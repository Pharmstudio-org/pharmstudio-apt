#!/bin/bash

PACKAGE_NAME="pharmstudio-rc-client"
VERSION="1.0-2"

BASEDIR=$(dirname "$0")
FULLNAME="${PACKAGE_NAME}_${VERSION}"
DIST_DIR=${BASEDIR}/dist

if [ $UID != 0 ]; then
    echo "Please run this script with sudo:"
    echo "sudo $0 $*"
    exit 1
fi

if [ -d $DIST_DIR ]; then rm -Rf $DIST_DIR; fi

mkdir -p ${DIST_DIR}/${FULLNAME}/DEBIAN
mkdir -p ${DIST_DIR}/${FULLNAME}/usr/bin
mkdir -p ${DIST_DIR}/${FULLNAME}/usr/share/${PACKAGE_NAME}

rsync -a --no-i-r --human-readable --info=progress2 ${BASEDIR} ${DIST_DIR}/${FULLNAME}/usr/share/${PACKAGE_NAME} --exclude .git --exclude .gitignore --exclude .venv --exclude __pycache__ --exclude dist

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/DEBIAN/control
Package: ${PACKAGE_NAME}
Version: ${VERSION}
Section: base
Priority: optional
Architecture: all
Maintainer: Valentin Osipenko <valtron.forever@gmail.com>
Depends: python3-websockets, python3-pydantic, vlc, tigervnc-scraping-server, openssh-server
Description: Pharmstudio remote controll client
 Allow remote access to this machine
EOF

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/DEBIAN/postinst
#!/bin/sh
echo "Instalation complete, please run '${PACKAGE_NAME}-init' (without sudo) to define connection settings"
exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/DEBIAN/postinst

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/DEBIAN/prerm
#!/bin/sh
chown -R root.root /usr/share/${PACKAGE_NAME}
rm -Rf /usr/share/${PACKAGE_NAME}/__pycache__

if [ -f /etc/systemd/system/${PACKAGE_NAME}.service ]; then
    systemctl stop ${PACKAGE_NAME}.service
    rm /etc/systemd/system/${PACKAGE_NAME}.service
    systemctl daemon-reload
fi

exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/DEBIAN/prerm

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/usr/bin/${PACKAGE_NAME}
#!/bin/sh
cd /usr/share/${PACKAGE_NAME}
RUN=prod python3 main.py
exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/usr/bin/${PACKAGE_NAME}

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/usr/bin/${PACKAGE_NAME}-init
#!/bin/sh
cd /usr/share/${PACKAGE_NAME}
python3 init.py
exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/usr/bin/${PACKAGE_NAME}-init

chown -R root.root ${DIST_DIR}/${FULLNAME}/usr/share/${PACKAGE_NAME}
find ${DIST_DIR}/${FULLNAME}/usr/share/${PACKAGE_NAME} | grep -E "(__pycache__|\.pyc|\.pyo$)" | xargs rm -rf

cd $DIST_DIR
dpkg-deb --build $FULLNAME

cd ..
chown -R $SUDO_USER.$SUDO_USER ${DIST_DIR}
