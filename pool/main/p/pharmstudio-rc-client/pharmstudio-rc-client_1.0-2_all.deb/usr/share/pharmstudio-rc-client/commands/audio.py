from typing import Optional
from enum import Enum
from subprocess import Popen, PIPE
from shutil import which
import os
from uuid import UUID
from pydantic import validator, BaseModel
from models import Task, Result, ResultEnum
from forwarding import (
    open_tunel, close_tunel_by_port, get_tunel_for_local_port,
    OpenTunelError, CloseTunelError,
    RemotePortAlreadyInUse, TunelAlreadyExists,
    TunelDoesNotExist,
    host
)


COMMAND_VERSION = 1
COMMAND_PORT = 4545
COMMAND_DESC = {
    'ru': "Воспроизведение аудио потока с устройства записи, установленного на клиенте",
    'default': "Відтворення аудіо потоку з пристрою запису, встановленого на клієнті",
}


class ActionEnum(str, Enum):
    open_action = 'open'
    close_action = 'close'
    status_action = 'status'


class AudioTask(Task):
    action: ActionEnum
    remote_port: Optional[int]
    stream_id: Optional[UUID]

    @validator('remote_port')
    def remote_port_must_exists(cls, v, values):
        if values['action'] == ActionEnum.open_action and not v:
            raise ValueError('For action `open` remote port must be set')
        return v

    @validator('stream_id')
    def stream_id_must_exists(cls, v, values):
        if values['action'] == ActionEnum.open_action and not v:
            raise ValueError('For action `open` stream id must be set')
        return v


class AudioResult(Result):
    remote_port: Optional[int]
    audio_url: Optional[str]


COMMAND_REQUEST_SCHEMA = AudioTask.schema()
COMMAND_RESULT_SCHEMA = AudioResult.schema()


class VlcProcess(BaseModel):
    process: Popen
    stream_id: UUID

    class Config:
        arbitrary_types_allowed = True


vlc_process: VlcProcess = None


def vlc_not_installed():
    return not which('cvlc')


def get_rec_url(stream_id):
    return f"/{stream_id}/rec.ogg"


async def open(task):
    global vlc_process
    if vlc_not_installed():
        return AudioResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Vlc not installed"
        )
    if vlc_process is not None:
        return AudioResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Vlc process already runing"
        )
    else:
        try:
            rec_url = get_rec_url(task.stream_id)
            my_env = os.environ.copy()
            my_env['DISPLAY'] = ':0.0'
            process = Popen([
                'cvlc',
                'alsa://pulse',
                '--sout',
                f"#transcode{{acodec=vorb,ab=64,samplerate=44100}}:standard{{access=http,mux=ogg,dst=127.0.0.1:{COMMAND_PORT}{rec_url}}}"
            ], env=my_env, stdout=PIPE, stderr=PIPE)
            vlc_process = VlcProcess(
                process=process,
                stream_id=task.stream_id,
            )
        except Exception as e:
            return AudioResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message=f"Error in runing vlc process: {e.message}"
            )
        try:
            open_tunel(COMMAND_PORT, task.remote_port)
        except OpenTunelError:
            vlc_process.process.terminate()
            vlc_process = None
            return AudioResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message="Open tunel error has occurred"
            )
        except RemotePortAlreadyInUse:
            vlc_process.process.terminate()
            vlc_process = None
            return AudioResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message=f"Remote port {task.remote_port} is already in use"
            )
        except TunelAlreadyExists:
            vlc_process.process.terminate()
            vlc_process = None
            return AudioResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message="Tunel already exist"
            )
        except Exception as e:
            vlc_process.process.terminate()
            vlc_process = None
            return AudioResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message="Failed to open connection: " + str(e),
            )
        return AudioResult(
            uuid=task.uuid,
            result=ResultEnum.ok_result,
            remote_port=task.remote_port,
            audio_url=f'http://{host}:{task.remote_port}{rec_url}'
        )


async def close(task):
    global vlc_process
    if vlc_process is not None:
        try:
            vlc_process.process.terminate()
        except Exception:
            pass
        finally:
            vlc_process = None
    try:
        close_tunel_by_port(COMMAND_PORT)
    except CloseTunelError:
        return AudioResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Close tunel error has occurred"
        )
    except TunelDoesNotExist:
        return AudioResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message=f"Tunel to remote port {COMMAND_PORT} does not exist"
        )
    except Exception as e:
        return AudioResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Failed to close connection: " + str(e),
        )
    return AudioResult(
        uuid=task.uuid,
        result=ResultEnum.ok_result
    )


async def status(task):
    if vlc_process is not None and vlc_process.process.poll() is None:
        try:
            tunel = get_tunel_for_local_port(COMMAND_PORT)
            rec_url = get_rec_url(vlc_process.stream_id)
            return AudioResult(
                uuid=task.uuid,
                result=ResultEnum.ok_result,
                message="opened",
                remote_port=tunel.remote_port,
                audio_url=f'http://{host}:{tunel.remote_port}{rec_url}'
            )
        except TunelDoesNotExist:
            return AudioResult(
                uuid=task.uuid,
                result=ResultEnum.ok_result,
                message="closed",
            )
        except Exception as e:
            return AudioResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message="Failed to get status: " + str(e),
            )
    else:
        return AudioResult(
            uuid=task.uuid,
            result=ResultEnum.ok_result,
            message="closed",
        )


async def run(message: dict):
    task = AudioTask(**message)
    if task.action == ActionEnum.open_action:
        return await open(task)
    elif task.action == ActionEnum.close_action:
        return await close(task)
    elif task.action == ActionEnum.status_action:
        return await status(task)
    else:
        return AudioResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message=f"Unknown action {task.action}"
        )
