from typing import List
from pkgutil import iter_modules
import importlib
from pydantic import BaseModel
from models import Task, Result, ResultEnum
import commands


COMMAND_VERSION = 1
COMMAND_PORT = None
COMMAND_DESC = {
    'ru': "Перечень доступных команд",
    'default': "Перелік доступних команд",
}


class Command(BaseModel):
    name: str
    version: int
    port: int = None
    description: dict
    request_schema: dict
    result_schema: dict


class ListCommandsTaskResult(Result):
    commands: List[Command]


COMMAND_REQUEST_SCHEMA = Task.schema()
COMMAND_RESULT_SCHEMA = ListCommandsTaskResult.schema()


async def run(message: dict):
    command_list = []
    for name in [m.name for m in iter_modules(commands.__path__)]:
        module = importlib.import_module(f"commands.{name}")
        command_list.append(Command(
            name=name,
            version=module.COMMAND_VERSION,
            port=module.COMMAND_PORT,
            description=module.COMMAND_DESC,
            request_schema=module.COMMAND_REQUEST_SCHEMA,
            result_schema=module.COMMAND_RESULT_SCHEMA,
        ))

    task = Task(**message)
    return ListCommandsTaskResult(
        uuid=task.uuid,
        result=ResultEnum.ok_result,
        commands=command_list,
    )
