#!/bin/bash

PACKAGE_NAME="pharmstudio-rc-client"

if [ $UID != 0 ]; then
    echo "Please run this script with sudo:"
    echo "sudo $0 $*"
    exit 1
fi

/bin/cat <<EOF > /etc/systemd/system/${PACKAGE_NAME}.service
[Unit]
Description=Pharmstudio Remote Control Client
After=multi-user.target

[Service]
Type=idle
User=$SUDO_USER
Group=$SUDO_USER
ExecStart=/usr/bin/${PACKAGE_NAME}
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
