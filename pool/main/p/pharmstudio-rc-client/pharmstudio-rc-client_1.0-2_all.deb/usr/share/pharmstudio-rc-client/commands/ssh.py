from enum import Enum
from typing import Optional
from pydantic import validator
from models import Task, Result, ResultEnum
from forwarding import (
    open_tunel, close_tunel_by_port, get_tunel_for_local_port,
    OpenTunelError, CloseTunelError,
    RemotePortAlreadyInUse, TunelAlreadyExists,
    TunelDoesNotExist,
)


COMMAND_VERSION = 1
COMMAND_PORT = 22
COMMAND_DESC = {
    'ru': "Удаленный доступ по протоколу ssh",
    'default': "Віддалений доступ по протоколу ssh",
}


class ActionEnum(str, Enum):
    open_action = 'open'
    close_action = 'close'
    status_action = 'status'


class SshTask(Task):
    action: ActionEnum
    remote_port: Optional[int]

    @validator('remote_port')
    def command_must_exists(cls, v, values):
        if values['action'] == ActionEnum.open_action and not v:
            raise ValueError('For action `open` remote port must be set')
        return v


class SshResult(Result):
    remote_port: Optional[int]


COMMAND_REQUEST_SCHEMA = SshTask.schema()
COMMAND_RESULT_SCHEMA = SshResult.schema()


async def open(task: SshTask):
    try:
        open_tunel(COMMAND_PORT, task.remote_port)
    except OpenTunelError:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Open tunel error has occurred"
        )
    except RemotePortAlreadyInUse:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message=f"Remote port {task.remote_port} is already in use"
        )
    except TunelAlreadyExists:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Tunel already exist"
        )
    except Exception as e:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Failed to open connection: " + str(e),
        )
    return SshResult(
        uuid=task.uuid,
        result=ResultEnum.ok_result,
        remote_port=task.remote_port,
    )


async def close(task: SshTask):
    try:
        close_tunel_by_port(COMMAND_PORT)
    except CloseTunelError:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Close tunel error has occurred"
        )
    except TunelDoesNotExist:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message=f"Tunel to remote port {COMMAND_PORT} does not exist"
        )
    except Exception as e:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Failed to close connection: " + str(e),
        )
    return SshResult(
        uuid=task.uuid,
        result=ResultEnum.ok_result
    )


async def status(task: SshTask):
    try:
        tunel = get_tunel_for_local_port(COMMAND_PORT)
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.ok_result,
            message="opened",
            remote_port=tunel.remote_port,
        )
    except TunelDoesNotExist:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.ok_result,
            message="closed",
        )
    except Exception as e:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Failed to get status: " + str(e),
        )


async def run(message: dict):
    task = SshTask(**message)
    if task.action == ActionEnum.open_action:
        return await open(task)
    elif task.action == ActionEnum.close_action:
        return await close(task)
    elif task.action == ActionEnum.status_action:
        return await status(task)
    else:
        return SshResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message=f"Unknown action {task.action}"
        )
