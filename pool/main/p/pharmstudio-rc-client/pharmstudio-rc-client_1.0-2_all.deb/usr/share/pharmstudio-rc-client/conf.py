from pathlib import Path
import configparser


version = '1.0'

base_dir = Path(__file__).parent.absolute()
config = configparser.ConfigParser()
config.read(Path.home() / '.pharmstudio' / 'rc-client' / 'config.ini')
