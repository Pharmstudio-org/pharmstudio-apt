from typing import Optional
from pkgutil import iter_modules
from subprocess import Popen
from enum import Enum
from uuid import UUID
from pydantic import BaseModel, Field, validator
import commands


class ClientHeaders(BaseModel):
    x_client: str = Field(..., alias='x-client')
    x_drugstore_id: str = Field(..., alias='x-drugstore-id')
    x_version: str = Field(..., alias='x-version')

    class Config:
        allow_population_by_field_name = True


class ResultEnum(str, Enum):
    ok_result = 'ok'
    error_result = 'error'


class Message(BaseModel):
    uuid: UUID


class Task(Message):
    command: str

    @validator('command')
    def command_must_exists(cls, v):
        command_names = [m.name for m in iter_modules(commands.__path__)]
        if v not in command_names:
            raise ValueError('must exists')
        return v


class Result(Message):
    result: ResultEnum
    message: Optional[str]


class InvalidMessage(BaseModel):
    error: str


class Tunel(BaseModel):
    uuid: UUID
    local_port: int
    remote_port: int


class TunelStore(Tunel):
    process: Popen

    class Config:
        arbitrary_types_allowed = True
