import os
import logging

if os.environ.get('RUN', 'dev') == 'prod':
    logging.basicConfig(level=logging.WARNING)
else:
    logging.basicConfig(level=logging.DEBUG)

logger = logging.getLogger(__name__)
