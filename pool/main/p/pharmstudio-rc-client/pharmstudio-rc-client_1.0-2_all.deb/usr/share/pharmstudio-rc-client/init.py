from pathlib import Path
import os
import pwd
import configparser


def init():
    conf_dir = Path.home() / '.pharmstudio' / 'rc-client'
    if not conf_dir.exists():
        conf_dir.mkdir(parents=True, exist_ok=True)
    conf_file = conf_dir / 'config.ini'

    with conf_file.open("w", encoding="utf-8") as cfg:
        config = configparser.ConfigParser()

        print("Please enter following settings")
        host = input("Host name (rc.pharmstudio.com.ua):")
        if host == '':
            host = 'rc.pharmstudio.com.ua'

        secure = input("Use secure connection (y/N):")
        if secure.lower() == 'y':
            secure = True
        else:
            secure = False

        drugstore_id_not_filled = True
        while drugstore_id_not_filled:
            drugstore_id = input("Drugstore id (required):")
            try:
                if int(drugstore_id):
                    drugstore_id_not_filled = False
            except Exception:
                pass

        client = input("Client name (Касса 1):")
        if client == '':
            client = "Касса 1"

        config['connection'] = {
            'host': host,
            'secure': secure,
            'drugstore_id': drugstore_id,
            'client': client,
        }

        config.write(cfg)

        install_service = input("would you install systemd service? (y/N):")
        if install_service.lower() == 'y':
            curr_dir = os.path.dirname(os.path.abspath(__file__))
            os.system('sudo ' + os.path.join(curr_dir, 'install_service.sh'))
        else:
            print("You can install service manually later by executing 'sudo /usr/share/pharmstudio-rc-client/install_service.sh'")

        username = pwd.getpwuid(os.getuid()).pw_name
        os.system('sudo cp -r ' + str(Path(__file__).parent.absolute() / 'key') + ' ' + str(conf_dir))
        os.system(f'sudo chown -R {username}.{username} ' + str(conf_dir / 'key'))


if __name__ == '__main__':
    init()
