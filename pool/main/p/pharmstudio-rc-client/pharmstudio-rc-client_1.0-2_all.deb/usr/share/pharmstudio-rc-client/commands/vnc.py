from typing import Optional
from enum import Enum
from subprocess import Popen, PIPE
from shutil import which
from pathlib import Path
from pydantic import validator, BaseModel
from models import Task, Result, ResultEnum
from forwarding import (
    open_tunel, close_tunel_by_port, get_tunel_for_local_port,
    OpenTunelError, CloseTunelError,
    RemotePortAlreadyInUse, TunelAlreadyExists,
    TunelDoesNotExist,
)


COMMAND_VERSION = 1
COMMAND_PORT = 5900
COMMAND_DESC = {
    'ru': "Удаленный доступ по протоколу vnc",
    'default': "Віддалений доступ по протоколу vnc",
}


class VncActionEnum(str, Enum):
    open_action = 'open'
    display_action = 'display'
    close_action = 'close'
    status_action = 'status'


class VncTask(Task):
    action: VncActionEnum
    remote_port: Optional[int]

    @validator('remote_port')
    def remote_port_must_exists(cls, v, values):
        if values['action'] == VncActionEnum.open_action and not v:
            raise ValueError('For action `open` remote port must be set')
        return v


class VncResult(Result):
    remote_port: Optional[int]


COMMAND_REQUEST_SCHEMA = VncTask.schema()
COMMAND_RESULT_SCHEMA = VncResult.schema()


class VncProcess(BaseModel):
    process: Popen

    class Config:
        arbitrary_types_allowed = True


vnc_process: VncProcess = None


def vnc_not_installed():
    return not which('x0vncserver')


def get_vnc_controll_args():
    return [
        'x0vncserver',
        '-display',
        ':0',
        '-passwordfile',
        str(Path.home() / '.pharmstudio' / 'rc-client' / 'key' / 'passwd'),
        '-rfbport',
        f'{COMMAND_PORT}',
    ]


def get_vnc_display_args():
    return get_vnc_controll_args() + [
        '-AcceptSetDesktopSize=0',
        '-SendCutText=0',
        '-AcceptCutText=0',
        '-AcceptPointerEvents=0',
        '-AcceptKeyEvents=0',
    ]


async def open(task, display_only=False):
    global vnc_process
    if vnc_not_installed():
        return VncResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Vnc server not installed"
        )
    if vnc_process is not None:
        return VncResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Vnc server process already runing"
        )
    else:
        try:
            if display_only:
                process_args = get_vnc_display_args()
            else:
                process_args = get_vnc_controll_args()
            process = Popen(process_args, stdout=PIPE, stderr=PIPE)
            vnc_process = VncProcess(
                process=process,
            )
        except Exception as e:
            return VncResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message=f"Error in runing vnc server process: {e.message}"
            )
        try:
            open_tunel(COMMAND_PORT, task.remote_port)
        except OpenTunelError:
            vnc_process.process.terminate()
            vnc_process = None
            return VncResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message="Open tunel error has occurred"
            )
        except RemotePortAlreadyInUse:
            vnc_process.process.terminate()
            vnc_process = None
            return VncResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message=f"Remote port {task.remote_port} is already in use"
            )
        except TunelAlreadyExists:
            vnc_process.process.terminate()
            vnc_process = None
            return VncResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message="Tunel already exist"
            )
        except Exception as e:
            vnc_process.process.terminate()
            vnc_process = None
            return VncResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message="Failed to open connection: " + str(e),
            )
        return VncResult(
            uuid=task.uuid,
            result=ResultEnum.ok_result,
            remote_port=task.remote_port,
        )


async def close(task):
    global vnc_process
    if vnc_process is not None:
        try:
            vnc_process.process.terminate()
        except Exception:
            pass
        finally:
            vnc_process = None
    try:
        close_tunel_by_port(COMMAND_PORT)
    except CloseTunelError:
        return VncResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Close tunel error has occurred"
        )
    except TunelDoesNotExist:
        return VncResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message=f"Tunel to remote port {COMMAND_PORT} does not exist"
        )
    except Exception as e:
        return VncResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message="Failed to close connection: " + str(e),
        )
    return VncResult(
        uuid=task.uuid,
        result=ResultEnum.ok_result
    )


async def status(task):
    if vnc_process is not None and vnc_process.process.poll() is None:
        try:
            tunel = get_tunel_for_local_port(COMMAND_PORT)
            return VncResult(
                uuid=task.uuid,
                result=ResultEnum.ok_result,
                message="opened",
                remote_port=tunel.remote_port,
            )
        except TunelDoesNotExist:
            return VncResult(
                uuid=task.uuid,
                result=ResultEnum.ok_result,
                message="closed",
            )
        except Exception as e:
            return VncResult(
                uuid=task.uuid,
                result=ResultEnum.error_result,
                message="Failed to get status: " + str(e),
            )
    else:
        return VncResult(
            uuid=task.uuid,
            result=ResultEnum.ok_result,
            message="closed",
        )


async def run(message: dict):
    task = VncTask(**message)
    if task.action == VncActionEnum.open_action:
        return await open(task)
    elif task.action == VncActionEnum.display_action:
        return await open(task, display_only=True)
    elif task.action == VncActionEnum.close_action:
        return await close(task)
    elif task.action == VncActionEnum.status_action:
        return await status(task)
    else:
        return VncResult(
            uuid=task.uuid,
            result=ResultEnum.error_result,
            message=f"Unknown action {task.action}"
        )
