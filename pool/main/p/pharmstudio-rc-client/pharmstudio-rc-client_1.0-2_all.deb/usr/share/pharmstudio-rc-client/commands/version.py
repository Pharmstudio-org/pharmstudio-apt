from models import Task, Result, ResultEnum
from conf import version


COMMAND_VERSION = 1
COMMAND_PORT = None
COMMAND_DESC = {
    'ru': "Версия клиентского ПО",
    'default': "Версія клієнтського ПЗ",
}


COMMAND_REQUEST_SCHEMA = Task.schema()
COMMAND_RESULT_SCHEMA = Result.schema()


async def run(message: dict):
    task = Task(**message)
    return Result(
        uuid=task.uuid,
        result=ResultEnum.ok_result,
        message=version,
    )
