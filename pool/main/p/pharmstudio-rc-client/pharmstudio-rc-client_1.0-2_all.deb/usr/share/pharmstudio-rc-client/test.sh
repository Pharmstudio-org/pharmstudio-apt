#!/usr/bin/make -f
export PYBUILD_NAME=foo

%:
        echo $@