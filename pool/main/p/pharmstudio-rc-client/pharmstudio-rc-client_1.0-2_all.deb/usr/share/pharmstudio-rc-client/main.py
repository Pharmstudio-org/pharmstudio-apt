import sys
import asyncio
import websockets
import json
import urllib
from importlib import import_module
from pydantic import ValidationError
from models import ClientHeaders
from app_log import logger
from conf import config, version
from models import Task

RECONNECT_TIMEOUT_SECONDS = 10
loop = asyncio.get_event_loop()


async def run():
    proto = 'ws://'
    if config['connection']['secure'] == 'True':
        proto = 'wss://'

    uri = f"{proto}{config['connection']['host']}/api/remote/ws"
    print(config['connection']['client'])
    headers = ClientHeaders(
        x_client=urllib.parse.quote(config['connection']['client']),
        x_drugstore_id=config['connection']['drugstore_id'],
        x_version=version,
    )

    while True:
        try:
            async with websockets.connect(
                uri,
                extra_headers=headers.dict(by_alias=True)
            ) as websocket:
                while True:
                    raw_message = await websocket.recv()
                    logger.debug(f"New message received: {raw_message}")

                    message = json.loads(raw_message)
                    try:
                        task = Task(**message)
                        module = import_module(f"commands.{task.command}")
                        result = await module.run(message)
                    except ValidationError as ve:
                        logger.exception(ve)
                        await websocket.send(ve.json())
                        continue

                    await websocket.send(result.json(by_alias=True))
        except (
            websockets.exceptions.WebSocketException, ConnectionRefusedError
        ) as e:
            logger.exception(e)
            logger.debug(
                f"Try to reconnect in {RECONNECT_TIMEOUT_SECONDS} seconds")
            await asyncio.sleep(RECONNECT_TIMEOUT_SECONDS)


def main():
    main_loop = asyncio.get_event_loop()
    try:
        return main_loop.run_until_complete(run())
    except KeyboardInterrupt:
        print('CTRL+C detected.')
        return 1
    finally:
        if not main_loop.is_closed():
            main_loop.close()


if __name__ == '__main__':
    sys.exit(main())
