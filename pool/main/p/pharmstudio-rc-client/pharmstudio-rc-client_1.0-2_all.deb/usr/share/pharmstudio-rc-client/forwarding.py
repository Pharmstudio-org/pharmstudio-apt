from subprocess import Popen, PIPE
import socket
from uuid import uuid4, UUID
from pathlib import Path
from models import TunelStore
from conf import config, base_dir


#host = config['connection']['host']
host = 'pharmstudio.com.ua'
tunels = {}


class OpenTunelError(Exception):
    pass


class CloseTunelError(Exception):
    pass


class TunelDoesNotExist(Exception):
    pass


class RemotePortAlreadyInUse(Exception):
    pass


class TunelAlreadyExists(Exception):
    pass


def remote_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        in_free = s.connect_ex((host, port)) == 0
    return not in_free


def open_tunel(local_port: int, remote_port: int):
    tunel_id = uuid4()

    if local_port in [tunel.local_port for tunel in tunels.values()]:
        raise TunelAlreadyExists

    #if remote_port_in_use(remote_port):
    #    raise RemotePortAlreadyInUse

    try:
        p = Popen([
            '/usr/bin/ssh',
            '-N',
            '-o',
            'StrictHostKeyChecking=accept-new',
            '-R',
            f'{remote_port}:127.0.0.1:{local_port}',
            '-i',
            str(Path.home() / '.pharmstudio' / 'rc-client' / 'key' / 'id_rsa'),
            f'pharmstudio_rc@{host}',
        ], stdout=PIPE, stderr=PIPE)
    except Exception:
        raise OpenTunelError

    tunel = TunelStore(
        uuid=tunel_id,
        local_port=local_port,
        remote_port=remote_port,
        process=p,
    )
    tunels[tunel_id] = tunel
    return tunel


def close_tunel(tunel_id: UUID):
    if tunels.get(tunel_id, None) is None:
        raise TunelDoesNotExist
    tunels[tunel_id].process.terminate()
    del tunels[tunel_id]


def close_tunel_by_port(port: int):
    tunel = None
    for t in tunels.values():
        if t.local_port == port:
            tunel = t
    if tunel is None:
        raise TunelDoesNotExist
    tunel.process.terminate()
    del tunels[tunel.uuid]


def is_local_port_forwarded(port: int):
    tunel = None
    for t in tunels.values():
        if t.local_port == port:
            tunel = t
    if tunel is None:
        return False
    else:
        if tunel.process.poll() is None:
            return True
        else:
            del tunels[tunel.uuid]
            return False


def get_tunel_for_local_port(port: int) -> TunelStore:
    tunel = None
    for t in tunels.values():
        if t.local_port == port:
            tunel = t
    if tunel is None:
        raise TunelDoesNotExist
    else:
        if tunel.process.poll() is None:
            return tunel
        else:
            del tunels[tunel.uuid]
            raise TunelDoesNotExist
