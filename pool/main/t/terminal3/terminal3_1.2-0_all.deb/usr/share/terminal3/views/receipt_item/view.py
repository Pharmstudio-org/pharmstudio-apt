from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import ReceiptItemHandler
from .layout import ReceiptItemLayout
from .state import ReceiptItemState


class ReceiptItemDialogView(View):
    glade_file = 'receipt_item_dialog.glade'
    main_widget_id = 'dialog_receipt_item'

    event_handler_class = ReceiptItemHandler
    layout_class = ReceiptItemLayout
    state_class = ReceiptItemState

    __gsignals__ = {
        'add': (GObject.SIGNAL_RUN_FIRST, None, (int, int, int)),
    }
