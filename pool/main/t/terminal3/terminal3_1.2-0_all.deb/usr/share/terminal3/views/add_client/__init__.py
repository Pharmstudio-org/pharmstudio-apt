from .view import AddClientDialogView
