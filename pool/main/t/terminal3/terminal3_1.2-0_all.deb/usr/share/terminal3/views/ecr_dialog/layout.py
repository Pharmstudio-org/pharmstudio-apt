from views.common import Layout, Widget
from composites.accounts_header import AccountsHeaderBox
import settings


class EcrDialogLayout(Layout):
    stack = Widget('form_stack')
    last_receipt_copy_button = Widget('last_receipt_copy_button')

    accounts_box = Widget('accounts_box')
    accounts_stack = Widget('accounts_stack')
    accounts_loader_box = Widget('accounts_loader_box')
    accounts_loader_image = Widget('accounts_loader_image')
    accounts_error_box = Widget('accounts_error_box')
    accounts_list_window = Widget('accounts_list_window')
    accounts_list = Widget('accounts_list')
    accounts_refresh_button = Widget('accounts_refresh_button')
    accounts_in_spin = Widget('accounts_in_spin')
    accounts_in_button = Widget('accounts_in_button')
    accounts_out_spin = Widget('accounts_out_spin')
    accounts_out_button = Widget('accounts_out_button')
    accounts_adjustment_out = Widget('adjustment_out')
    accounts_widgets = None
    accounts_cash_transfer_widgets = None
    accounts_cash_transfer_in_widgets = None
    accounts_cash_transfer_out_widgets = None

    reports_stack = Widget('reports_stack')
    reports_box = Widget('reports_box')
    reports_loader_box = Widget('reports_loader_box')
    reports_error_box = Widget('reports_error_box')
    reportx_button = Widget('reportx_button')
    reportz_button = Widget('reportz_button')
    sessionopen_button = Widget('sessionopen_button')
    report_buttons = None

    service_box = Widget('service_box')
    service_lock_button = Widget('service_lock_button')
    send_and_reset_button = Widget('send_and_reset_button')

    settings = Widget('settings_box')

    devices_stack = Widget('devices_stack')
    loader_box = Widget('loader_box')
    device_loader_image = Widget('devices_loader_image')
    devices_box = Widget('devices_box')
    devices_list = Widget('devices_list_box')
    select_device_button = Widget('select_device_button')

    error_box = Widget('error_box')

    renderers = {
        'service_dialog_locked': 'render_service_actions',
    }

    def build(self, *args, **kwargs):
        super(EcrDialogLayout, self).build(*args, **kwargs)
        self.report_buttons = [self.reportx_button, self.reportz_button, self.sessionopen_button]
        self.accounts_widgets = [self.accounts_refresh_button, self.accounts_in_spin, self.accounts_in_button,
                                 self.accounts_out_spin, self.accounts_out_button]
        self.accounts_cash_transfer_in_widgets = [self.accounts_in_spin, self.accounts_in_button]
        self.accounts_cash_transfer_out_widgets = [self.accounts_out_spin, self.accounts_out_button]
        self.accounts_cash_transfer_widgets = self.accounts_cash_transfer_in_widgets + self.accounts_cash_transfer_out_widgets

        self.settings.connect('settings_changed', self.view.on_settings_form_save)
        self.settings.init_settings(self.view.config)
        self.devices_stack.set_visible_child(self.devices_box)
        self.accounts_list.set_header_func(self.accounts_list_set_header)

        self.service_lock_button.set_active(not self.view.state.service_dialog_locked)
        self.render_service_actions()

        self.connect_state(self.view.state, self.renderers)

    def render_service_actions(self, *args):
        if self.view.state.service_dialog_locked:
            self.set_disabled(self.send_and_reset_button)
        else:
            self.set_sensitive(self.send_and_reset_button)

    def render(self):
        pass

    def accounts_list_set_header(self, row, before, *args):
        if before is None:
            row.set_header(AccountsHeaderBox())

    def clear_devices_list(self):
        self.devices_list.foreach(lambda child: self.devices_list.remove(child))

    def clear_accounts_list(self):
        self.accounts_list.foreach(lambda child: self.accounts_list.remove(child))

    def update_cash_transfer_sensitivity(self):
        row = self.accounts_list.get_selected_row()
        if row:
            account = row.get_child().get_account()
            if account['sum']:
                self.set_sensitive(*self.accounts_cash_transfer_widgets)
                self.accounts_adjustment_out.set_upper(account['sum'])
            else:
                self.set_sensitive(*self.accounts_cash_transfer_in_widgets)
                self.set_disabled(*self.accounts_cash_transfer_out_widgets)
            if account['no'] not in [settings.config['ecr'].cash_account_no]:
                self.set_disabled(*self.accounts_cash_transfer_in_widgets)
        else:
            self.set_disabled(*self.accounts_cash_transfer_widgets)
