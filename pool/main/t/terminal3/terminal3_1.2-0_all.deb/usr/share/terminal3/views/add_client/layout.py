from views.common import Layout, Binding


class AddClientDialogLayout(Layout):
    client_code = Binding('entry_client_code')

    def render(self):
        self.client_code = ''
        self.focus('entry_client_code')
