from .view import AddClientByPhoneDialogView
