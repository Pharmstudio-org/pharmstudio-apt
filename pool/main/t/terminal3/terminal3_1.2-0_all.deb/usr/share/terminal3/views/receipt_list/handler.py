from views.common import Handler


class ReceiptListHandler(Handler):
    def on_refresh(self, *args):
        self.layout.stack.set_visible_child(self.layout.loader)
        self.view.receipt_collection.clear()
        self.view.receipt_collection.api('list')

    def on_close(self, *args):
        self.view.receipt_collection.clear()
        self.emit('close')

    def on_selection_changed(self, selection):
        (store, iter) = selection.get_selected()
        self.view.selected_receipt_model = self.view.receipt_collection.get(iter)
        self.layout.update_btn_show_receipt_sensitivity()
        return True

    def on_open_receipt(self, *args):
        self.emit('open_receipt', self.view.selected_receipt_model)
