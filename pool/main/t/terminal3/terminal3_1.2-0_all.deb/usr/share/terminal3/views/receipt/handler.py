import json
import os
import tempfile
from gi.repository import GObject, Gtk, Gdk, Pango
from decimal import Decimal
from views.client_not_found import ClientNotFoundDialogView
from views.common import Handler
from views.receipt_item import ReceiptItemDialogView
from views.add_client import AddClientDialogView
from views.add_client_by_phone import AddClientByPhoneDialogView
from views.client_form import ClientFromDialogView
from views.add_cashless_amount import AddCashlessAmountDialogView
from views.add_reimbursement import AddReimbursementDialogView
from views.to_money_box import ToMoneyBoxDialogView
from views.from_money_box import FromMoneyBoxDialogView
from api.receipt import ReceiptCancelRequest, ReceiptCloseRequest
from api.receipt_print import GetReceiptTextRequest, PrintReceiptRequest
from api.crm_info import ClientNotifiedRequest
from api.ecr.receipts import EcrReceiptRequest, DecimalEncoder
from settings import config


class ReceiptHandler(Handler):
    def on_spinbutton_key_press(self, widget, event, *args):
        key = Gdk.keyval_name(event.keyval)
        if key == 'KP_Decimal':
            # Comma
            event.keyval = 44
            event.hardware_keycode = 59
            event.put()
            return True
        else:
            return False

    def on_spinbutton_changed(self, *args):
        self.layout.calculate_back()

    def on_selection_changed(self, selection):
        (store, iter) = selection.get_selected()
        self.view.selected_receipt_item = self.view.receipt_item_collection.get(iter)
        return True

    def on_add_item(self, *args):
        self.view.receipt_item_dialog = ReceiptItemDialogView(self.view.application)
        self.view.receipt_item_dialog.connect('add', self.on_receipt_item_add)
        self.view.receipt_item_dialog.set_parent(self.view.application.application_window)
        self.view.receipt_item_dialog.layout().render()
        self.view.receipt_item_dialog.widget().show_all()

    def on_add_card(self, *args):
        if self.view.add_client_dialog is None:
            self.view.add_client_dialog = AddClientDialogView(self.view.application)
            self.view.add_client_dialog.connect('add', self.on_card_add)
            self.view.add_client_dialog.connect('find-by-phone', self.on_find_by_phone)
            self.view.add_client_dialog.connect('register-new-client', self.on_register_new_client)
        self.view.add_client_dialog.set_parent(self.view.application.application_window)
        self.view.add_client_dialog.layout().render()
        self.view.add_client_dialog.widget().show_all()

    def on_add_cashless_amount(self, *args):
        if self.view.add_cashless_amount_dialog is None:
            self.view.add_cashless_amount_dialog = AddCashlessAmountDialogView(self.view.application)
            self.view.add_cashless_amount_dialog.connect('add', self.on_cashless_amount_add)
        self.view.add_cashless_amount_dialog.set_parent(self.view.application.application_window)
        self.view.add_cashless_amount_dialog.layout().render(self.view.get_total())
        self.view.add_cashless_amount_dialog.widget().show_all()

    def on_button_add_reimbursement_clicked(self, *args):
        if self.view.add_reimbursement_dialog is None:
            self.view.add_reimbursement_dialog = AddReimbursementDialogView(self.view.application)
            self.view.add_reimbursement_dialog.connect('add', self.on_reimbursement_add)
        self.view.add_reimbursement_dialog.set_parent(self.view.application.application_window)
        self.view.add_reimbursement_dialog.layout().render(self.view.get_total())
        self.view.add_reimbursement_dialog.widget().show_all()

    def on_to_money_box(self, *args):
        if self.view.to_money_box_dialog is None:
            self.view.to_money_box_dialog = ToMoneyBoxDialogView(self.view.application)
            self.view.to_money_box_dialog.connect('add', self.on_to_money_box_add)
        total = self.view.get_total()
        self.view.to_money_box_dialog.set_parent(self.view.application.application_window)
        self.view.to_money_box_dialog.layout().render(Decimal(int(total) + 1) - total)
        self.view.to_money_box_dialog.widget().show_all()

    def on_from_money_box(self, *args):
        if self.view.from_money_box_dialog is None:
            self.view.from_money_box_dialog = FromMoneyBoxDialogView(self.view.application)
            self.view.from_money_box_dialog.connect('add', self.on_from_money_box_add)
        total = self.view.get_total()
        coins = total - int(total)
        self.view.from_money_box_dialog.set_parent(self.view.application.application_window)
        if self.layout.client_money_box > coins:
            self.view.from_money_box_dialog.layout().render(coins, self.layout.client_money_box)
        else:
            self.view.from_money_box_dialog.layout().render(self.layout.client_money_box, self.layout.client_money_box)
        self.view.from_money_box_dialog.widget().show_all()

    def on_reset_money_box(self, *args):
        self.view.from_money_box = None
        self.view.to_money_box = None
        self.layout.calculate_money_box_transfer()

    def on_close_icon_clicked(self, *args):
        self.emit('close')

    # -- Requests --
    # Cancel
    def on_receipt_cancel(self, *args):
        ReceiptCancelRequest(
            self.view.receipt.id,
            on_success=self.on_receipt_cancel_request_success,
            on_error=self.on_receipt_cancel_request_error,
        )
        self.layout.set_dialog_disabled()

    def on_receipt_cancel_request_success(self, data):
        self.emit('close')

    def on_receipt_cancel_request_error(self, error):
        self.layout.set_dialog_sensitive()
        self.view.application.show_network_error()

    # Close
    def on_receipt_close(self, *args):
        #account_to = getattr(settings, 'ACCOUNT_TO', None)
        account_to = config['auth'].account_to
        data = {}
        if account_to:
            data['account_to'] = account_to

        if self.view.from_money_box:
            data['from_money_box'] = self.view.from_money_box
        elif self.view.to_money_box:
            data['to_money_box'] = self.view.to_money_box

        ReceiptCloseRequest(
            self.view.receipt.id,
            on_success=self.on_receipt_close_request_success,
            on_error=self.on_receipt_close_request_error,
            data=data,
        )
        self.layout.set_dialog_disabled()

    def on_receipt_close_request_success(self, data):
        if config['print'].enabled and config['print'].auto_print:
            self.on_receipt_print()

        self.emit('receipt_closed')
        self.emit('close')

    def on_receipt_close_request_error(self, error):
        self.layout.set_dialog_sensitive()
        self.view.application.show_network_error()

    # Print
    def on_receipt_print(self, *args, **kwargs):
        if config['print'].enabled:
            GetReceiptTextRequest(
                self.view.receipt.id,
                on_success=self.on_receipt_text_success,
                on_error=self.on_receipt_text_error
            )
            self.layout.set_dialog_disabled()

    def on_receipt_text_error(self, error):
        self.layout.set_dialog_sensitive()
        self.view.application.show_network_error()

    def on_receipt_text_success(self, data):
        PrintReceiptRequest(
            data.get('receipt').encode('utf8'),
            on_success=self.on_print_receipt_success,
            on_error=self.on_print_receipt_error
        )

    def on_print_receipt_success(self, data):
        self.layout.set_dialog_sensitive()

    def on_print_receipt_error(self, error):
        self.layout.set_dialog_sensitive()
        self.view.application.show_network_error()

    # Ecr
    def on_receipt_ecr(self, *args):
        ecr_receipt_list = []
        for item in self.view.receipt_item_collection:
            ecr_receipt_list.append(item.get_ecr_json())
        if config['reimbursement'].enabled and self.view.receipt.reimbursement:
            ecr_receipt_list.append({'D': {'sum': self.view.receipt.reimbursement * -1}})
        if self.view.receipt.cashless_amount:
            ecr_receipt_list.append({'P': {'no': config['ecr'].cashless_account_no, 'sum': self.view.receipt.cashless_amount}})
            if self.view.receipt.cashless_amount < self.view.receipt.total_with_discount:
                ecr_receipt_list.append({'P': {
                    'sum': self.view.receipt.total_with_discount - self.view.receipt.cashless_amount
                }})
        else:
            ecr_receipt_list.append({'P': {}})

        f = tempfile.NamedTemporaryFile(mode='w', delete=False, encoding='utf-8')
        json.dump({'F': ecr_receipt_list}, f, cls=DecimalEncoder, ensure_ascii=False)
        name = f.name
        f.close()

        def on_success(*args):
            os.unlink(f.name)
            self.layout.set_sensitive(self.layout.btn_receipt_ecr)

        def on_error(*args):
            os.unlink(f.name)
            self.layout.set_sensitive(self.layout.btn_receipt_ecr)
            print(args)
            self.view.application.show_network_error()

        self.layout.set_disabled(self.layout.btn_receipt_ecr)
        EcrReceiptRequest(name, on_success=on_success, on_error=on_error)

    # Add receipt item
    def on_receipt_item_add(self, dialog, goods_code_id, count, units):
        self.view.receipt_item_collection.api('create', data={
            'goods_code': goods_code_id,
            'count': count,
            'units': units,
        }, on_error=lambda e: [self.view.application.show_network_error(), self.layout.set_dialog_sensitive()])
        self.layout.set_dialog_disabled()
        self.layout.focus('spinbutton_entry')

    # Remove receipt item
    def on_receipt_item_delete(self, *args):
        if self.view.selected_receipt_item:
            self.view.selected_receipt_item.api('delete',
                                                on_error=lambda e: [self.view.application.show_network_error(),
                                                                    self.layout.set_dialog_sensitive()])
            self.layout.set_dialog_disabled()

    # Client
    def on_card_add(self, dialog, client_code):
        self.view.receipt.api('add_card', data={
            'client_code': client_code,
        })
        self.layout.set_dialog_disabled()

    def on_card_not_found(self, *args):
        self.layout.set_dialog_sensitive()
        if self.view.client_not_found_dialog is None:
            self.view.client_not_found_dialog = ClientNotFoundDialogView(self.view.application)
        self.view.client_not_found_dialog.set_parent(self.view.application.application_window)
        self.view.client_not_found_dialog.widget().show_all()

    def on_find_by_phone(self, *args):
        if self.view.add_client_by_phone_dialog is None:
            self.view.add_client_by_phone_dialog = AddClientByPhoneDialogView(self.view.application)
            self.view.add_client_by_phone_dialog.connect('add', self.on_card_add)
        self.view.add_client_by_phone_dialog.set_parent(self.view.application.application_window)
        self.view.add_client_by_phone_dialog.layout().render()
        self.view.add_client_by_phone_dialog.widget().show_all()

    def on_register_new_client(self, *args):
        if self.view.add_client_dialog is not None:
            self.view.add_client_dialog.widget().close()
            self.view.add_client_dialog = None

        client_form_dialog = ClientFromDialogView(self.view.application)
        client_form_dialog.connect('add', self.on_card_add)
        client_form_dialog.set_parent(self.view.application.application_window)
        client_form_dialog.layout().render()
        client_form_dialog.widget().show_all()

    def on_client_remove(self, *args):
        self.view.receipt.api('remove_client', on_error=lambda e: [self.view.application.show_network_error(),
                                                                   self.layout.set_dialog_sensitive()])
        self.layout.set_dialog_disabled()

    # Cashless amount
    def on_cashless_amount_add(self, dialog, amount):
        self.view.receipt.api('update', data={
            'cashless_amount': Decimal(amount.replace(',', '.'))
        }, on_error=lambda e: [self.view.application.show_network_error(), self.layout.set_dialog_sensitive()])
        self.layout.set_dialog_disabled()

    # Reimbursement
    def on_reimbursement_add(self, dialog, amount):
        self.view.receipt.api('update', data={
            'reimbursement': Decimal(amount.replace(',', '.'))
        }, on_error=lambda e: [self.view.application.show_network_error(), self.layout.set_dialog_sensitive()])
        self.layout.set_dialog_disabled()

    # Money box
    def on_to_money_box_add(self, dialog, amount):
        self.view.to_money_box = Decimal(amount.replace(',', '.'))
        self.view.from_money_box = None
        self.layout.calculate_money_box_transfer()

    def on_from_money_box_add(self, dialog, amount):
        self.view.from_money_box = Decimal(amount.replace(',', '.'))
        self.view.to_money_box = None
        self.layout.calculate_money_box_transfer()

    # Specials
    def on_client_notified(self, *args):
        if self.view.receipt.client:
            self.layout.set_notified_button_disabled()
            ClientNotifiedRequest(
                self.view.receipt.client.get('id'),
                on_success=self.on_client_notified_success,
                on_error=self.on_client_notified_error,
            )

    def on_client_notified_success(self, data):
        if self.view.receipt.client:
            self.view.receipt.client['specials'] = data
            self.layout.specials_model.clear()
            self.layout.fill_specials()

    def on_client_notified_error(self):
        self.layout.set_notified_button_sensitive()
        self.view.application.show_network_error()
