from gi.repository import GObject, Gtk, Pango, Gdk
from views.common import Handler


class ReceiptItemHandler(Handler):

    def on_searchentry_item_code_icon_release(self, entry, icon_pos, *args):
        if icon_pos == Gtk.EntryIconPosition.SECONDARY:
            entry.grab_focus()

    def on_search(self, *args):
        self.view.state.dispatch_search_request(self.layout.item_code)

    def on_radiobutton_count_toggled(self, button, *args):
        if button.get_active():
            self.view.state.dispatch_count_select()
        else:
            self.view.state.dispatch_units_select()

    def on_focus_count(self, widget, *args):
        if widget.get_sensitive():
            self.view.state.dispatch_count_select()
        else:
            self.view.state.dispatch_units_select()

    def on_focus_units(self, widget, *args):
        self.view.state.dispatch_units_select()

    def on_spinbutton_count_changed(self, widget, *args):
        value = widget.get_text()
        if value == '':
            value = 0
        self.view.state.dispatch_count_change(int(value))

    def on_spinbutton_units_changed(self, widget, *args):
        value = widget.get_text()
        if value == '':
            value = 0
        self.view.state.dispatch_units_change(int(value))

    def on_selection_changed(self, selection, *args):
        (model, iter) = selection.get_selected()
        if iter is not None:
            self.layout.selected_id = model[iter][0].get('id')
            self.layout.selected_total_units = model[iter][0].get('total_units')
            self.layout.selected_max_count = model[iter][0].get('full_items_count')
            self.layout.selected_max_units = model[iter][0].get('remaining_units')

            self.view.state.dispatch_prices_goods_code_select({
                'id': model[iter][0].get('id'),
                'units': model[iter][0].get('total_units'),
                'similar': model[iter][0].get('similar')
            })

            self.view.state.dispatch_count_set_max(model[iter][0].get('full_items_count'))
            self.layout.count = '1'
            self.view.state.dispatch_units_set_max(model[iter][0].get('remaining_units'))
            self.layout.units = '1'
            self.view.state.dispatch_count_select()

        else:
            self.layout.selected_id = None
            self.layout.selected_total_units = None
        return True

    def on_add(self, *args):
        if self.layout.btn_add.get_sensitive():
            correct = False
            selected_id = self.view.state.prices.get('selected_goods_code')['id']
            count = None
            units = None

            if self.view.state.count.get('selected'):
                count = self.view.state.count.get('number')
                units = self.view.state.prices.get('selected_goods_code')['units']
                correct = True
            elif self.view.state.units.get('selected'):
                count = 1
                units = self.view.state.units.get('number')
                correct = True

            if correct:
                self.emit('add', selected_id, count, units)
                self.widget.close()
