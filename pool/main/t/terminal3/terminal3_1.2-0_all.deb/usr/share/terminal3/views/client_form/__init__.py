from .view import ClientFromDialogView
