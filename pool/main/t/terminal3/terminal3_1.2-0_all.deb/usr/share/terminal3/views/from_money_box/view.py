from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import FromMoneyBoxDialogHandler
from .layout import FromMoneyBoxDialogLayout


class FromMoneyBoxDialogView(View):
    glade_file = 'from_money_box_dialog.glade'
    main_widget_id = 'dialog_from_money_box'

    event_handler_class = FromMoneyBoxDialogHandler
    layout_class = FromMoneyBoxDialogLayout

    __gsignals__ = {
        'add': (GObject.SIGNAL_RUN_FIRST, None, (str,)),
    }
