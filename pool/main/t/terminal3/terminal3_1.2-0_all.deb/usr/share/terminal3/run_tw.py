from application_tw import Application

Application()
