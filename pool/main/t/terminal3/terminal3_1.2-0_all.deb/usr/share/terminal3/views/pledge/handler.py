from views.client_not_found import ClientNotFoundDialogView
from views.common import Handler
from api.crm_info import GetCrmClientInfoRequest
from api.pledge_print import GetPledgeTextRequest, PrintPledgeRequest
from common.widget import number_input
from settings import config


class PledgeDialogHandler(Handler):
    def on_search(self, *args):
        if len(self.layout.client_code) == 13:
            self.layout.set_dialog_disabled()
            GetCrmClientInfoRequest(self.layout.client_code,
                                    on_success=self.on_search_success,
                                    on_error=self.on_search_error)

    def on_search_success(self, client):
        self.layout.client_fio = client.get('short_client_name', '')
        self.layout.client_phone = client.get('phones', '')
        self.layout.set_dialog_sensitive()
        self.layout.focus('entry_amount')

    def on_amount_activate(self, *args):
        self.on_print()

    def on_search_error(self, *args):
        try:
            err = args[0]
            if err.status == '404':
                if self.view.client_not_found_dialog is None:
                    self.view.client_not_found_dialog = ClientNotFoundDialogView(self.view.application)
                self.view.client_not_found_dialog.set_parent(self.view.widget())
                self.view.client_not_found_dialog.widget().show_all()
            else:
                self.view.application.show_network_error(self.view.widget())
        except Exception:
            self.view.application.show_network_error(self.view.widget())
        self.layout.set_dialog_sensitive()

    def on_insert_amount(self, entry, text, *args):
        number_input(entry, text, self.on_insert_amount)

    def on_print(self, *args):
        if config['print'].enabled:
            GetPledgeTextRequest(
                data={
                    'name': self.layout.client_fio,
                    'phone': self.layout.client_phone,
                    'amount': self.layout.client_amount,
                    'comment': self.layout.comment,
                },
                on_success=self.on_pledge_text_success,
                on_error=self.on_pledge_text_error
            )
            self.layout.set_dialog_disabled()

    def on_pledge_text_error(self, error):
        self.layout.set_dialog_sensitive()
        self.view.application.show_network_error()

    def on_pledge_text_success(self, data):
        PrintPledgeRequest(
            data.get('pledge').encode('utf8'),
            on_success=self.on_print_pledge_success,
            on_error=self.on_print_pledge_error
        )

    def on_print_pledge_success(self, data):
        self.layout.set_dialog_sensitive()
        self.widget.close()

    def on_print_pledge_error(self, error):
        self.layout.set_dialog_sensitive()
        self.view.application.show_network_error()

    def on_close(self, *args):
        self.widget.hide()
        return True
