from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import ClientNotFoundDialogHandler


class ClientNotFoundDialogView(View):
    glade_file = 'client_not_found_dialog.glade'
    main_widget_id = 'messagedialog1'

    event_handler_class = ClientNotFoundDialogHandler
