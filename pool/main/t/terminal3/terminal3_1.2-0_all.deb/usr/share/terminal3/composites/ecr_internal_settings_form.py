#!/usr/bin/env python

from __future__ import print_function

# This is only required to make the example with without requiring installation
# - Most of the time, you shouldn't use this hack
import sys
from os.path import join, dirname

sys.path.insert(0, join(dirname(__file__), '..', '..'))

import os
from gi.repository import Gtk, GdkPixbuf, GObject
from gi_composites import GtkTemplate
from settings import config


@GtkTemplate(ui='glade/composites/ecr_internal_settings_form.ui')
class EcrInternalSettingsFormBox(Gtk.Box):
    __gtype_name__ = 'EcrInternalSettingsFormBox'
    __gsignals__ = {
        'settings_changed': (GObject.SIGNAL_RUN_FIRST, None, (object,)),
    }

    initial_settings = {}

    addr, op_id, op_psswd, timeout, print_timeout, save_icon, save_button = GtkTemplate.Child().widgets(7)

    def __init__(self):
        super(Gtk.Box, self).__init__()

        # This must occur *after* you initialize your base
        self.init_template()

        svg_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
            os.path.join('data', 'svg', 'black', 'check.svg'),
            -1,
            16,
            True
        )
        self.save_icon.set_from_pixbuf(svg_pixbuf)

    def init_settings(self, cfg):
        self.initial_settings = cfg
        self.addr.set_text(cfg['addr'])
        self.op_id.set_text(cfg['op_id'])
        self.op_psswd.set_text(cfg['op_psswd'])
        self.timeout.set_text(cfg['timeout'])
        self.print_timeout.set_text(cfg['print_timeout'])
        self.save_button.set_sensitive(False)

    def get_settings(self):
        return {
            'addr': self.addr.get_text().strip(),
            'op_id': self.op_id.get_text().strip(),
            'op_psswd': self.op_psswd.get_text(),
            'timeout': self.timeout.get_text().strip(),
            'print_timeout': self.print_timeout.get_text().strip(),
        }

    @GtkTemplate.Callback
    def entry_changed(self, widget):
        if self.initial_settings == self.get_settings():
            self.save_button.set_sensitive(False)
        else:
            self.save_button.set_sensitive(True)

    @GtkTemplate.Callback
    def on_save_button_clicked(self, *args):
        self.emit('settings_changed', self.get_settings())
