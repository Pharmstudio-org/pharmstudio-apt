from views.common import Handler
from api.ecr.update_driver import EcrFetchDriver, EcrResetDriver


class SettingsDialogHandler(Handler):
    def on_menu_select(self, _, row):
        row.activate()

    def on_row_main_activate(self, *args):
        self.layout.stack.set_visible_child(self.layout.main_settings)

    def on_row_auth_activate(self, *args):
        self.layout.stack.set_visible_child(self.layout.auth_settings)

    def on_row_print_activate(self, *args):
        self.layout.stack.set_visible_child(self.layout.print_settings)

    def on_row_payment_activate(self, *args):
        self.layout.stack.set_visible_child(self.layout.payment_settings)

    def on_row_ecr_activate(self, *args):
        self.layout.stack.set_visible_child(self.layout.ecr_settings)

    def on_row_reimbursement_activate(self, *args):
        self.layout.stack.set_visible_child(self.layout.reimbursement_settings)

    def on_print_enabled_state_set(self, _, state):
        if state:
            self.layout.set_sensitive(*self.layout.print_widgets)
        else:
            self.layout.set_disabled(*self.layout.print_widgets)

    def on_ecr_enabled_state_set(self, _, state):
        if state:
            self.layout.set_sensitive(*self.layout.ecr_widgets)
        else:
            self.layout.set_disabled(*self.layout.ecr_widgets)

    def on_update_driver_button_clicked(self, *args):
        self.view.state.driver_update_success = False
        self.view.state.driver_update_in_progress = True

        def on_update_success(*args):
            self.view.state.driver_update_success = True
            self.view.state.driver_update_in_progress = False

        def on_error(*args):
            print(args)
            self.view.state.driver_update_success = False
            self.view.state.driver_update_in_progress = False
            self.view.application.show_network_error()

        def on_fetch_success(*args):
            EcrResetDriver(on_success=on_update_success, on_error=on_error)

        EcrFetchDriver(on_success=on_fetch_success, on_error=on_error)

    def on_close(self, *args):
        self.widget.hide()
        return True

    def on_save(self, *args):
        self.layout.save()
        self.widget.close()
        self.view.application.restart()
