from views.common import Layout, Binding, Widget


class FromMoneyBoxDialogLayout(Layout):
    amount = Binding('spinbutton_amount')
    entry_amount = Widget('spinbutton_amount')
    adjustment = Widget('adjustment1')

    _max_value = None

    @property
    def max_value(self):
        return self._max_value

    @max_value.setter
    def max_value(self, value):
        self._max_value = value
        self.adjustment.set_upper(value)

    def render(self, amount, max_value):
        self.entry_amount.set_value(amount)
        self.max_value = max_value

        self.focus(self.entry_amount)
