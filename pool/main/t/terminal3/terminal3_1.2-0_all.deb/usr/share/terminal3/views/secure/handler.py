from views.common import Handler


class SecureDialogHandler(Handler):
    def on_ok(self, *args):
        self.view.emit('show_settings')
        self.widget.close()

    def on_close(self, *args):
        self.widget.hide()
        return True

    def on_change(self, *args):
        if self.layout.secure_code == '7345':
            self.layout.set_dialog_sensitive()
        else:
            self.layout.set_dialog_disabled()
