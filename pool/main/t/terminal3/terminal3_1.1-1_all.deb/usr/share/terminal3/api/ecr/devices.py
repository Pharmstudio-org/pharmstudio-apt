from api.common import EcrRequest


class EcrDevicesRequest(EcrRequest):
    def get_args(self):
        return ['devices']
