from .view import FromMoneyBoxDialogView
