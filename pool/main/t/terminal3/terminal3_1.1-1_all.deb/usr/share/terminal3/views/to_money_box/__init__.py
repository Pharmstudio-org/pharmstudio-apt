from .view import ToMoneyBoxDialogView
