from gi.repository import GObject, Gtk, Pango
from views.common import Layout, Binding, Widget


class AddClientByPhoneDialogLayout(Layout):
    entry_client_phone = Widget('entry_client_phone')
    button_client_search = Widget('button_client_search')
    button_add = Widget('button_add')
    clients_treeview = Widget('clients_treeview')
    clients_selection = Widget('clients_selection')
    clients_selection_handler_id = None
    clients_loader = Widget('clients_loader')
    clients_error = Widget('clients_error')

    list_model = None

    renderers = {
        'phone': 'render_search_button',
        'clients': 'render_add_button_and_status',
        'client_list': 'render_results_list'
    }

    def build(self):
        self.list_model = Gtk.ListStore(int, str, str, str)
        self.clients_treeview.set_model(self.list_model)
        self.clients_treeview.append_column(
            Gtk.TreeViewColumn("ФІО", Gtk.CellRendererText(), text=2))
        self.clients_treeview.append_column(
            Gtk.TreeViewColumn("Телефон", Gtk.CellRendererText(), text=3))

        self.connect_state(self.view.state, self.renderers)

    def render(self):
        self.entry_client_phone.set_text('')
        self.focus('entry_client_phone')
        self.view.state.dispatch_clear_client_list()

        self.render_search_button(self.view.state)

    def render_search_button(self, state, *args):
        if len(state.phone) > 4:
            self.set_sensitive(self.button_client_search)
        else:
            self.set_disabled(self.button_client_search)

    def render_add_button_and_status(self, state, *args):
        if state.clients.get('selected_client_code'):
            self.set_sensitive(self.button_add)
        else:
            self.set_disabled(self.button_add)

        if state.clients.get('request'):
            self.show(self.clients_loader)
        else:
            self.hide(self.clients_loader)

        if state.clients.get('error'):
            self.show(self.clients_error)
        else:
            self.hide(self.clients_error)

    def render_results_list(self, state, *args):
        if self.clients_selection_handler_id is not None:
            self.clients_selection.disconnect(self.clients_selection_handler_id)
            self.clients_selection_handler_id = None

        self.list_model.clear()
        if len(state.client_list) > 0:
            for client in state.client_list:
                self.list_model.append([
                    client['id'],
                    client['code'],
                    client['short_client_name'],
                    client['phones'],
                ])
            if self.clients_selection_handler_id is None:
                self.clients_selection_handler_id = self.clients_selection.connect(
                    'changed', self.handler.on_clients_selection_changed)
