from views.common import Handler


class AddClientByPhoneDialogHandler(Handler):
    def on_add(self, *args):
        self.emit('add', self.view.state.clients.get('selected_client_code'))
        self.widget.close()

    def on_close(self, *args):
        self.widget.hide()
        return True

    def on_entry_client_phone_changed(self, entry):
        self.view.state.dispatch_phone_change(entry.get_text())

    def on_button_client_search_clicked(self, *args):
        self.view.state.dispatch_clients_search_request()

    def on_clients_selection_changed(self, selection, *args):
        (model, iter) = selection.get_selected()
        if iter is not None:
            self.view.state.dispatch_client_select(model[iter][1])
        else:
            self.view.state.dispatch_client_select(None)
