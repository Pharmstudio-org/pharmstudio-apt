from gi.repository import GObject
from api.item_code import ItemCodeRequest, ItemCodePriceRequest
from views.common import reset_state

defaults = {
    'search': {
        'request': False,
        'error': False,
    },
    'count': {
        'selected': True,
        'number': 1,
        'max': 1,
    },
    'units': {
        'selected': False,
        'number': 1,
        'max': 1,
    },
    'error_message': None,
    'receipt_item_list': [],
    'similar_item_list': [],
    'prices': {
        'selected_goods_code': {
            'id': None,
            'units': None,
        },
        'request': False,
        'error': False,
    },
    'prices_result': None,
}


class ReceiptItemState(GObject.Object):
    _state = dict(defaults)

    @GObject.Property(type=object)
    def search(self):
        return self._state['search']

    @search.setter
    def search(self, value):
        self._state['search'] = value

    @GObject.Property(type=object)
    def count(self):
        return self._state['count']

    @count.setter
    def count(self, value):
        self._state['count'] = value

    @GObject.Property(type=object)
    def units(self):
        return self._state['units']

    @units.setter
    def units(self, value):
        self._state['units'] = value

    @GObject.Property(type=object)
    def error_message(self):
        return self._state['error_message']

    @error_message.setter
    def error_message(self, value):
        self._state['error_message'] = value

    @GObject.Property(type=object)
    def receipt_item_list(self):
        return self._state['receipt_item_list']

    @receipt_item_list.setter
    def receipt_item_list(self, value):
        self._state['receipt_item_list'] = value

    @GObject.Property(type=object)
    def similar_item_list(self):
        return self._state['similar_item_list']

    @similar_item_list.setter
    def similar_item_list(self, value):
        self._state['similar_item_list'] = value

    @GObject.Property(type=object)
    def prices(self):
        return self._state['prices']

    @prices.setter
    def prices(self, value):
        self._state['prices'] = value

    @GObject.Property(type=object)
    def prices_result(self):
        return self._state['prices_result']

    @prices_result.setter
    def prices_result(self, value):
        self._state['prices_result'] = value

    def dispatch_state_reset(self):
        reset_state(self, defaults)

    def dispatch_search_success(self, result):
        self.search = dict(self.search, request=False, erorr=False)
        self.receipt_item_list = result

    def dispatch_search_error(self):
        self.search = dict(self.search, request=False, erorr=True)

    def dispatch_search_request(self, code):
        self.dispatch_state_reset()
        self.search = dict(self.search, request=True, error=False)
        ItemCodeRequest(
            code.replace('+', ''),
            on_success=lambda result: self.dispatch_search_success(result),
            on_error=lambda _: self.dispatch_search_error(),
        )

    def dispatch_count_select(self):
        self.units = dict(self.units, selected=False)
        self.count = dict(self.count, selected=True)
        self.dispatch_check_form_error()

    def dispatch_count_change(self, value):
        self.count = dict(self.count, number=value)
        self.dispatch_check_form_error()

    def dispatch_count_set_max(self, value):
        self.count = dict(self.count, max=value)
        self.dispatch_check_form_error()

    def dispatch_units_select(self):
        self.count = dict(self.count, selected=False)
        self.units = dict(self.units, selected=True)
        self.dispatch_check_form_error()

    def dispatch_units_change(self, value):
        self.units = dict(self.units, number=value)
        self.dispatch_check_form_error()

    def dispatch_units_set_max(self, value):
        self.units = dict(self.units, max=value)
        self.dispatch_check_form_error()

    def dispatch_set_form_error(self, message):
        self.error_message = message

    def dispatch_clear_form_error(self):
        self.error_message = None

    def dispatch_check_form_error(self):
        if self.count.get('selected'):
            if self.count.get('number') > self.count.get('max'):
                self.dispatch_set_form_error("Значення кількості\nбільше ніж %s" % str(self.count.get('max')))
            elif self.count.get('number') < 0:
                self.dispatch_set_form_error("Значення кількості\nменьше 0")
            elif self.count.get('number') == 0:
                self.dispatch_set_form_error("Значення кількості\nдорівнює 0")
            else:
                self.dispatch_clear_form_error()

        if self.units.get('selected'):
            if self.units.get('number') > self.units.get('max'):
                self.dispatch_set_form_error("Значення торг. од.\nбільше ніж %s" % str(self.units.get('max')))
            elif self.units.get('number') < 0:
                self.dispatch_set_form_error("Значення торг. од.\nменьше 0")
            elif self.units.get('number') == 0:
                self.dispatch_set_form_error("Значення торг. од.\nдорівнює 0")
            else:
                self.dispatch_clear_form_error()

    def dispatch_pices_success(self, result):
        self.prices = dict(self.prices, request=False, error=False)
        self.prices_result = result

    def dispatch_prices_error(self):
        self.prices = dict(self.prices, request=False, error=True)

    def dispatch_prices_goods_code_select(self, goods_code):
        self.prices = dict(self.prices, selected_goods_code=goods_code, request=True)
        self.similar_item_list = goods_code['similar']
        ItemCodePriceRequest(
            goods_code['id'],
            on_success=lambda result: self.dispatch_pices_success(result),
            on_error=lambda _: self.dispatch_prices_error(),
        )

    def dispatch_prices_goods_code_selection_clear(self):
        self.prices = dict(self.prices, selected_goods_code={'id': None, 'units': None}, request=False)
