from .view import ReceiptView
