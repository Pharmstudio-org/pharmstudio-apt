
from __future__ import print_function

# This is only required to make the example with without requiring installation
# - Most of the time, you shouldn't use this hack
import sys
from os.path import join, dirname

sys.path.insert(0, join(dirname(__file__), '..', '..'))

import os
from gi.repository import Gtk
from gi_composites import GtkTemplate


@GtkTemplate(ui='glade/composites/accounts_header.ui')
class AccountsHeaderBox(Gtk.Box):
    __gtype_name__ = 'AccountsHeaderBox'

    def __init__(self):
        super(Gtk.Box, self).__init__()
        self.init_template()
