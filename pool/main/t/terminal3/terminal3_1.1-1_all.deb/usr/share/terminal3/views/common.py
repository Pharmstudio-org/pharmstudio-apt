import six
from gi.repository import Gtk, GObject, GdkPixbuf
from six import string_types
import collections
import os
from copy import copy


def iterable(arg):
    return (
        isinstance(arg, collections.abc.Iterable) and not isinstance(arg, string_types)
    )


class Widget(object):
    key = None

    def __init__(self, key):
        self.key = key

    def __get__(self, instance, owner):
        return instance.obj(self.key)

    def __set__(self, instance, value):
        pass


class Binding(object):
    key = None

    def __init__(self, key):
        self.key = key

    def __get__(self, instance, owner):
        if isinstance(instance.obj(self.key), Gtk.Switch):
            return instance.obj(self.key).get_state()
        return instance.obj(self.key).get_text()

    def __set__(self, instance, value):
        if isinstance(instance.obj(self.key), Gtk.Switch):
            instance.obj(self.key).set_state(value)
        else:
            instance.obj(self.key).set_text(value)


class Layout(object):
    view = None
    icons = {}
    icons_small = {}
    icons_large = {}

    @property
    def widget(self):
        return self.view.widget()

    @property
    def handler(self):
        return self.view.handler()

    def __init__(self, view):
        self.view = view
        self.build()

    def obj(self, key):
        return self.view._builder.get_object(key)

    def focus(self, key):
        if isinstance(key, Gtk.Widget):
            key.grab_focus()
        else:
            self.obj(key).grab_focus()

    def set_svg(self, key, icon, height=24):
        if not isinstance(icon, string_types):
            height = icon[1]
            icon = icon[0]

        svg_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
            os.path.join('data', 'svg', 'black', icon + '.svg'),
            -1,
            height,
            True
        )
        self.obj(key).set_from_pixbuf(svg_pixbuf)

    def set_svg_small(self, key, icon):
        self.set_svg(key, icon, height=16)

    def set_svg_large(self, key, icon):
        self.set_svg(key, icon, height=32)

    @staticmethod
    def set_sensitive(*widgets):
        for widget in widgets:
            widget.set_sensitive(True)

    @staticmethod
    def set_disabled(*widgets):
        for widget in widgets:
            widget.set_sensitive(False)

    @staticmethod
    def hide(*widgets):
        for widget in widgets:
            widget.hide()

    @staticmethod
    def show(*widgets):
        for widget in widgets:
            widget.show()

    def build(self):
        for k, v in self.icons.items():
            self.set_svg(k, v)

        for k, v in self.icons_small.items():
            self.set_svg_small(k, v)

        for k, v in self.icons_large.items():
            self.set_svg_large(k, v)

    def render(self):
        pass

    def connect_state(self, state, renderers):
        for k, v in renderers.items():
            if iterable(v):
                for cb in v:
                    state.connect("notify::" + k.replace('_', '-'), getattr(self, cb))
            else:
                state.connect("notify::" + k.replace('_', '-'), getattr(self, v))


class Handler(object):
    view = None

    @property
    def widget(self):
        return self.view.widget()

    @property
    def layout(self):
        return self.view.layout()

    def emit(self, *args, **kwargs):
        self.view.emit(*args, **kwargs)

    def __init__(self, view):
        self.view = view


class View(GObject.GObject):
    glade_file = None
    main_widget_id = None

    state_class = None
    state = None

    layout_class = Layout
    _layout = None

    event_handler_class = None
    _event_handler = None

    _widget = None
    _builder = None
    application = None

    def __init__(self, application):
        GObject.GObject.__init__(self)
        self.application = application
        self.build()
        self.attach()

    def build(self):
        self._builder = Gtk.Builder()
        self._builder.add_from_file('glade/' + self.glade_file)

        if self.state_class:
            self.state = self.state_class()

        self._widget = self._builder.get_object(self.main_widget_id)

        self._layout = self.layout_class(self)

        if self.event_handler_class:
            self._event_handler = self.event_handler_class(self)
            self._builder.connect_signals(self._event_handler)
        else:
            self._builder.connect_signals(self)

    def set_parent(self, parent):
        if hasattr(parent, '_widget'):
            self._widget.set_transient_for(getattr(parent, '_widget'))
        else:
            self._widget.set_transient_for(parent)

    def attach(self):
        pass

    def widget(self):
        return self._widget

    def layout(self):
        return self._layout

    def handler(self):
        return self._event_handler


def reset_state(state, defaults):
    for k, v in defaults.items():
        setattr(state, k, copy(v))


class StateMixin(object):
    defaults = {}

    @classmethod
    def init(cls):
        defaults = dict(cls.defaults)

        def init_func(self):
            GObject.GObject.__init__(self)
            with self.freeze_notify():  # Set default for objects
                for k, v in defaults.items():
                    if not isinstance(v, six.string_types) and type(v) not in (int, bool, float):
                        setattr(self, k, v)

        arguments = {
            '__init__': init_func,
        }

        for k, v in defaults.items():
            if isinstance(v, six.string_types):
                arguments[k] = GObject.Property(type=str, default=v)
            elif type(v) in (int, bool, float):
                arguments[k] = GObject.Property(type=type(v), default=v)
            else:
                arguments[k] = GObject.Property()
        state_cls = type('State', (GObject.GObject, cls), arguments)

        return state_cls
