from api.common import EcrGitRequest


class EcrFetchDriver(EcrGitRequest):
    def get_args(self):
        return ['fetch']


class EcrResetDriver(EcrGitRequest):
    def get_args(self):
        return ['reset', '--hard', 'origin/master']
