from gi.repository import GObject, Gtk, Pango
import datetime
import uuid
from api.common import trace_error


class ApiMixin(object):
    api_methods = (
        #('method_name', RequestClass, ('param1', 'param2', ... ))
    )

    def api(self, method, data=None, **kwargs):
        for method_name, request_class, params in self.api_methods:
            if method_name == method:
                kw_values = {
                    'on_success': kwargs.get('on_success', getattr(self, 'on_' + method_name + '_success', lambda *args, **kwargs: None)),
                    'on_error': kwargs.get('on_error', getattr(self, 'on_' + method_name + '_error', trace_error)),
                    'data': data,
                }

                param_values = []
                for param in params:
                    param_values.append(getattr(self, param, None))
                request_class(*param_values, **kw_values)


class Model(ApiMixin, GObject.GObject):
    fields = []
    store_iter = None

    __gsignals__ = {
        'load': (GObject.SIGNAL_RUN_FIRST, None, ()),
        'update': (GObject.SIGNAL_RUN_FIRST, None, ()),
        'delete': (GObject.SIGNAL_RUN_FIRST, None, ()),
    }

    def __init__(self, *args, **kwargs):
        GObject.GObject.__init__(self)
        self._id = str(uuid.uuid4())
        self.load_from_dict(kwargs)

    def transform_field(self, field, field_type, value):
        if field_type.__name__ == 'datetime':
            return datetime.datetime.strptime(value.split('.')[0], '%Y-%m-%dT%H:%M:%S')
        return field_type(value)

    def as_dict(self):
        dct = {}
        for n, t, d in self.fields:
            dct[n] = getattr(self, n, None)
        return dct

    def load_from_dict(self, d):
        for field_key, field_type, field_default in self.fields:
            value = d.get(field_key, field_default)
            if value is not None:
                value = self.transform_field(field_key, field_type, value)
            setattr(self, field_key, value)
        self.emit('load')

    def update_from_dict(self, d):
        for field_key, field_type, field_default in self.fields:
            if field_key in d.keys():
                value = d.get(field_key, field_default)
                if value is not None:
                    value = self.transform_field(field_key, field_type, value)
                setattr(self, field_key, value)
        self.emit('update')

    def on_get_success(self, data):
        self.load_from_dict(data)

    def on_update_success(self, data):
        self.update_from_dict(data)

    def on_delete_success(self, data):
        self.emit('delete')


class TreeViewMixin(object):
    def prepare_col(self, col, field):
        pass

    def prepare_cell_renderer(self, renderer, field):
        pass

    def build_tree_columns(self, tree, field_list=None):
        complete_field_list = [f for f, t, l in self.table_columns]

        if field_list is None:
            field_list = complete_field_list
        else:
            field_list = [f for f in complete_field_list if f in field_list]

        #Exclude _id (start=1)
        for num, (f, t, l,) in enumerate(self.table_columns, start=1):
            if f in field_list:
                renderer = Gtk.CellRendererText()
                self.prepare_cell_renderer(renderer, f)
                col = Gtk.TreeViewColumn(l, renderer, text=num)
                self.prepare_col(col, f)
                tree.append_column(col)


class Collection(TreeViewMixin, ApiMixin, GObject.GObject):
    model_class = None
    internal_table_columns = (
        ('_id', str, None),
    )
    table_columns = ()
    _store = None
    _models = None

    __gsignals__ = {
        'fill': (GObject.SIGNAL_RUN_FIRST, None, ()),
        'clear': (GObject.SIGNAL_RUN_FIRST, None, ()),

        'create': (GObject.SIGNAL_RUN_FIRST, None, (Model,)),
        'load': (GObject.SIGNAL_RUN_FIRST, None, (Model,)),
        'update': (GObject.SIGNAL_RUN_FIRST, None, (Model,)),
        'delete': (GObject.SIGNAL_RUN_FIRST, None, (Model,)),
    }

    def __init__(self):
        self._models = []
        self._store = Gtk.ListStore(*self.get_store_types())
        GObject.GObject.__init__(self)

    def get_table_columns(self):
        return self.internal_table_columns + self.table_columns

    def store(self):
        return self._store

    def get(self, model_id):
        if isinstance(model_id, Gtk.TreeIter):
            model_id = self._store[model_id][0]
        for model in self._models:
            if model._id == model_id:
                return model
        return None

    def get_store_types(self):
        types = []

        for f, t, l in self.get_table_columns():
            if t.__name__ == 'unicode':
                types.append(str)
            else:
                types.append(t)
        return types

    def __iter__(self):
        return self._models.__iter__()

    def __len__(self):
        return self._models.__len__()

    def models(self):
        return self._models

    def as_store_row(self, model):
        return [t(getattr(model, f, None)) for f, t, l in self.get_table_columns()]

    def connect_model_signals(self, model):
        model.connect('load', self._model_load)
        model.connect('update', self._model_update)
        model.connect('delete', self._model_delete)

    def disconnect_model_signals(self, model):
        try:
            model.disconnect_by_func(self._model_load)
        except TypeError:
            print('Model load: already disconnected')
        try:
            model.disconnect_by_func(self._model_update)
        except TypeError:
            print('Model update: already disconnected')
        try:
            model.disconnect_by_func(self._model_delete)
        except TypeError:
            print('Model delete: already disconnected')

    def _append_model(self, model):
        self.connect_model_signals(model)
        model.store_iter = self._store.append(self.as_store_row(model))
        self._models.append(model)

    def _remove_model(self, model):
        self.disconnect_model_signals(model)
        if model.store_iter is not None:
            self._store.remove(model.store_iter)
        try:
            self._models.remove(model)
        except ValueError:
            pass

    def clear(self):
        for model in list(self._models):
            self._remove_model(model)
        self.emit('clear')

    def get_model(self, iter):
        for model in self._models:
            if iter == getattr(model, 'store_iter', None):
                return model
        return None

    def _model_load(self, model):
        self.emit('load', model)

    def _model_update(self, model):
        self.emit('update', model)

    def _model_delete(self, model):
        self._remove_model(model)
        self.emit('delete', model)

    def from_list(self, l):
        for item in l:
            model = self.model_class(**item)
            self._append_model(model)
        self.emit('fill')

    def on_list_success(self, data):
        self.from_list(data)

    def on_create_success(self, data):
        model = self.model_class(**data)
        self._append_model(model)
        self.emit('create', model)
