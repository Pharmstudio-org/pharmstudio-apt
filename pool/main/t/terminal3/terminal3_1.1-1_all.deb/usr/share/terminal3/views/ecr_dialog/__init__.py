from .view import EcrDialogView
