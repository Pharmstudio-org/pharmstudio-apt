import os
from shutil import copy
from common.config import BaseConfig, BASE_DIR_FOR_CONFIG

BASE_DIR = os.path.dirname(__file__)

SERVER_HOST = 'http://nasha.pharmstudio.com.ua'
DB_PATH = os.path.join(BASE_DIR, 'local_cache.db')
CHECK_CONNECTION_INTERVAL = 3000
CHECK_TABLET_CONNECTION_INTERVAL = 1500
CHECK_ESCPOS_CONNECTION_INTERVAL = 3000
ESCPOS_HOST = 'escpos.local'
ESCPOS_PORT = '8766'
RECEIPT_AUTO_PRINT = False
TABLET_IP = None
TABLET_PORT = None
ECR_ACCOUNTS_IN_ALLOWED = [1]


class MainConfig(BaseConfig):
    config_section = 'main'

    server_url = None
    check_connection_interval = None

    def load_section(self, section, default):
        key = 'ServerUrl'
        self.server_url = section.get(key, default.get(key, ''))

        key = 'CheckConnectionInterval'
        try:
            self.check_connection_interval = int(section.get(key, default[key]))
        except (ValueError, KeyError):
            self.check_connection_interval = 3000

    def save_section(self):
        return {
            'ServerUrl': self.server_url,
            'CheckConnectionInterval': str(self.check_connection_interval),
        }


class AuthConfig(BaseConfig):
    config_section = 'auth'

    drugstore_id = None
    api_user = None
    api_password = None
    account_to = None

    def load_section(self, section, default):
        key = 'DrugstoreId'
        try:
            self.drugstore_id = int(section.get(key, default[key]))
        except (KeyError, ValueError):
            self.drugstore_id = 0

        key = 'AccountTo'
        try:
            self.account_to = int(section.get(key, default[key]))
        except (KeyError, ValueError):
            self.account_to = 0

        key = 'ApiUser'
        self.api_user = section.get(key, default.get(key, ''))

        key = 'ApiPassword'
        self.api_password = section.get(key, default.get(key, ''))

    def save_section(self):
        return {
            'DrugstoreId': str(self.drugstore_id),
            'AccountTo': str(self.account_to),
            'ApiUser': self.api_user,
            'ApiPassword': self.api_password,
        }


class PrintConfig(BaseConfig):
    config_section = 'print'

    enabled = None
    server_url = None
    check_connection_interval = None
    auto_print = None

    def load_section(self, section, default):
        key = 'Enabled'
        self.enabled = section.get(key, default.get(key, '')) == 'yes'

        key = 'ServerUrl'
        self.server_url = section.get(key, default.get(key, ''))

        key = 'CheckConnectionInterval'
        try:
            self.check_connection_interval = int(section.get(key, default[key]))
        except (ValueError, KeyError):
            self.check_connection_interval = 3000

        key = 'AutoPrint'
        self.auto_print = section.get(key, default.get(key, '')) == 'yes'

    def save_section(self):
        return {
            'Enabled': 'yes' if self.enabled else 'no',
            'ServerUrl': self.server_url,
            'CheckConnectionInterval': str(self.check_connection_interval),
            'AutoPrint': 'yes' if self.auto_print else 'no',
        }


class PaymentConfig(BaseConfig):
    config_section = 'payment'

    enabled = None

    def load_section(self, section, default):
        key = 'Enabled'
        self.enabled = section.get(key, default.get(key, '')) == 'yes'

    def save_section(self):
        return {
            'Enabled': 'yes' if self.enabled else 'no',
        }


class EcrConfig(BaseConfig):
    config_section = 'ecr'

    enabled = None
    interpreter = None
    command = None
    config_path = None
    working_dir = None
    show_screen_info = None

    def __init__(self):
        if not os.path.exists(BASE_DIR_FOR_CONFIG):
            os.makedirs(BASE_DIR_FOR_CONFIG)

        default_ecr_conf_path = os.path.exists(os.path.join(BASE_DIR_FOR_CONFIG, 'ecr_config.ini'))
        if not default_ecr_conf_path:
            copy(os.path.join(BASE_DIR, 'ecr', 'ecr_config.ini'), BASE_DIR_FOR_CONFIG)
        super(EcrConfig, self).__init__()

    def load_section(self, section, default):
        key = 'Enabled'
        self.enabled = section.get(key, default.get(key, '')) == 'yes'

        key = 'Interpreter'
        self.interpreter = section.get(key, default.get(key, ''))

        key = 'Command'
        self.command = section.get(key, default.get(key, ''))

        key = 'Config'
        self.config_path = section.get(key, default.get(key, ''))
        if not self.config_path:
            self.config_path = os.path.join(BASE_DIR_FOR_CONFIG, 'ecr_config.ini')

        key = 'WorkingDir'
        self.working_dir = section.get(key, default.get(key, ''))

        key = 'ShowScreenInfo'
        self.show_screen_info = section.get(key, default.get(key, '')) == 'yes'

    def save_section(self):
        return {
            'Enabled': 'yes' if self.enabled else 'no',
            'Interpreter': self.interpreter,
            'Command': self.command,
            'Config': self.config_path,
            'WorkingDir': self.working_dir,
            'ShowScreenInfo': 'yes' if self.show_screen_info else 'no',
        }


class ReimbursementConfig(BaseConfig):
    config_section = 'reimbursement'
    enabled = None

    def load_section(self, section, default):
        key = 'Enabled'
        self.enabled = section.get(key, default.get(key, '')) == 'yes'

    def save_section(self):
        return {
            'Enabled': 'yes' if self.enabled else 'no',
        }


config = {
    'main': MainConfig(),
    'auth': AuthConfig(),
    'print': PrintConfig(),
    'payment': PaymentConfig(),
    'ecr': EcrConfig(),
    'reimbursement': ReimbursementConfig(),
}


def load_config():
    for c in config.values():
        c.load()


def save_config():
    for c in config.values():
        c.save()
