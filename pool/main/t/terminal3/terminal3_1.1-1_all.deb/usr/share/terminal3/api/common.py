from __future__ import print_function
from gi.repository import GObject
import os
import datetime
from twisted.internet.defer import inlineCallbacks
from twisted.web.error import Error
from twisted.internet.utils import getProcessOutput
import treq
import json

from settings import config


def url(url_name, url_type, *args):
    url_name = '/'.join([
        config['main'].server_url,
        str(config['auth'].drugstore_id),
        url_name
    ])
    if url_type in ('detail', 'update', 'delete',):
        url_name += "%d/"
        return url_name % args
    else:
        return url_name % args


def trace_error(error, **kwargs):
    if hasattr(error, 'response'):
        log_file = open("error(%s).html" % datetime.datetime.now().strftime("%Y-%m-%d %H-%M"), 'w')
        log_file.write(error.response.text.encode('utf-8'))
        log_file.close()


def raise_for_status(response):
    """Raises stored :class:`Error`, if one occurred."""
    http_error_msg = ''

    if 400 <= response.code < 500:
        http_error_msg = '%s Client Error: %s' % (response.code, response.phrase)

    elif 500 <= response.code < 600:
        http_error_msg = '%s Server Error: %s' % (response.code, response.phrase)

    if http_error_msg:
        raise Error(response.code, http_error_msg, response=response)


class BaseRequest(GObject.GObject):
    args = None
    on_success = None
    on_error = None
    data = None

    def __init__(self, *args, **kwargs):
        self.args = args
        self.on_success = kwargs.pop('on_success', lambda *args, **kwargs: None)
        self.on_error = kwargs.pop('on_error', lambda *args, **kwargs: None)
        self.on_both = kwargs.pop('on_both', lambda *args, **kwargs: None)

        self.data = kwargs.pop('data', {})

        self.make_request()

    def send(self):
        # Must return a deferred
        raise NotImplementedError

    def make_request(self):
        d = self.send()
        if d is not None:
            d.addCallback(self.prepare_result)
            d.addErrback(self.prepare_error)
            d.addBoth(self.on_both)

    def prepare_result(self, response):
        self.on_success(response)

    def prepare_error(self, error, *args, **kwargs):
        return self.on_error(error, *args, **kwargs)


class Request(BaseRequest):
    def get_result(self, result):
        self.on_success(result)

    def prepare_result(self, response):
        try:
            raise_for_status(response)
        except Error as e:
            self.prepare_error(e)
        else:
            treq.text_content(response).addCallback(self.get_result).addErrback(self.prepare_error)


class RequestJson(Request):
    def prepare_result(self, response):
        try:
            raise_for_status(response)
        except Error as e:
            self.prepare_error(e)
        else:
            if response.code != 204:
                treq.json_content(response).addCallback(self.get_result).addErrback(
                    lambda f: print(f.getTraceback(detail='verbose')))
            else:
                self.on_success(None)


class RequestCmd(BaseRequest):
    path = None

    def __init__(self, *args, **kwargs):
        self.path = kwargs.pop('path', self.path)
        super(RequestCmd, self).__init__(*args, **kwargs)

    def send(self):
        return getProcessOutput(self.args[0], *self.args, env=os.environ, path=self.path)

    def prepare_result(self, response):
        return self.on_success(response)

    @inlineCallbacks
    def make_request(self):
        try:
            res = yield self.send()
            self.prepare_result(res)
        except IOError as e:
            try:
                err = yield e.processEnded
                self.on_error(err)
            except Exception as ee:
                self.on_error(ee)
        except Exception as e:
            self.on_error(e)
        finally:
            self.on_both()


class EcrRequest(RequestCmd):
    def get_args(self):
        return ['-h']

    def base_args(self):
        args = [config['ecr'].command, '--json']
        if config['ecr'].config_path:
            args.append('-c')
            args.append(config['ecr'].config_path)
        return args

    def send(self):
        args = (self.base_args() + self.get_args())

        print(config['ecr'].interpreter)
        print(args)

        return getProcessOutput(
            config['ecr'].interpreter,
            args=args,
            env=os.environ,
            path=config['ecr'].working_dir,
        )

    def prepare_result(self, response):
        return self.on_success(json.loads(response))


class EcrGitRequest(EcrRequest):
    def send(self):
        return getProcessOutput(
            'git',
            args=self.get_args(),
            env=os.environ,
            path=config['ecr'].working_dir,
        )

    def prepare_result(self, response):
        return self.on_success(response)
