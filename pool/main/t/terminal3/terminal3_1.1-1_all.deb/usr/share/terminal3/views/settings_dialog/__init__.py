from .view import SettingsDialogView
