from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import AddClientByPhoneDialogHandler
from .layout import AddClientByPhoneDialogLayout
from .state import AddClientByPhoneState


class AddClientByPhoneDialogView(View):
    glade_file = 'add_client_by_phone_dialog.glade'
    main_widget_id = 'dialog_add_by_phone_client'

    event_handler_class = AddClientByPhoneDialogHandler
    layout_class = AddClientByPhoneDialogLayout
    state_class = AddClientByPhoneState

    __gsignals__ = {
        'add': (GObject.SIGNAL_RUN_FIRST, None, (str,)),
    }
