from gi.repository import GObject, Gtk, Pango
from decimal import Decimal
from views.common import Layout, Binding, Widget


class ReceiptItemLayout(Layout):
    list_model = Widget('list_store')
    similar_list_model = Widget('similar_list_store')

    tree_view_receipt_items = Widget('receipt_item_tree_view')
    selection_receipt_items = Widget('receipt_item_selection')
    selection_receipt_items_handler_id = None
    receipt_item_similar_tree_view = Widget('receipt_item_similar_tree_view')

    btn_search = Widget('button_search')
    searchentry_item_code = Widget('searchentry_item_code')
    btn_add = Widget('button_add')
    radio_count = Widget('radiobutton_count')
    spin_count = Widget('spinbutton_count')
    radio_units = Widget('radiobutton_units')
    spin_units = Widget('spinbutton_units')

    item_code = Binding('searchentry_item_code')
    searchentry_popover = Widget('searchentry_popover')
    count = Binding('spinbutton_count')
    units = Binding('spinbutton_units')

    prices_stack = Widget('prices_stack')
    prices_placeholder = Widget('prices_placeholder')
    prices_loader_box = Widget('prices_loader_box')
    prices_loader_box_spinner = Widget('prices_loader_box_spinner')
    prices_error_box = Widget('prices_error_box')
    prices_list_window = Widget('prices_list_window')
    prices_tree = Widget('prices_tree')
    prices_liststore = Widget('prices_liststore')

    form_error_box = Widget('form_error_box')
    form_error_label = Widget('form_error_label')

    selected_id = None
    selected_total_units = None
    selected_max_count = None
    selected_max_units = None

    sensitive_widgets = None

    renderers = {
        'search': ('render_search', 'render_actions',),
        'receipt_item_list': 'render_receipt_item_list',
        'similar_item_list': 'render_similar_item_list',
        'prices': ('render_prices', 'render_actions',),
        'prices_result': 'render_prices_result',
        'count': 'render_count',
        'units': 'render_units',
        'error_message': ('render_error_message', 'render_actions',)
    }

    def build(self):
        self.sensitive_widgets = (
            self.btn_add, self.radio_count, self.spin_count, self.radio_units,
            self.spin_units,
        )
        self.connect_state(self.view.state, self.renderers)

    def render(self):
        self.view.state.dispatch_state_reset()

        self.item_code = ''
        self.count = '1'
        self.units = '1'
        self.radio_count.set_active(True)
        self.focus('searchentry_item_code')

    def render_search(self, *args):
        search_state = self.view.state.search
        if search_state.get('request'):
            self.set_disabled(self.searchentry_item_code, self.btn_search)
        else:
            self.set_sensitive(self.searchentry_item_code, self.btn_search)

        if search_state.get('error'):
            self.view.application.show_network_error(self.view.widget())

    def render_receipt_item_list(self, *args):
        if self.selection_receipt_items_handler_id is not None:
            self.selection_receipt_items.disconnect(self.selection_receipt_items_handler_id)
            self.selection_receipt_items_handler_id = None
        self.view.state.dispatch_prices_goods_code_selection_clear()
        self.list_model.clear()
        self.similar_list_model.clear()

        if len(self.view.state.receipt_item_list) == 0:
            return

        first_iter = None
        for item in self.view.state.receipt_item_list:
            label = "%s/%s" % (str(item.get('remaining_units', 0)), str(item.get('total_units', 0)))
            model_iter = self.list_model.append((
                item,
                item.get('product_title', ''),
                item.get('full_items_count', ''),
                label,
            ))
            if first_iter is None:
                first_iter = model_iter

        if self.selection_receipt_items_handler_id is None:
            self.selection_receipt_items_handler_id = self.selection_receipt_items.connect(
                'changed', self.handler.on_selection_changed)

        if first_iter is not None:
            self.selection_receipt_items.select_iter(first_iter)

    def render_similar_item_list(self, *args):
        self.similar_list_model.clear()
        for item in self.view.state.similar_item_list:
            label = "%s/%s" % (str(item.get('remaining_units', 0)), str(item.get('total_units', 0)))
            self.similar_list_model.append((
                item.get('product_title', ''),
                item.get('full_items_count', ''),
                label,
            ))

    def render_prices(self, *args):
        prices_state = self.view.state.prices
        if not prices_state['selected_goods_code'].get('id'):
            self.prices_stack.set_visible_child(self.prices_placeholder)
        else:
            if prices_state.get('request'):
                self.prices_stack.set_visible_child(self.prices_loader_box)
                self.prices_loader_box_spinner.start()
            elif prices_state.get('error'):
                self.prices_stack.set_visible_child(self.prices_error_box)
                self.prices_loader_box_spinner.stop()
            else:
                self.prices_stack.set_visible_child(self.prices_list_window)
                self.prices_loader_box_spinner.stop()

    def render_prices_result(self, *args, **kwargs):
        if self.view.state.prices['selected_goods_code']['id']:
            model = self.prices_liststore
            model.clear()

            if self.view.state.prices_result.get('groups'):
                for group in self.view.state.prices_result['groups']:
                    model.append([
                        group.get('group', ''),
                        str(Decimal(group.get('price', 0)).quantize(Decimal('1.00'))),
                        str(Decimal(
                            group.get('price', 0) / self.view.state.prices['selected_goods_code']['units']
                        ).quantize(Decimal('1.00'))),
                    ])

    def render_count(self, *args):
        if self.view.state.count.get('selected'):
            self.spin_count.grab_focus()
        self.spin_count.set_range(1, self.view.state.count.get('max'))
        self.radio_count.set_active(self.view.state.count.get('selected'))

    def render_units(self, *args):
        self.spin_units.set_range(1, self.view.state.units.get('max'))
        self.radio_units.set_active(self.view.state.units.get('selected'))
        if self.view.state.units.get('selected'):
            self.spin_units.grab_focus()

    def render_error_message(self, *args):
        err_message = self.view.state.error_message
        if err_message:
            self.form_error_label.set_text(err_message)
            self.form_error_box.show()
        else:
            self.form_error_box.hide()

    def render_actions(self, *args):
        state = self.view.state
        if state.search.get('request') or state.search.get('error') or state.prices['selected_goods_code']['id'] is None:
            self.set_disabled(*self.sensitive_widgets)
        else:
            self.set_sensitive(*self.sensitive_widgets)

            if state.error_message:
                self.set_disabled(self.btn_add)
            else:
                self.set_sensitive(self.btn_add)
