import os

BASE_DIR_FOR_CONFIG = os.path.join(os.path.expanduser("~"), '.pharmstudio', 'terminal')

try:
    from configparser import ConfigParser
except ImportError:
    from ConfigParser import ConfigParser


class BaseConfig(object):
    config = None
    config_default = None

    config_section = None
    default_file_name = 'config_default.ini'
    main_file_name = os.path.join(BASE_DIR_FOR_CONFIG, 'config.ini')

    def __init__(self):
        self.config = ConfigParser()
        self.config_default = ConfigParser()
        self.load()

    def load(self):
        self.config.read(self.main_file_name)
        self.config_default.read(self.default_file_name)

        try:
            config_section = self.config[self.config_section]
        except KeyError:
            config_section = {}

        try:
            default_config_section = self.config_default[self.config_section]
        except KeyError:
            default_config_section = {}

        self.load_section(
            config_section,
            default_config_section,
        )

    def load_section(self, section, default):
        pass

    def save_section(self):
        return {}

    def save(self):
        self.config.read(self.main_file_name)
        self.config[self.config_section] = self.save_section()

        if not os.path.exists(BASE_DIR_FOR_CONFIG):
            os.makedirs(BASE_DIR_FOR_CONFIG)

        with open(self.main_file_name, 'w') as configfile:
            self.config.write(configfile)
