from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import AddClientDialogHandler
from .layout import AddClientDialogLayout


class AddClientDialogView(View):
    glade_file = 'add_client_dialog.glade'
    main_widget_id = 'dialog_add_client'

    event_handler_class = AddClientDialogHandler
    layout_class = AddClientDialogLayout

    __gsignals__ = {
        'add': (GObject.SIGNAL_RUN_FIRST, None, (str,)),
        'find-by-phone': (GObject.SIGNAL_RUN_FIRST, None, ()),
        'register-new-client': (GObject.SIGNAL_RUN_FIRST, None, ()),
    }
