from views.common import Handler


class AddCashlessAmountDialogHandler(Handler):
    def on_add(self, *args):
        self.emit('add', self.layout.amount)
        self.widget.close()

    def on_close(self, *args):
        self.widget.hide()
        return True
