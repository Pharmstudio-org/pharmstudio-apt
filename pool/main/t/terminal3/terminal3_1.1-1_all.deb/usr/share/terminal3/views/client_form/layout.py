from gi.repository import GObject, Gtk, GdkPixbuf, Pango
from views.common import Layout, Binding, Widget as W


class ClientFormDialogLayout(Layout):
    last_name_entry = W('last_name_entry')
    last_name_error = W('last_name_error')
    first_name_entry = W('first_name_entry')
    first_name_error = W('first_name_error')
    middle_name_entry = W('middle_name_entry')
    middle_name_error = W('middle_name_error')
    primary_phone_entry = W('primary_phone_entry')
    primary_phone_error = W('primary_phone_error')
    secondary_phone_entry = W('secondary_phone_entry')
    secondary_phone_error = W('secondary_phone_error')
    card_entry = W('card_entry')
    card_error = W('card_error')

    request_box = W('request_box')
    request_spinner = W('request_spinner')
    request_label = W('request_label')

    register_client_button = W('register_client_button')
    save_button = W('save_button')
    close_button = W('close_button')

    renderers = {
        'form_errors': ('render_form_errors', 'render_actions'),
        'form_data': 'render_form_data',
        'client': ('render_client_data', 'render_client_request', 'render_actions'),
        'show_network_error': 'render_network_error',
        'emit_add_client_signal': 'render_add_client_signal',
    }

    action_widgets = None

    def build(self):
        self.action_widgets = [self.register_client_button, self.save_button]
        self.form_entries = [self.last_name_entry, self.first_name_entry,
                             self.middle_name_entry, self.primary_phone_entry,
                             self.secondary_phone_entry, self.card_entry]
        self.connect_state(self.view.state, self.renderers)

    def render(self, client_id=None):
        if client_id is None:
            self.render_client_data(self.view.state)
            self.view.state.dispatch_validate()
            self.last_name_entry.grab_focus()
        else:
            self.view.state.dispatch_client_details_request(client_id)

    def render_form_errors(self, state, *args):
        err_state = state.form_errors
        for key, error in err_state.items():
            error_entry = getattr(self, key + '_entry')
            error_label = getattr(self, key + '_error')
            if error:
                error_entry.set_icon_from_pixbuf(
                    Gtk.EntryIconPosition.SECONDARY,
                    GdkPixbuf.Pixbuf.new_from_file('data/fa/grey/16/times-circle.png')
                )
                error_label.set_text(error)
            else:
                error_entry.set_icon_from_pixbuf(Gtk.EntryIconPosition.SECONDARY, None)
                error_label.hide()

    def render_actions(self, state, *args):
        if state.has_errors() or not state.client['ready']:
            self.set_disabled(*self.action_widgets)
        else:
            self.set_sensitive(*self.action_widgets)
            
    def render_form_data(self, state, *args):
        fd = state.form_data
        self.last_name_entry.set_text(fd['last_name'])
        self.first_name_entry.set_text(fd['first_name'])
        self.middle_name_entry.set_text(fd['middle_name'])
        self.primary_phone_entry.set_text(fd['primary_phone'])
        self.secondary_phone_entry.set_text(fd['secondary_phone'])
        self.card_entry.set_text(fd['card'])
        
    def render_client_data(self, state, *args):
        if state.client['id'] is None:
            self.register_client_button.show()
            self.save_button.hide()
        else:
            self.register_client_button.hide()
            self.save_button.show()
            
    def render_client_request(self, state, *args):
        if state.client['ready']:
            self.set_sensitive(*self.form_entries)
            self.request_spinner.stop()
            self.request_box.hide()
        else:
            self.set_disabled(*self.form_entries)
            self.request_spinner.start()
            self.request_box.show()
        
    def render_network_error(self, state, *args):
        if state.show_network_error:
            self.view.application.show_network_error()

    def render_add_client_signal(self, state, *args):
        if state.emit_add_client_signal:
            self.view.emit('add', state.client['data']['card'])
            self.view.widget().close()