from decimal import Decimal, InvalidOperation
from gi.repository import GObject, Gtk, Gdk, Pango
from views.common import Layout, Binding, Widget
from api.tablet import UpdateTabletInfoRequest
from settings import config


class ReceiptLayout(Layout):
    _dialog_sensitive = None
    specials_model = None

    tree_view_receipt = Widget('receipt_tree_view')
    label_total = Widget('label_total')
    tree_view_specials = Widget('treeview_specials')
    button_client_notified = Widget('button_notified')

    # total info
    receipt_title = Binding('label_receipt_title')
    total = Binding('label_total')
    back = Binding('label_back')
    entry = Binding('spinbutton_entry')
    cashless_amount = Binding('label_cashless')
    reimbursement = Binding('label_reimbursement')

    # client info
    client_name = Binding('label_client_name')
    client_rating = Binding('label_client_rating')
    client_discount = Binding('label_client_discount')

    _client_money_box = None
    _client_money_box_bind = Binding('label_client_money_box')

    # tablet_info
    prev_sum = None
    prev_money_box = None

    @property
    def client_money_box(self):
        return self._client_money_box

    @client_money_box.setter
    def client_money_box(self, value):
        if value:
            self._client_money_box = Decimal(value)
            self._client_money_box_bind = str(self._client_money_box)
        else:
            self._client_money_box = None
            self._client_money_box_bind = ''

    _client_money_box_transfer = None
    _client_money_box_transfer_bind = Binding('label_client_money_box_transfer')

    @property
    def client_money_box_transfer(self):
        return self._client_money_box_transfer

    @client_money_box_transfer.setter
    def client_money_box_transfer(self, value):
        if value:
            self._client_money_box_transfer = Decimal(value)
            sign = '+'
            if self._client_money_box_transfer < 0:
                sign = ''
            self._client_money_box_transfer_bind = ''.join([
                '(', sign, str(self._client_money_box_transfer).replace('.', ','), ')'
            ])
        else:
            self._client_money_box_transfer = None
            self._client_money_box_transfer_bind = ''

    # main buttons
    btn_receipt_close = Widget('button_receipt_close')
    btn_receipt_cancel = Widget('button_receipt_cancel')
    btn_receipt_add = Widget('button_receipt_add')
    btn_receipt_remove = Widget('button_receipt_remove')
    btn_receipt_add_card = Widget('button_card_add')
    btn_receipt_print = Widget('button_receipt_print')
    btn_receipt_ecr = Widget('button_receipt_ecr')

    # info buttons
    btn_add_cashless_amount = Widget('button_add_cashless_amount')
    btn_add_reimbursement = Widget('button_add_reimbursement')

    # client buttons
    btn_client_remove = Widget('button_client_remove')

    # money box buttons
    btn_reset_money_box = Widget('button_reset_money_box')
    btn_from_money_box = Widget('button_from_money_box')
    btn_to_money_box = Widget('button_to_money_box')

    def tablet_info_is_updated(self, new_info):
        return (new_info.get('sum', None) != self.prev_sum) or (new_info.get('money_box', None) != self.prev_money_box)

    def update_tablet_info(self, *args, **kwargs):
        data = {'sum': self.total}
        if self.client_money_box:
            data['money_box'] = self.client_money_box

        if self.tablet_info_is_updated(data):
            self.prev_sum = data.get('sum', None)
            self.prev_money_box = data.get('money_box', None)
            UpdateTabletInfoRequest(data=data)

    def title_render(self, tree_column, cell, tree_model, iter, data):
        title, maker, new = tree_model.get(iter, 1, 2, 3)
        cell.props.text = title
        if new:
            cell.props.weight = 700
        else:
            cell.props.weight = 400

        tooltip = Gtk.Tooltip()
        tooltip.set_text(maker)
        self.tree_view_specials.set_tooltip_cell(tooltip, None, tree_column, cell)

    def build(self):
        self.specials_model = Gtk.TreeStore(int, str, str, bool)
        self.tree_view_specials.set_model(self.specials_model)

        title_cell = Gtk.CellRendererText()
        title_cell.set_property('ellipsize', Pango.EllipsizeMode.END)
        title_col = Gtk.TreeViewColumn("Назва", title_cell, text=1)
        title_col.set_expand(True)
        title_col.set_cell_data_func(title_cell, self.title_render)

        self.tree_view_specials.append_column(title_col)

        label_cell = Gtk.CellRendererText()
        value_col = Gtk.TreeViewColumn("", label_cell, text=2)
        # value_col.set_widget(Gtk.Button.new_with_label("Click Me"))
        self.tree_view_specials.append_column(value_col)

        self.btn_receipt_add.add_accelerator(
            "clicked", self.view.application.accel_group, Gdk.KEY_KP_Add, 0, Gtk.AccelFlags.VISIBLE)

        self.btn_receipt_add_card.add_accelerator(
            "clicked", self.view.application.accel_group, Gdk.KEY_KP_Multiply, 0, Gtk.AccelFlags.VISIBLE)

        self.btn_add_cashless_amount.add_accelerator(
            "clicked", self.view.application.accel_group, Gdk.KEY_KP_Divide, 0, Gtk.AccelFlags.VISIBLE)

        self.label_total.connect('draw', self.update_tablet_info)
        if config['ecr'].enabled:
            self.btn_receipt_ecr.show()
        else:
            self.btn_receipt_ecr.hide()

        if config['payment'].enabled:
            self.btn_add_cashless_amount.show()
        else:
            self.btn_add_cashless_amount.hide()

        if config['reimbursement'].enabled:
            self.btn_add_reimbursement.show()
        else:
            self.btn_add_reimbursement.hide()

    def render(self):
        self.receipt_title += ' ' + str(self.view.receipt.id)
        self.fill_info()
        self.fill_client()
        self.tree_view_receipt.set_model(self.view.receipt_item_collection.store())
        self.view.receipt_item_collection.build_tree_columns(self.tree_view_receipt)

    def dialog_sensitive(self):
        return self._dialog_sensitive

    def set_dialog_sensitive(self, *args):
        self._dialog_sensitive = True

        if self.view.receipt.closed:
            self.hide(self.btn_receipt_close)
        else:
            self.show(self.btn_receipt_close)

        if self.view.receipt.canceled or self.view.receipt.closed:
            self.set_disabled(self.btn_receipt_cancel, self.btn_receipt_close, self.btn_receipt_add,
                              self.btn_receipt_remove, self.btn_receipt_add_card, self.btn_client_remove,
                              self.btn_reset_money_box, self.btn_from_money_box, self.btn_to_money_box)
        else:
            self.set_sensitive(self.btn_receipt_cancel, self.btn_receipt_add, self.btn_client_remove,
                               self.btn_receipt_add_card)

            if self.view.receipt.client:
                self.set_sensitive(self.btn_client_remove)

                # Money box
                if self.total and Decimal(self.total):
                    self.set_sensitive(self.btn_to_money_box)

                    if self.client_money_box:
                        self.set_sensitive(self.btn_from_money_box)
                    else:
                        self.set_disabled(self.btn_from_money_box)

                    if self.view.to_money_box:
                        self.set_disabled(self.btn_from_money_box)
                    if self.view.from_money_box:
                        self.set_disabled(self.btn_to_money_box)

                else:
                    # Reset transfers
                    self.view.from_money_box = None
                    self.view.to_money_box = None
                    self.calculate_money_box_transfer(silent=True)
                    self.set_disabled(self.btn_to_money_box, self.btn_from_money_box)

                if self.client_money_box_transfer:
                    self.set_sensitive(self.btn_reset_money_box)
                else:
                    self.set_disabled(self.btn_reset_money_box)

            else:
                self.set_disabled(self.btn_reset_money_box, self.btn_from_money_box, self.btn_to_money_box)

            if len(self.view.receipt_item_collection) == 0:
                self.set_disabled(self.btn_receipt_close)
            else:
                if self.view.selected_receipt_item is not None:
                    self.set_sensitive(self.btn_receipt_remove)
                else:
                    self.set_disabled(self.btn_receipt_remove)

                self.set_sensitive(self.btn_receipt_close)

    def set_dialog_disabled(self, *args):
        self._dialog_sensitive = False

        if self.view.receipt.closed:
            self.hide(self.btn_receipt_close)
        else:
            self.show(self.btn_receipt_close)

        self.set_disabled(self.btn_receipt_close, self.btn_receipt_cancel,
                          self.btn_receipt_add_card, self.btn_receipt_add, self.btn_receipt_remove,
                          self.btn_client_remove, self.btn_reset_money_box, self.btn_from_money_box,
                          self.btn_to_money_box)

    def set_notified_button_disabled(self):
        self.set_disabled(self.button_client_notified)

    def set_notified_button_sensitive(self):
        new_exists = False
        if self.view.receipt.client:
            for special in self.view.receipt.client.get('specials'):
                if special.get('is_new', False):
                    new_exists = True
        if new_exists:
            self.set_sensitive(self.button_client_notified)
        else:
            self.set_disabled(self.button_client_notified)

    def calculate_total(self, *args):
        self.total = str(self.view.get_total_with_money_box())

    def calculate_back(self, *args):
        entry_text = self.entry.replace(',', '.')
        try:
            entry = Decimal(entry_text)
        except InvalidOperation:
            entry = 0

        #total = self.view.get_total()
        total = self.view.get_total_with_money_box()
        back = (Decimal(entry) - total + self.view.receipt.cashless_amount).quantize(Decimal('1.00'))
        if back < 0:
            self.back = ''
        else:
            self.back = str(back)

    def calculate_money_box_transfer(self, silent=False):
        if self.view.to_money_box is None and self.view.from_money_box is None:
            self.client_money_box_transfer = ''
        else:
            if self.view.to_money_box:
                self.client_money_box_transfer = self.view.to_money_box
            if self.view.from_money_box:
                self.client_money_box_transfer = self.view.from_money_box * -1

        self.calculate_total()
        self.calculate_back()

        if not silent:
            self.set_dialog_sensitive()

    def fill_info(self, *args):
        self.cashless_amount = str(self.view.receipt.cashless_amount)
        self.reimbursement = str(self.view.receipt.reimbursement)
        self.calculate_total()
        self.calculate_back()

    def fill_client(self, *args):
        client = self.view.receipt.client
        self.specials_model.clear()
        if client:
            self.fill_specials()
            self.client_name = client.get('short_client_name', '')
            self.client_discount = client.get('discount', '')
            self.client_rating = client.get('rating', '')
            self.client_money_box = client.get('money_box', '')
            self.show(self.btn_client_remove)
        else:
            self.client_name = ''
            self.client_discount = ''
            self.client_rating = ''
            self.client_money_box = ''
            self.hide(self.btn_client_remove)
            self.set_notified_button_disabled()

    def fill_specials(self, *args):
        for special in self.view.receipt.client.get('specials', []):
            special_amount = special.get('value', '0')
            if special_amount.endswith('.00'):
                special_amount = special_amount.replace('.00', '')
            if special.get('type') == 'discount':
                special_amount += '%'

            iter = self.specials_model.append(None, (
                special.get('id', 0),
                special.get('product_title', ''),
                special_amount,
                special.get('is_new', False),
            ))
        self.set_notified_button_sensitive()
