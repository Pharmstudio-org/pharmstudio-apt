from gi.repository import GObject
from api.check_connection import CheckConnectionRequest, CheckTabletConnectionRequest, CheckEscposConnectionRequest
from settings import CHECK_TABLET_CONNECTION_INTERVAL, config


class ConnectionMonitor(GObject.GObject):
    _is_running = False
    connection_status = GObject.property(type=str, default='not available')

    __gsignals__ = {
        'connection_changed': (GObject.SIGNAL_RUN_FIRST, None,
                               (str,))
    }

    def __init__(self):
        GObject.GObject.__init__(self)

    def get_interval(self):
        return config['main'].check_connection_interval

    def make_request(self):
        if self._is_running:
            CheckConnectionRequest(on_success=self.on_success, on_error=self.on_error)
        return False

    def on_success(self, *args, **kwargs):
        if self.connection_status != 'available':
            self.set_property('connection_status', 'available')
            self.emit('connection_changed', self.get_property('connection_status'))
        if self._is_running:
            GObject.timeout_add(self.get_interval(), self.make_request)

    def on_error(self, e):
        if self.connection_status != 'not available':
            self.set_property('connection_status', 'not available')
            self.emit('connection_changed', self.get_property('connection_status'))
        if self._is_running:
            GObject.timeout_add(self.get_interval(), self.make_request)

    def run(self):
        self._is_running = True
        self.make_request()

    def stop(self):
        self._is_running = False


class TabletConnectionMonitor(ConnectionMonitor):
    def get_interval(self):
        return CHECK_TABLET_CONNECTION_INTERVAL

    def make_request(self):
        if self._is_running:
            CheckTabletConnectionRequest(on_success=self.on_success, on_error=self.on_error)
        return False


class EscposConnectionMonitor(ConnectionMonitor):
    def get_interval(self):
        return config['print'].check_connection_interval

    def make_request(self):
        if self._is_running:
            CheckEscposConnectionRequest(on_success=self.on_success, on_error=self.on_error)
        return False
