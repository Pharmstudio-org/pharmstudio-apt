from .view import PledgeDialogView
