from views.common import Handler
from decimal import Decimal


class FromMoneyBoxDialogHandler(Handler):
    def on_add(self, *args):
        amount = self.layout.amount
        if Decimal(amount.replace(',', '.')) > self.layout.max_value:
            self.emit('add', str(self.layout.max_value).replace('.', ','))
        else:
            self.emit('add', self.layout.amount)
        self.widget.close()

    def on_close(self, *args):
        self.widget.hide()
        return True
