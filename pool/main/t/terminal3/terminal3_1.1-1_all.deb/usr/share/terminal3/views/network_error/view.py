from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import NetworkErrorDialogHandler


class NetworkErrorDialogView(View):
    glade_file = 'network_error_dialog.glade'
    main_widget_id = 'messagedialog1'

    event_handler_class = NetworkErrorDialogHandler
