from .view import AddCashlessAmountDialogView
