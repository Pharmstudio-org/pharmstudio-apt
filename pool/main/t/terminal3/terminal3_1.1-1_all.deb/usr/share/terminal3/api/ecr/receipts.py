import decimal
import json
from api.common import EcrRequest


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        return super(DecimalEncoder, self).default(o)


class EcrReceiptsCopyRequest(EcrRequest):
    def get_args(self):
        return ['chk_copy']


class EcrReceiptRequest(EcrRequest):
    def get_args(self):
        return ['chk', self.args[0]]
