from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import SettingsDialogHandler
from .layout import SettingsDialogLayout
from .state import SettingsDialogState


class SettingsDialogView(View):
    glade_file = 'settings.glade'
    main_widget_id = 'window_settings'

    event_handler_class = SettingsDialogHandler
    layout_class = SettingsDialogLayout
    state_class = SettingsDialogState

    selected_menu_row = None

    def build(self):
        super(SettingsDialogView, self).build()
