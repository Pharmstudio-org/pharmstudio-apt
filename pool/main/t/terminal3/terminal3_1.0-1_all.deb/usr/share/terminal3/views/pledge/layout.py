from views.common import Layout, Binding, Widget


class PledgeDialogLayout(Layout):
    se_code = Widget('searchentry_code')
    e_fio = Widget('entry_fio')
    e_phone = Widget('entry_phone')
    e_amount = Widget('entry_amount')
    e_comment = Widget('entry_comment')

    client_code = Binding('searchentry_code')
    client_fio = Binding('entry_fio')
    client_phone = Binding('entry_phone')
    client_amount = Binding('entry_amount')
    comment = Binding('entry_comment')

    _dialog_sensitive = None

    def render(self):
        self.set_dialog_sensitive()
        self.client_code = ''
        self.client_fio = ''
        self.client_phone = ''
        self.client_amount = ''
        self.comment = ''
        self.focus('searchentry_code')

    def dialog_sensitive(self):
        return self._dialog_sensitive

    def set_dialog_sensitive(self, *args):
        self._dialog_sensitive = True
        self.set_sensitive(self.se_code, self.e_fio, self.e_phone, self.e_amount, self.e_comment)

    def set_dialog_disabled(self, *args):
        self._dialog_sensitive = False
        self.set_disabled(self.se_code, self.e_fio, self.e_phone, self.e_amount, self.e_comment)
