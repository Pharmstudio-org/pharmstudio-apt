import api
from settings import TABLET_IP, TABLET_PORT, config
import treq

URL = ''


class CheckConnectionRequest(api.Request):
    def send(self):
        return treq.get(
            api.url(URL, 'list'),
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=2
        )


class CheckTabletConnectionRequest(api.Request):
    def send(self):
        if TABLET_IP and TABLET_PORT:
            return treq.get('http://' + TABLET_IP + ':' + TABLET_PORT, params=self.data, timeout=2)
        else:
            return None


class CheckEscposConnectionRequest(api.Request):
    def send(self):
        if config['print'].enabled:
            return treq.get(config['print'].server_url, params=self.data, timeout=2)
        else:
            return None
