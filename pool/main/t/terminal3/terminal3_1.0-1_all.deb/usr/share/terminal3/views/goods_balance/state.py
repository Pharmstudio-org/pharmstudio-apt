from gi.repository import GObject
from api.item_code import ItemCodePriceRequest

defaults = {
    'prices': {
        'selected_goods_code': {
            'id': None,
            'units': None,
        },
        'request': False,
        'error': False,
    },
    'prices_result': None,
    'item_code_list_ready': False,
}


class GoodsBalanceState(GObject.Object):
    _state = defaults

    @GObject.Property(type=bool, default=defaults['item_code_list_ready'])
    def item_code_list_ready(self):
        return self._state['item_code_list_ready']

    @item_code_list_ready.setter
    def item_code_list_ready(self, value):
        self._state['item_code_list_ready'] = value

    @GObject.Property(type=object)
    def prices(self):
        return self._state['prices']

    @prices.setter
    def prices(self, value):
        self._state['prices'] = value

    @GObject.Property(type=object)
    def prices_result(self):
        return self._state['prices_result']

    @prices_result.setter
    def prices_result(self, value):
        self._state['prices_result'] = value

    def dispatch_pices_success(self, result):
        self.prices = dict(self.prices, request=False, error=False)
        self.prices_result = result

    def dispatch_prices_error(self):
        self.prices = dict(self.prices, request=False, error=True)

    def dispatch_prices_goods_code_select(self, goods_code):
        self.prices = dict(self.prices, selected_goods_code=goods_code, request=True)
        ItemCodePriceRequest(
            goods_code['id'],
            on_success=lambda result: self.dispatch_pices_success(result),
            on_error=lambda _: self.dispatch_prices_error(),
        )

    def dispatch_prices_goods_code_selection_clear(self):
        self.prices = dict(self.prices, selected_goods_code={'id': None, 'units': None}, request=False)

    def dispatch_item_code_list_ready(self, ready_state):
        self.item_code_list_ready = ready_state
