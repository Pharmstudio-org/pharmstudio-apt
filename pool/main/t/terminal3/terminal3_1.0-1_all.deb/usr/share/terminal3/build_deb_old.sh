#!/bin/bash

PACKAGE_NAME="terminal3"
VERSION="1.0-1"

BASEDIR=$(dirname "$0")
FULLNAME="${PACKAGE_NAME}_${VERSION}"
DIST_DIR=${BASEDIR}/deb

PYINSTALLER=${BASEDIR}/.env/bin/pyinstaller
RUN=${BASEDIR}/run_tw.py

if [ $UID != 0 ]; then
    echo "Please run this script with sudo:"
    echo "sudo $0 $*"
    exit 1
fi

if [ -d $DIST_DIR ]; then rm -Rf $DIST_DIR; fi

mkdir $DIST_DIR
mkdir ${DIST_DIR}/${FULLNAME}
mkdir ${DIST_DIR}/${FULLNAME}/usr
mkdir ${DIST_DIR}/${FULLNAME}/usr/bin
mkdir ${DIST_DIR}/${FULLNAME}/usr/lib

${PYINSTALLER} ${RUN} --add-data glade:glade --add-data data:data --add-data Terminal.desktop:. --add-data config_default.ini:. --add-data ecr:ecr -n ${PACKAGE_NAME} --noconfirm
cp -r ${BASEDIR}/dist/${PACKAGE_NAME} ${DIST_DIR}/${FULLNAME}/usr/lib/

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/usr/bin/${PACKAGE_NAME}
#!/bin/sh
cd /usr/lib/${PACKAGE_NAME}
/usr/lib/${PACKAGE_NAME}/${PACKAGE_NAME}
exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/usr/bin/${PACKAGE_NAME}

mkdir ${DIST_DIR}/${FULLNAME}/DEBIAN

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/DEBIAN/control
Package: ${PACKAGE_NAME}
Version: ${VERSION}
Section: base
Priority: optional
Architecture: amd64
Maintainer: Valentin Osipenko <valtron.forever@gmail.com>
Depends: python3-gi-cairo
Description: Pharmstudio terminal
 Goods selling tool connected to pharmstudio.com.ua
EOF

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/DEBIAN/postinst
#!/bin/sh
sudo -u \${SUDO_USER} xdg-desktop-icon install --novendor /usr/lib/${PACKAGE_NAME}/Terminal.desktop
exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/DEBIAN/postinst

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/DEBIAN/prerm
#!/bin/sh
xdg-desktop-icon uninstall Terminal.desktop
rm /usr/bin/${PACKAGE_NAME}
exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/DEBIAN/prerm

cd $DIST_DIR
dpkg-deb --build $FULLNAME

cd ..
rm -rf ${BASEDIR}/build
rm -rf ${BASEDIR}/dist
chown -R $SUDO_USER.$SUDO_USER ${DIST_DIR}

