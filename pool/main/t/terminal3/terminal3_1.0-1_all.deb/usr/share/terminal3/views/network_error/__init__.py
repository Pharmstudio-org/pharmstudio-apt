from .view import NetworkErrorDialogView
