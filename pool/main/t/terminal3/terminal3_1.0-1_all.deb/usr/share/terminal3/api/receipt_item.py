import api
from settings import config
import treq

URL = "sales/api/receipts/%d/items/"


class ReceiptItemListRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(URL, 'list', self.args[0]),
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5,
        )


class ReceiptItemCreateRequest(api.RequestJson):
    def send(self):
        return treq.post(
            api.url(URL, 'create', self.args[0]),
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptItemDetailRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(URL, 'detail', self.args[0], self.args[1]),
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptItemUpdateRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(URL, 'update', self.args[0], self.args[1]),
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptItemDeleteRequest(api.RequestJson):
    def send(self):
        return treq.delete(
            api.url(URL, 'delete', self.args[0], self.args[1]),
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )
