#!/usr/bin/env python

from __future__ import print_function

# This is only required to make the example with without requiring installation
# - Most of the time, you shouldn't use this hack
import sys
from os.path import join, dirname

sys.path.insert(0, join(dirname(__file__), '..', '..'))

import os
from gi.repository import Gtk, GdkPixbuf
from gi_composites import GtkTemplate
from settings import config


@GtkTemplate(ui='glade/composites/devices_row.ui')
class DevicesRowBox(Gtk.Box):
    # Required else you would need to specify the full module
    # name in mywidget.ui (__main__+MyWidget)
    __gtype_name__ = 'DevicesRowBox'

    device = None

    ip = GtkTemplate.Child()
    model = GtkTemplate.Child()
    serial = GtkTemplate.Child()
    icon = GtkTemplate.Child()

    # Alternative way to specify multiple widgets
    # label1, entry = GtkTemplate.Child.widgets(2)

    def __init__(self, device, curr_ip=None):
        super(Gtk.Box, self).__init__()
        self.device = device

        # This must occur *after* you initialize your base
        self.init_template()

        self.ip.set_text(device['ip'])
        self.model.set_text(device['model'])
        self.serial.set_text(device['serial'])

        if device['ip'] == curr_ip:
            svg_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                os.path.join('data', 'svg', 'black', 'check.svg'),
                -1,
                16,
                True
            )
            self.icon.set_from_pixbuf(svg_pixbuf)
            self.icon.set_visible(True)

    def get_ip(self):
        return self.device['ip']
