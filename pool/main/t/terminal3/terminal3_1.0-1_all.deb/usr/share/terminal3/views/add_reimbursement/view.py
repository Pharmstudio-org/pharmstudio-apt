from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import AddReimbursementDialogHandler
from .layout import AddReimbursementDialogLayout


class AddReimbursementDialogView(View):
    glade_file = 'add_reimbursement_dialog.glade'
    main_widget_id = 'dialog_add_reimbursement'

    event_handler_class = AddReimbursementDialogHandler
    layout_class = AddReimbursementDialogLayout

    __gsignals__ = {
        'add': (GObject.SIGNAL_RUN_FIRST, None, (str,)),
    }
