from api.common import EcrRequest


class EcrReportXRequest(EcrRequest):
    def get_args(self):
        return ['printreport', '10']


class EcrReportZRequest(EcrRequest):
    def get_args(self):
        return ['printreport', '0']


class EcrOpenSessionRequest(EcrRequest):
    def get_args(self):
        return ['chk_empty']
