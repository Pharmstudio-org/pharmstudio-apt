from gi.repository import GObject, Gtk
from views.common import Layout, Binding, Widget


class ReceiptListLayout(Layout):
    receipt_list = Widget('scrolledwindow_receipt_list')
    tree_view_receipts = Widget('tree_view_receipts')
    btn_show_receipt = Widget('button_receipt_list_show')
    stack = Widget('stack_loader')
    loader = Widget('image_loader')
    total = Binding('label_total')

    def update_btn_show_receipt_sensitivity(self):
        if self.view.selected_receipt_model is None:
            self.btn_show_receipt.set_sensitive(False)
        else:
            self.btn_show_receipt.set_sensitive(True)

    def build(self):
        super(ReceiptListLayout, self).build()
        self.loader.set_from_file('data/img/loader-eclipse.gif')

    def render(self):
        self.tree_view_receipts.set_model(self.view.receipt_collection.store())
        self.view.receipt_collection.build_tree_columns(self.tree_view_receipts)

        self.update_btn_show_receipt_sensitivity()
