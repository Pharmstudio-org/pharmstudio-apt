from api.common import EcrRequest
import json


class EcrScreenRequest(EcrRequest):
    def get_args(self):
        #json_str = '"' + json.dumps(self.args[0], ensure_ascii=False).replace('"', "\\\"") + '"'
        json_str = json.dumps(self.args[0], ensure_ascii=False)
        return ['scr_multi', json_str]
