from gi.repository import GObject, Gtk, Gdk
from views import View
from views.receipt import ReceiptView
from views.receipt_list import ReceiptListView
from views.goods_balance import GoodsBalanceView
from api.receipt import ReceiptCreateRequest
from models.receipt import ReceiptModel
from views.pledge import PledgeDialogView
from views.secure import SecureDialogView
from views.settings_dialog import SettingsDialogView
from views.ecr_dialog import EcrDialogView
import settings
from settings import config


def deb(name):
    def ppp(*args):
        print(name)
    return ppp


class LayoutView(View):
    glade_file = 'layout.glade'
    main_widget_id = 'application_window'

    notebook = None
    status_bar = None
    status_icon = None
    tablet_separator = None
    tablet_status_bar = None
    tablet_status_icon = None
    escpos_separator = None
    escpos_status_bar = None
    escpos_status_icon = None
    spinner = None
    button_add_receipt = None
    button_show_receipt_list = None
    button_ecr = None

    receipt_list_view = None
    network_error_dialog = None
    pledge_dialog = None
    secure_dialog = None
    settings_dialog = None
    ecr_dialog = None
    goods_balance_view = None

    def build(self):
        super(LayoutView, self).build()
        self._widget.set_default_size(1000, 700)
        self._widget.set_border_width(10)

        box = self._builder.get_object('box2')

        self.spinner = self._builder.get_object('spinner')
        self.button_add_receipt = self._builder.get_object('button_add_receipt')
        self.button_show_receipt_list = self._builder.get_object('button_show_receipt_list')
        self.button_ecr = self._builder.get_object('button_ecr')
        if config['ecr'].enabled:
            self.button_ecr.set_visible(True)
        else:
            self.button_ecr.set_visible(False)

        self.widget().add_accel_group(self.application.accel_group)

        self.notebook = Gtk.Notebook(scrollable=True)
        box.pack_start(self.notebook, True, True, 0)
        box.reorder_child(self.notebook, 1)

        self.goods_balance_view = GoodsBalanceView(self.application)
        default_page = self.goods_balance_view.widget()

        #default_page = Gtk.Box()
        #default_page.set_border_width(10)
        #default_page.add(Gtk.Label('Default Page!'))

        image = Gtk.Image.new_from_icon_name(
            "gtk-home",
            Gtk.IconSize.MENU
        )
        image.set_margin_left(10)
        image.set_margin_top(10)
        image.set_margin_right(10)
        image.set_margin_bottom(10)
        self.notebook.append_page(default_page, image)

        self.status_bar = self._builder.get_object('statusbar')
        self.status_icon = self._builder.get_object('image_connection')
        self.tablet_status_bar = self._builder.get_object('statusbar_tablet')
        self.tablet_status_icon = self._builder.get_object('image_connection_tablet')
        self.tablet_separator = self._builder.get_object('tablet_separator')
        self.escpos_status_bar = self._builder.get_object('statusbar_escpos')
        self.escpos_status_icon = self._builder.get_object('image_connection_escpos')
        self.escpos_separator = self._builder.get_object('escpos_separator')

        self.on_connection_status_changed(None, 'not available')
        self.application.connection_monitor.connect("connection_changed", self.on_connection_status_changed)

        if settings.TABLET_IP and settings.TABLET_PORT:
            self.on_tablet_connection_status_changed(None, 'not available')
            self.application.tablet_connection_monitor.connect("connection_changed",
                                                               self.on_tablet_connection_status_changed)
        else:
            self.on_tablet_connection_status_changed(None, 'not defined')

        if config['print'].enabled:
            self.on_escpos_connection_status_changed(None, 'not available')
            self.application.escpos_connection_monitor.connect("connection_changed",
                                                               self.on_escpos_connection_status_changed)
        else:
            self.on_escpos_connection_status_changed(None, 'not defined')

    def attach(self):
        self._widget.show_all()

    def _add_icon_to_button(self, button):
        icon_box = Gtk.HBox()
        image = Gtk.Image()
        image.set_from_stock(Gtk.STOCK_CLOSE, Gtk.IconSize.MENU)
        Gtk.Button.set_relief(button, Gtk.ReliefStyle.NONE)
        button.set_property('valign', Gtk.Align.CENTER)

        settings = Gtk.Widget.get_settings(button)
        valid_, w, h = Gtk.icon_size_lookup_for_settings(settings,
                                                         Gtk.IconSize.MENU)
        Gtk.Widget.set_size_request(button, w + 4, h + 4)
        image.set_property('margin', 2)
        image.show()
        icon_box.set_property('spacing', 1)
        icon_box.pack_start(image, True, False, 0)
        button.add(icon_box)
        icon_box.show()

    def on_application_window_delete_event(self, *args):
        self.application.quit(*args)

    def on_connection_status_changed(self, sender, status):
        context_id = self.status_bar.get_context_id("connection")
        self.status_bar.remove_all(context_id)
        if status == 'available':
            self.status_icon.set_from_icon_name('gtk-network', Gtk.IconSize.MENU)
            self.status_bar.push(context_id, "Pharmstudio: Підключено")
        else:
            self.status_icon.set_from_icon_name('gtk-dialog-warning', Gtk.IconSize.MENU)
            self.status_bar.push(context_id, "Pharmstudio: З'єднання відсутнє")

    def on_tablet_connection_status_changed(self, sender, status):
        if status == 'not defined':
            self.tablet_separator.hide()
            self.tablet_status_bar.hide()
            self.tablet_status_icon.hide()
        else:
            context_id = self.tablet_status_bar.get_context_id("connection")
            self.tablet_status_bar.remove_all(context_id)
            if status == 'available':
                self.tablet_status_icon.set_from_icon_name('gtk-network', Gtk.IconSize.MENU)
                self.tablet_status_bar.push(context_id, "Планшет: Підключено")
            else:
                self.tablet_status_icon.set_from_icon_name('gtk-dialog-warning', Gtk.IconSize.MENU)
                self.tablet_status_bar.push(context_id, "Планшет: З'єднання відсутнє")

    def on_escpos_connection_status_changed(self, sender, status):
        if status == 'not defined':
            self.escpos_separator.hide()
            self.escpos_status_bar.hide()
            self.escpos_status_icon.hide()
        else:
            context_id = self.escpos_status_bar.get_context_id("connection")
            self.escpos_status_bar.remove_all(context_id)
            if status == 'available':
                self.escpos_status_icon.set_from_icon_name('gtk-network', Gtk.IconSize.MENU)
                self.escpos_status_bar.push(context_id, "Принтер чеків: Підключено")
            else:
                self.escpos_status_icon.set_from_icon_name('gtk-dialog-warning', Gtk.IconSize.MENU)
                self.escpos_status_bar.push(context_id, "Принтер чеків: З'єднання відсутнє")

    def on_show_receipt_list(self, *args):
        if self.receipt_list_view is None:
            self.receipt_list_view = ReceiptListView(self.application)
            self.receipt_list_view.connect('open_receipt', self.on_receipt_open)
            receipt_list_widget = self.receipt_list_view.widget()

            close_button = Gtk.Button()
            self._add_icon_to_button(close_button)
            close_button.connect('clicked', self.on_receipt_list_close)

            tab_title = Gtk.Box()
            tab_title.add(Gtk.Label("Перегляд чеків"))
            tab_title.add(close_button)
            tab_title.show_all()

            self.notebook.append_page(receipt_list_widget, tab_title)

        self.notebook.set_current_page(self.notebook.page_num(self.receipt_list_view.widget()))
        self.attach()

    def on_show_pledge(self, *args):
        if self.pledge_dialog is None:
            self.pledge_dialog = PledgeDialogView(self.application)
        self.pledge_dialog.set_parent(self.application.application_window)
        self.pledge_dialog.layout().render()
        self.pledge_dialog.widget().show_all()

    def on_show_settings_secure(self, *args):
        if self.secure_dialog is None:
            self.secure_dialog = SecureDialogView(self.application)
            self.secure_dialog.connect('show_settings', self.on_show_settings)
        self.secure_dialog.set_parent(self.application.application_window)
        self.secure_dialog.layout().render()
        self.secure_dialog.widget().show_all()

    def on_show_settings(self, *args):
        self.settings_dialog = SettingsDialogView(self.application)
        self.settings_dialog.set_parent(self.application.application_window)
        self.settings_dialog.layout().render()
        self.settings_dialog.widget().show_all()

    def on_receipt_list_close(self, receipt_list_view):
        self.notebook.remove_page(self.notebook.page_num(self.receipt_list_view.widget()))
        self.receipt_list_view = None

    def on_new_receipt(self, *args):
        self.spinner.show()
        self.button_add_receipt.set_sensitive(False)
        ReceiptCreateRequest(on_success=self.on_receipt_created, on_error=self.on_receipt_create_error)

    def on_receipt_created(self, receipt_dict):
        self.spinner.hide()
        self.button_add_receipt.set_sensitive(True)

        receipt = ReceiptModel(**receipt_dict)
        self.on_receipt_open(None, receipt)

    def on_receipt_create_error(self, error):
        self.button_add_receipt.set_sensitive(True)
        self.spinner.hide()
        self.application.show_network_error()

    def on_receipt_open(self, receipt_list_view, receipt):
        receipt_view = ReceiptView(self.application, receipt)
        receipt_view.connect('close', self.on_receipt_close)
        receipt_view.connect('receipt_closed', self.on_new_receipt)
        receipt_widget = receipt_view.widget()

        close_button = Gtk.Button()
        self._add_icon_to_button(close_button)
        close_button.connect('clicked', receipt_view.handler().on_close_icon_clicked)

        tab_title = Gtk.Box()
        tab_title.add(Gtk.Label(receipt.created.strftime("%H:%M:%S")))
        tab_title.add(close_button)
        tab_title.show_all()

        #names = GObject.signal_list_names(Gtk.Widget)
        #for name in names:
        #    receipt_widget.connect(name, deb(name))

        page_num = self.notebook.append_page(receipt_widget, tab_title)
        self.notebook.set_current_page(page_num)
        self.attach()

    def on_receipt_close(self, receipt_view):
        page_num = self.notebook.page_num(receipt_view.widget())
        self.notebook.remove_page(page_num)

    def on_ecr_dialog_open(self, *args):
        self.ecr_dialog = EcrDialogView(self.application)
        self.ecr_dialog.set_parent(self.application.application_window)
        self.ecr_dialog.layout().render()
        self.ecr_dialog.widget().show_all()

    def on_restart(self, *args):
        self.application.restart()
