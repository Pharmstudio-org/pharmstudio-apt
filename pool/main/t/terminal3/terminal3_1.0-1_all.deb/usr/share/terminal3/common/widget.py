from gi.repository import GObject


def number_input(entry, text, func):
    position = entry.get_position()
    new_text = ''
    for char in text:
        if char in '.,':
            if char == '.':
                char = ','
            if char not in entry.get_text():
                new_text += char
        elif char in '1234567890':
            text_list = entry.get_text().split(',')
            if len(text_list) == 2 and len(text_list[1]) == 2:
                pass
            else:
                new_text += char
    if new_text != '':
        entry.handler_block_by_func(func)
        entry.insert_text(new_text, position)
        entry.handler_unblock_by_func(func)

        new_pos = position + len(new_text)
        GObject.idle_add(entry.set_position, new_pos)

    entry.stop_emission("insert_text")
