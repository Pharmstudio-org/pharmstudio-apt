from views.common import Layout, Binding, Widget


class SecureDialogLayout(Layout):
    b_ok = Widget('button_ok')

    secure_code = Binding('entry_code')

    _dialog_sensitive = None

    def render(self):
        self.set_dialog_disabled()
        self.secure_code = ''
        self.focus('entry_code')

    def dialog_sensitive(self):
        return self._dialog_sensitive

    def set_dialog_sensitive(self, *args):
        self._dialog_sensitive = True
        self.set_sensitive(self.b_ok)

    def set_dialog_disabled(self, *args):
        self._dialog_sensitive = False
        self.set_disabled(self.b_ok)
