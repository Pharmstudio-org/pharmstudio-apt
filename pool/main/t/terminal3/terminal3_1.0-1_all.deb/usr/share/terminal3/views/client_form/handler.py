from views.common import Handler
from twisted.internet import reactor


class ClientFormDialogHandler(Handler):
    card_delayed_call = None

    def on_last_name_entry_changed(self, widget, *args):
        self.view.state.dispatch_form_data_change('last_name', widget.get_text())

    def on_last_name_entry_icon_press(self, *args):
        self.layout.last_name_error.set_visible(not self.layout.last_name_error.get_visible())

    def on_first_name_entry_changed(self, widget, *args):
        self.view.state.dispatch_form_data_change('first_name', widget.get_text())

    def on_first_name_entry_icon_press(self, *args):
        self.layout.first_name_error.set_visible(not self.layout.first_name_error.get_visible())

    def on_middle_name_entry_changed(self, widget, *args):
        self.view.state.dispatch_form_data_change('middle_name', widget.get_text())

    def on_middle_name_entry_icon_press(self, *args):
        self.layout.middle_name_error.set_visible(not self.layout.middle_name_error.get_visible())

    def on_primary_phone_entry_changed(self, widget, *args):
        self.view.state.dispatch_form_data_change('primary_phone', widget.get_text())

    def on_primary_phone_entry_icon_press(self, *args):
        self.layout.primary_phone_error.set_visible(not self.layout.primary_phone_error.get_visible())

    def on_secondary_phone_entry_changed(self, widget, *args):
        self.view.state.dispatch_form_data_change('secondary_phone', widget.get_text())

    def on_secondary_phone_entry_icon_press(self, *args):
        self.layout.secondary_phone_error.set_visible(not self.layout.secondary_phone_error.get_visible())

    def on_card_entry_changed(self, widget, *args):
        if self.card_delayed_call is not None and self.card_delayed_call.active():
            self.card_delayed_call.cancel()

        self.card_delayed_call = reactor.callLater(
            0.5, self.view.state.dispatch_form_data_change, 'card', widget.get_text())

    def on_card_entry_icon_press(self, *args):
        self.layout.card_error.set_visible(not self.layout.card_error.get_visible())

    def on_register_client_button_clicked(self, *args):
        self.view.state.dispatch_client_create_request()

    def on_save_button_clicked(self, *args):
        self.view.state.dispatch_client_update_request()

    def on_close_button_clicked(self, *args):
        self.widget.close()
