from gi.repository import GObject, Gtk, Pango
from views.common import Layout, Binding, Widget
from decimal import Decimal


class GoodsBalanceLayout(Layout):
    title_search = Widget('searchentry_title')
    tree_view_item_codes = Widget('item_code_tree_view')
    item_code_selection = Widget('item_code_selection')
    all_drugstores = Widget('checkbutton_all_drugstores')

    prices_stack = Widget('prices_stack')
    prices_placeholder = Widget('prices_placeholder')
    prices_loader_box = Widget('prices_loader_box')
    prices_loader_box_spinner = Widget('prices_loader_box_spinner')
    prices_error_box = Widget('prices_error_box')
    prices_list_window = Widget('prices_list_window')
    prices_tree = Widget('prices_tree')
    prices_liststore = None

    title = Binding('searchentry_title')

    _dialog_sensitive = None
    list_model = None

    selection_change_handler_id = None

    drugstore_column = None

    renderers = {
        'prices': 'render_prices',
        'prices_result': 'render_prices_result',
        'item_code_list_ready': 'connect_item_code_selection_changed',
    }

    def build(self):
        self.list_model = Gtk.TreeStore(int, str, int, int, str, int, str, str, str, str)
        self.tree_view_item_codes.set_model(self.list_model)

        title_cell = Gtk.CellRendererText()
        title_cell.set_property('ellipsize', Pango.EllipsizeMode.END)
        title_col = Gtk.TreeViewColumn("Назва", title_cell, text=1)
        title_col.set_expand(True)
        self.tree_view_item_codes.append_column(title_col)

        label_cell = Gtk.CellRendererText()
        self.tree_view_item_codes.append_column(Gtk.TreeViewColumn("Код", label_cell, text=8))

        label_cell = Gtk.CellRendererText()
        label_cell.set_property('xalign', 0.9)
        self.tree_view_item_codes.append_column(Gtk.TreeViewColumn("Упаковок", label_cell, text=2))

        count_cell = Gtk.CellRendererText()
        count_cell.set_property('xalign', 0.9)
        self.tree_view_item_codes.append_column(Gtk.TreeViewColumn("Торг. од.", count_cell, text=4))

        label_cell = Gtk.CellRendererText()
        label_cell.set_property('xalign', 0.9)
        self.drugstore_column = Gtk.TreeViewColumn("Аптека", count_cell, text=9)

        self.prices_liststore = Gtk.ListStore(str, str, str)
        self.prices_tree.set_model(self.prices_liststore)
        group_col = Gtk.TreeViewColumn("Скидка", Gtk.CellRendererText(), text=0)
        group_col.set_expand(True)
        self.prices_tree.append_column(group_col)
        self.prices_tree.append_column(Gtk.TreeViewColumn("Ціна", Gtk.CellRendererText(), text=1))
        self.prices_tree.append_column(Gtk.TreeViewColumn("За од.", Gtk.CellRendererText(), text=2))

        self.connect_state(self.view.state, self.renderers)

    def render(self):
        self.list_model.clear()

    def dialog_sensitive(self):
        return self._dialog_sensitive

    def set_dialog_sensitive(self, *args):
        self._dialog_sensitive = True
        self.set_sensitive(self.title_search)

    def set_dialog_disabled(self, *args):
        self._dialog_sensitive = False
        self.set_disabled(self.title_search)

    def render_prices(self, *args, **kwargs):
        prices_state = self.view.state.prices
        if not prices_state['selected_goods_code'].get('id'):
            self.prices_stack.set_visible_child(self.prices_placeholder)
        else:
            if prices_state.get('request'):
                self.prices_stack.set_visible_child(self.prices_loader_box)
                self.prices_loader_box_spinner.start()
            elif prices_state.get('error'):
                self.prices_stack.set_visible_child(self.prices_error_box)
                self.prices_loader_box_spinner.stop()
            else:
                self.prices_stack.set_visible_child(self.prices_list_window)
                self.prices_loader_box_spinner.stop()

    def render_prices_result(self, *args, **kwargs):
        if self.view.state.prices['selected_goods_code']['id']:
            model = self.prices_liststore
            model.clear()

            if self.view.state.prices_result.get('groups'):
                for group in self.view.state.prices_result['groups']:
                    model.append([
                        group.get('group', ''),
                        str(Decimal(group.get('price', 0)).quantize(Decimal('1.00'))),
                        str(Decimal(
                            group.get('price', 0) / self.view.state.prices['selected_goods_code']['units']
                        ).quantize(Decimal('1.00'))),
                    ])

    def connect_item_code_selection_changed(self, *args, **kwargs):
        if self.view.state.item_code_list_ready:
            if self.selection_change_handler_id is None:
                self.selection_change_handler_id = self.item_code_selection.connect('changed', self.handler.on_item_code_selection_changed)
        else:
            if self.selection_change_handler_id is not None:
                self.item_code_selection.disconnect(self.selection_change_handler_id)
                self.selection_change_handler_id = None
