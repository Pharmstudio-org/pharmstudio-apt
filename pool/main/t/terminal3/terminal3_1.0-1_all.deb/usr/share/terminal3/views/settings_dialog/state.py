from gi.repository import GObject

defaults = {
    'driver_update_in_progress': False,
    'driver_update_success': False,
}


class SettingsDialogState(GObject.Object):
    _state = defaults

    @GObject.Property(type=bool, default=defaults['driver_update_in_progress'])
    def driver_update_in_progress(self):
        return self._state['driver_update_in_progress']

    @driver_update_in_progress.setter
    def driver_update_in_progress(self, value):
        self._state['driver_update_in_progress'] = value

    @GObject.Property(type=bool, default=defaults['driver_update_success'])
    def driver_update_success(self):
        return self._state['driver_update_success']

    @driver_update_success.setter
    def driver_update_success(self, value):
        self._state['driver_update_success'] = value
