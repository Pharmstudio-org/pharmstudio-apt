from gi.repository import GObject, Gtk, Pango
from decimal import Decimal
from models.common import Model, Collection
from api.receipt_item import (
    ReceiptItemListRequest, ReceiptItemCreateRequest, ReceiptItemDetailRequest, ReceiptItemUpdateRequest,
    ReceiptItemDeleteRequest,
)


class ReceiptItemModel(Model):
    fields = (
        ('id', int, None),
        ('receipt', int, None),
        ('code', str, None),
        ('title', str, None),
        ('maker', str, None),
        ('count', int, None),
        ('units', int, None),
        ('total_units', int, None),
        ('price', Decimal, None),
        ('total', Decimal, None),
        ('discount', Decimal, None),
        ('total_with_discount', Decimal, None),
        ('rating', Decimal, None),
    )

    def get_ecr_json(self):
        if self.count > 1:
            count = self.count
            price = Decimal(self.total_with_discount / self.count).quantize(Decimal('1.00'))
        else:
            count = Decimal(Decimal(self.units) / Decimal(self.total_units)).quantize(Decimal('1.000'))
            price = Decimal(self.total_with_discount / count).quantize(Decimal('1.00'))

        return {'S': {
            'code': self.code,
            'price': price,
            'qty': count,
            'name': self.title.encode('utf-8'),
        }}

    @property
    def units_detailed(self):
        return "%s/%s" % (str(self.units), str(self.total_units))

    @property
    def price_display(self):
        return str(self.price)

    @property
    def total_display(self):
        return str(self.total)

    @property
    def discount_display(self):
        return str(self.discount)

    @property
    def total_with_discount_display(self):
        return str(self.total_with_discount)

    @property
    def rating_display(self):
        return str(self.rating)

    api_methods = (
        ('get', ReceiptItemDetailRequest, ('receipt', 'id')),
        ('update', ReceiptItemUpdateRequest, ('receipt', 'id')),
        ('delete', ReceiptItemDeleteRequest, ('receipt', 'id')),
    )


class ReceiptItemCollection(Collection):
    model_class = ReceiptItemModel
    table_columns = (
        # ('code', str, "Код товару"),
        ('title', str, "Назва"),
        ('maker', str, "Виробник"),
        ('count', int, "Кіл."),
        ('units_detailed', str, "Торг. од."),
        ('price_display', str, "Ціна"),
        ('total_display', str, "Сума"),
        ('discount_display', str, "Скидка"),
        ('rating_display', str, "Балів"),
        ('total_with_discount_display', str, "Всього"),
    )

    api_methods = (
        ('list', ReceiptItemListRequest, ('receipt',)),
        ('create', ReceiptItemCreateRequest, ('receipt',)),
    )

    receipt = None

    def prepare_col(self, col, field):
        if field == 'title':
            col.set_expand(True)
            col.set_property('resizable', True)
        if field == 'maker':
            col.set_property('resizable', True)
            col.set_fixed_width(200)

    def prepare_cell_renderer(self, renderer, field):
        if field in (
            'count', 'units_detailed', 'price_display', 'total_display', 'discount_display', 'rating_display',
            'total_with_discount_display',
        ):
            renderer.set_property('xalign', 0.9)
        if field in ('title', 'maker'):
            renderer.set_property('ellipsize', Pango.EllipsizeMode.END)

    def __init__(self, receipt):
        self.receipt = receipt
        super(ReceiptItemCollection, self).__init__()
