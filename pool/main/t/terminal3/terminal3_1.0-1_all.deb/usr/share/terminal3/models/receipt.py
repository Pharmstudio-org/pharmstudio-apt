from gi.repository import GObject, Gtk, Pango
from decimal import Decimal
import datetime
from models.common import Model, Collection
from api.receipt import (
    ReceiptListRequest, ReceiptCreateRequest, ReceiptDetailRequest, ReceiptUpdateRequest, ReceiptCloseRequest,
    ReceiptCancelRequest, ReceiptAddClientRequest, ReceiptAddCardRequest, ReceiptRemoveClientRequest,
    ReceiptRemoveAffiliateRequest
)
from models.receipt_item import ReceiptItemCollection


class ReceiptModel(Model):
    __gsignals__ = {
        'client_not_found': (GObject.SIGNAL_RUN_FIRST, None, ()),
        'card_not_found': (GObject.SIGNAL_RUN_FIRST, None, ()),
    }

    fields = (
        ('id', int, None),
        ('created', datetime.datetime, None),
        ('total', Decimal, None),
        ('discount', Decimal, None),
        ('total_with_discount', Decimal, None),
        ('rating', Decimal, None),
        ('canceled', datetime.datetime, None),
        ('closed', datetime.datetime, None),
        ('items', list, ()),
        ('client', dict, None),
        ('affiliate', dict, None),
        ('balance', Decimal, None),
        ('cashless_amount', Decimal, None),
        ('reimbursement', Decimal, None),
    )

    api_methods = (
        ('get', ReceiptDetailRequest, ('id',)),
        ('update', ReceiptUpdateRequest, ('id',)),
        ('close', ReceiptCloseRequest, ('id',)),
        ('cancel', ReceiptCancelRequest, ('id',)),
        ('add_client', ReceiptAddClientRequest, ('id',)),
        ('add_card', ReceiptAddCardRequest, ('id',)),
        ('remove_client', ReceiptRemoveClientRequest, ('id',)),
        ('remove_affiliate', ReceiptRemoveAffiliateRequest, ('id',)),
    )

    _item_collection = None

    @property
    def status(self):
        if self.closed:
            return "Закрито"
        if self.canceled:
            return "Відмінено"
        return ""

    @property
    def created_formatted(self):
        if self.created:
            return self.created.strftime("%H:%M")

    @property
    def client_display(self):
        if self.client:
            return self.client.get('short_client_name', '')
        else:
            return ''

    @property
    def affiliate_display(self):
        if self.affiliate:
            name = self.affiliate.get('short_name', '')
            if name:
                return "%s (%s)" % (name, self.affiliate_status)
            else:
                return ''
        else:
            return ''

    @property
    def affiliate_status(self):
        if self.affiliate:
            return self.affiliate.get('status', '')
        else:
            return ''

    @property
    def balance_display(self):
        return str(self.balance)

    @property
    def total_display(self):
        return str(self.total)

    @property
    def total_with_discount_display(self):
        return str(self.total_with_discount)

    @property
    def discount_display(self):
        return str(self.discount)

    @property
    def rating_display(self):
        return str(self.rating)

    @property
    def item_count(self):
        return len(self.items)

    def on_add_card_success(self, data):
        self.load_from_dict(data)

    def on_add_card_error(self, data):
        self.emit('card_not_found')

    def on_add_client_success(self, data):
        self.load_from_dict(data)

    def on_add_client_error(self, data):
        self.emit('client_not_found')

    def on_remove_client_success(self, data):
        self.load_from_dict(data)

    def on_remove_affiliate_success(self, data):
        self.load_from_dict(data)


class ReceiptCollection(Collection):
    model_class = ReceiptModel
    table_columns = (
        ('id', int, "№"),
        ('created_formatted', str, "Створено"),
        ('affiliate_display', str, "Партнер"),
        ('balance_display', str, "Баланс"),
        ('client_display', str, "Клієнт"),
        ('item_count', int, "Товарів"),
        ('total_display', str, "Сума"),
        ('discount', str, "Скидка"),
        ('total_with_discount', str, "Всього"),
        ('rating', str, "Нараховано балів"),
        ('status', str, "Статус"),
    )

    api_methods = (
        ('list', ReceiptListRequest, ()),
        ('create', ReceiptCreateRequest, ()),
    )

    def _append_model(self, model):
        if model.item_count:
            super(ReceiptCollection, self)._append_model(model)

    def _remove_model(self, model):
        if model.item_count:
            super(ReceiptCollection, self)._remove_model(model)

    def prepare_cell_renderer(self, renderer, field):
        if field in ('balance_display', 'total_display', 'discount', 'total_with_discount', 'rating'):
            renderer.set_property('xalign', 0.9)
