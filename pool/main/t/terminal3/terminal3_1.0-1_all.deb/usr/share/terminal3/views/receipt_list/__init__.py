from .view import ReceiptListView
