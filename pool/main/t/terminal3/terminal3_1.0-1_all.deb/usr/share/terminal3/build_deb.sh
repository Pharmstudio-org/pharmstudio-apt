#!/bin/bash

PACKAGE_NAME="terminal3"
VERSION="1.0-1"

BASEDIR=$(dirname "$0")
FULLNAME="${PACKAGE_NAME}_${VERSION}"
DIST_DIR=${BASEDIR}/deb

if [ $UID != 0 ]; then
    echo "Please run this script with sudo:"
    echo "sudo $0 $*"
    exit 1
fi

echo "Prepare file structure"

if [ -d $DIST_DIR ]; then rm -Rf $DIST_DIR; fi

mkdir -p ${DIST_DIR}/${FULLNAME}/DEBIAN
mkdir -p ${DIST_DIR}/${FULLNAME}/usr/bin
mkdir -p ${DIST_DIR}/${FULLNAME}/usr/share/${PACKAGE_NAME}

rsync -a --no-i-r --human-readable --info=progress2 ${BASEDIR} ${DIST_DIR}/${FULLNAME}/usr/share/${PACKAGE_NAME} --exclude .git --exclude .gitignore --exclude .env --exclude __pycache__

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/DEBIAN/control
Package: ${PACKAGE_NAME}
Version: ${VERSION}
Section: base
Priority: optional
Architecture: all
Maintainer: Valentin Osipenko <valtron.forever@gmail.com>
Depends: python3-gi-cairo, python3-psutil, python3-twisted, python3-treq, python3-service-identity, python3-cerberus
Description: Pharmstudio terminal
 Goods selling tool connected to pharmstudio.com.ua
EOF

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/DEBIAN/postinst
#!/bin/sh
sudo -u \${SUDO_USER} xdg-desktop-icon install --novendor /usr/lib/${PACKAGE_NAME}/Terminal.desktop
exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/DEBIAN/postinst

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/DEBIAN/prerm
#!/bin/sh
xdg-desktop-icon uninstall Terminal.desktop
rm /usr/bin/${PACKAGE_NAME}
exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/DEBIAN/prerm

/bin/cat <<EOF > ${DIST_DIR}/${FULLNAME}/usr/bin/${PACKAGE_NAME}
#!/bin/sh
cd /usr/share/${PACKAGE_NAME}
python3 run_tw.py
exit 0
EOF
chmod +x ${DIST_DIR}/${FULLNAME}/usr/bin/${PACKAGE_NAME}

chown -R root.root ${DIST_DIR}/${FULLNAME}/usr/share/${PACKAGE_NAME}
find ${DIST_DIR}/${FULLNAME}/usr/share/${PACKAGE_NAME} | grep -E "(__pycache__|\.pyc|\.pyo$)" | xargs rm -rf

cd $DIST_DIR
dpkg-deb --build $FULLNAME

cd ..
chown -R $SUDO_USER.$SUDO_USER ${DIST_DIR}
