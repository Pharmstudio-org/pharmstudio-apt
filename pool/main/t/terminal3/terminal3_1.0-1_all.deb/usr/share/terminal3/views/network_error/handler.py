from views.common import Handler


class NetworkErrorDialogHandler(Handler):
    def on_close(self, *args):
        self.widget.hide()
        return True
