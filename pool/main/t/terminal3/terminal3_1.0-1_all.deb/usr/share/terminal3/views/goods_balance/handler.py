from gi.repository import GObject, Gtk, Pango
from views.common import Handler
from api.item_code import ItemCodeListRequest


class GoodsBalanceHandler(Handler):
    def on_search_error(self, *args):
        self.view.application.show_network_error()

    def on_search(self, *args):
        self.view.state.dispatch_item_code_list_ready(False)
        self.layout.list_model.clear()
        if len(self.layout.title) > 3:

            ItemCodeListRequest(
                data={
                    'title': self.layout.title,
                    'for_campaign': 1 if self.layout.all_drugstores.get_active() else 0,
                },
                on_success=self.on_search_success,
                on_error=self.on_search_error
            )

    def on_search_success(self, result):
        list_model = self.layout.list_model
        list_model.clear()

        for item in result:
            label = "%s/%s" % (str(item.get('remaining_units', 0)), str(item.get('total_units', 0)))
            list_model.append(None, (
                item.get('id', 0),
                item.get('product_title', ''),
                item.get('full_items_count', ''),
                item.get('remaining_units', 0),
                label,
                item.get('total_units', 0),
                item.get('price'),
                item.get('unit_price'),
                item.get('code'),
                item.get('drugstore_name'),
            ))
        self.view.state.dispatch_item_code_list_ready(True)

    def on_click(self, widget, event):
        if event.button == 3:
            try:
                path, _, _, _ = widget.get_path_at_pos(int(event.x), int(event.y))
                iter = self.layout.list_model.get_iter(path)
            except TypeError:
                return
            menu = Gtk.Menu()
            i1 = Gtk.MenuItem("Копіювати код")
            i1.connect('activate', self.on_copy, iter)
            menu.append(i1)
            menu.show_all()
            menu.attach_to_widget(self.view.widget())
            menu.popup(None, None, None, None, 0, Gtk.get_current_event_time())

    def on_item_code_selection_changed(self, selection, *args):
        (model, iter) = selection.get_selected()
        if iter is not None:
            self.view.state.dispatch_prices_goods_code_select({
                'id': model[iter][0],
                'units': model[iter][5],
            })
        else:
            self.view.state.dispatch_prices_goods_code_selection_clear()

    def on_drugstores_toggled(self, *args):
        if self.layout.all_drugstores.get_active():
            self.layout.tree_view_item_codes.append_column(self.layout.drugstore_column)
        else:
            self.layout.tree_view_item_codes.remove_column(self.layout.drugstore_column)
        self.on_search()

    def on_copy(self, item, iter):
        self.view.application.clipboard.set_text(self.layout.list_model[iter][8], -1)
