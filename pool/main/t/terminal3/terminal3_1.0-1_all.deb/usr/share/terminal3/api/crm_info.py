import api
from settings import config
import treq


URL = "sales/api/crm-info/"
CLIENT_NOTIFIED_URL = "sales/api/client-notified/"
CLIENTS_BY_PHONE_URL = "sales/api/crm-info/client-find-by-phone/"
CLIENT_FORM_URL = "sales/api/client-form/"


class GetCrmClientInfoRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(URL, 'list') + self.args[0] + '/',
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ClientNotifiedRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(CLIENT_NOTIFIED_URL, 'update', self.args[0]),
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class GetCrmClientsByPhoneRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(CLIENTS_BY_PHONE_URL, 'list'),
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class GetCrmClientDetailsRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(CLIENT_FORM_URL, 'detail', int(self.args[0])),
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class GetCrmClientCreateRequest(api.RequestJson):
    def send(self):
        return treq.post(
            api.url(CLIENT_FORM_URL, 'create'),
            auth=(config['auth'].api_user, config['auth'].api_password,),
            json=self.data,
            timeout=5
        )


class GetCrmClientUpdateRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(CLIENT_FORM_URL, 'update', int(self.args[0])),
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )
