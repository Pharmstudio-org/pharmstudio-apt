from views.common import Layout, Binding, Widget


class AddReimbursementDialogLayout(Layout):
    amount = Binding('spinbutton_amount')
    entry_amount = Widget('spinbutton_amount')

    def render(self, amount):
        self.entry_amount.set_value(amount)
        self.focus(self.entry_amount)
