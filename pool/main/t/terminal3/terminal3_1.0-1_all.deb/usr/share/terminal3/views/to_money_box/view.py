from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import ToMoneyBoxDialogHandler
from .layout import ToMoneyBoxDialogLayout


class ToMoneyBoxDialogView(View):
    glade_file = 'to_money_box_dialog.glade'
    main_widget_id = 'dialog_to_money_box'

    event_handler_class = ToMoneyBoxDialogHandler
    layout_class = ToMoneyBoxDialogLayout

    __gsignals__ = {
        'add': (GObject.SIGNAL_RUN_FIRST, None, (str,)),
    }
