from gi.repository import GObject
from views.common import StateMixin
from cerberus import Validator
from api.crm_info import GetCrmClientDetailsRequest, GetCrmClientCreateRequest,\
    GetCrmClientUpdateRequest

validation = {
    'last_name': {'type': 'string', 'maxlength': 255, 'required': True, 'empty': False},
    'first_name': {'type': 'string', 'maxlength': 255},
    'middle_name': {'type': 'string', 'maxlength': 255},
    'primary_phone': {'type': 'string', 'regex': r"^[\+()\s\-0-9]+", 'empty': True},
    'secondary_phone': {'type': 'string', 'regex': r"^[\+()\s\-0-9]+", 'empty': True},
    'card': {'type': 'string', 'regex': "^[0-9]{13}$", 'required': True, 'empty': False},
}


def get_validation_text(error):
    error_str = "Помилка при заповненні"
    if error.rule == 'empty':
        error_str = "Заповніть обов'язкове поле"
    return error_str


class ClientFormState(StateMixin):
    defaults = {
        'request': {
            'is_running': False,
            'error': None,
        },
        'client': {
            'ready': True,
            'id': None,
            'data': {
                'last_name': None,
                'first_name': None,
                'middle_name': None,
                'primary_phone': None,
                'secondary_phone': None,
                'card': None,
            },
        },
        'form_data': {
            'last_name': '',
            'first_name': '',
            'middle_name': '',
            'primary_phone': '',
            'secondary_phone': '',
            'card': '',
        },
        'form_errors': {
            'last_name': None,
            'first_name': None,
            'middle_name': None,
            'primary_phone': None,
            'secondary_phone': None,
            'card': None,
        },
        'show_network_error': False,
        'emit_add_client_signal': False,
    }

    def has_errors(self):
        has_errors = False
        for err in self.form_errors.values():
            if err is not None:
                has_errors = True
        return has_errors

    def dispatch_show_network_error(self):
        self.show_network_error = True
        self.show_network_error = False

    def dispatch_emit_add_client_signal(self):
        self.emit_add_client_signal = True
        self.emit_add_client_signal = False

    def dispatch_validate(self):
        v = Validator(validation)
        if v.validate(self.form_data):
            self.form_errors = dict(self.form_errors, **self.defaults['form_errors'])
        else:
            error_dict = {}
            for key in self.form_errors.keys():
                try:
                    error = v.document_error_tree[key].errors[0]
                    error_dict[key] = get_validation_text(error)
                except AttributeError:
                    pass
            self.form_errors = dict(self.form_errors, **error_dict)

    def dispatch_form_data_change(self, key, new_str):
        with self.freeze_notify():
            self.form_data = dict(self.form_data, **{key: new_str})
        v = Validator({key: validation.get(key)})
        if v.validate({key: new_str}):
            self.form_errors = dict(self.form_errors, **{key: None})
        else:
            error = v.document_error_tree[key].errors[0]
            self.form_errors = dict(self.form_errors, **{key: get_validation_text(error)})

    def dispatch_client_request_success(self, cd):
        client_data = {
            'last_name': cd['last_name'],
            'first_name': cd['first_name'],
            'middle_name': cd['middle_name'],
            'primary_phone': cd['primary_phone'],
            'secondary_phone': cd['secondary_phone'],
            'card': cd['code'],
        }
        self.client = dict(self.client,
                           ready=True, id=cd['id'], data=client_data)
        self.form_data = dict(client_data)

    def dispatch_client_request_error(self):
        self.client = dict(self.client, ready=True)
        self.dispatch_show_network_error()

    def dispatch_client_details_request(self, client_id):
        self.client = dict(self.client, ready=False, id=client_id)
        GetCrmClientDetailsRequest(
            client_id,
            on_success=self.dispatch_client_request_success,
            on_error=self.dispatch_client_request_error,
        )

    def dispatch_client_create_request(self):
        self.client = dict(self.client, ready=False)
        fd = self.form_data

        def create_request_success(cd):
            client_data = {
                'last_name': cd['last_name'],
                'first_name': cd['first_name'],
                'middle_name': cd['middle_name'],
                'primary_phone': cd['primary_phone'],
                'secondary_phone': cd['secondary_phone'],
                'card': cd['code'],
            }
            self.client = dict(self.client, ready=True, data=client_data)
            self.dispatch_emit_add_client_signal()

        GetCrmClientCreateRequest(
            data={
                'last_name': fd['last_name'],
                'first_name': fd['first_name'],
                'middle_name': fd['middle_name'],
                'primary_phone': fd['primary_phone'],
                'secondary_phone': fd['secondary_phone'],
                'code': fd['card'],
            },
            on_success=create_request_success,
            on_error=self.dispatch_client_request_error,
        )

    def dispatch_client_update_request(self):
        self.client = dict(self.client, ready=False)
        fd = self.form_data
        GetCrmClientUpdateRequest(
            self.client['id'],
            data={
                'last_name': fd['last_name'],
                'first_name': fd['first_name'],
                'middle_name': fd['middle_name'],
                'primary_phone': fd['primary_phone'],
                'secondary_phone': fd['secondary_phone'],
                'code': fd['card'],
            },
            on_success=self.dispatch_client_request_success,
            on_error=self.dispatch_client_request_error,
        )
