
from __future__ import print_function

# This is only required to make the example with without requiring installation
# - Most of the time, you shouldn't use this hack
import sys
from os.path import join, dirname

sys.path.insert(0, join(dirname(__file__), '..', '..'))

import os
from gi.repository import Gtk
from gi_composites import GtkTemplate
from decimal import Decimal


@GtkTemplate(ui='glade/composites/accounts_row.ui')
class AccountsRowBox(Gtk.Box):
    __gtype_name__ = 'AccountsRowBox'

    device = None

    name = GtkTemplate.Child()
    sum = GtkTemplate.Child()

    def __init__(self, account):
        super(Gtk.Box, self).__init__()
        self.account = account

        self.init_template()

        self.name.set_text(account['name'].capitalize())
        self.sum.set_text(str(Decimal(account['sum']).quantize(Decimal('1.00'))))

    def get_account(self):
        return self.account
