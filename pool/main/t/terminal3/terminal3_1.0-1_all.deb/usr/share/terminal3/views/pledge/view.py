from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import PledgeDialogHandler
from .layout import PledgeDialogLayout


class PledgeDialogView(View):
    glade_file = 'pledge.glade'
    main_widget_id = 'dialog_pledge'

    event_handler_class = PledgeDialogHandler
    layout_class = PledgeDialogLayout

    client_not_found_dialog = None

    def build(self):
        super(PledgeDialogView, self).build()
