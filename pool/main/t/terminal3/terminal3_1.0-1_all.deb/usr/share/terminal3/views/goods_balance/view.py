from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import GoodsBalanceHandler
from .layout import GoodsBalanceLayout
from .state import GoodsBalanceState


class GoodsBalanceView(View):
    glade_file = 'goods_balance.glade'
    main_widget_id = 'box1'

    event_handler_class = GoodsBalanceHandler
    layout_class = GoodsBalanceLayout
    state_class = GoodsBalanceState

    def build(self):
        super(GoodsBalanceView, self).build()
