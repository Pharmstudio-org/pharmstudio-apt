from views.common import Handler
from api.ecr.devices import EcrDevicesRequest
from api.ecr.reports import EcrReportXRequest, EcrReportZRequest, EcrOpenSessionRequest
from api.ecr.accounts import EcrAccountsRequest, EcrAccountsDepositRequest, EcrAccountsWithdrawalRequest
from api.ecr.receipts import EcrReceiptsCopyRequest
from api.ecr.service import EcrSendAndReset
from composites.devices_row import DevicesRowBox
from composites.accounts_row import AccountsRowBox


class EcrDialogHandler(Handler):
    def on_menu_select(self, _, row):
        row.activate()

    def on_row_accounts_activate(self, *args):
        self.layout.stack.set_visible_child(self.layout.accounts_box)
        self.on_accounts_refresh_button_clicked(*args)

    def on_row_reports_activate(self, *args):
        self.layout.reports_stack.set_visible_child(self.layout.reports_loader_box)
        self.layout.stack.set_visible_child(self.layout.reports_stack)

        def on_error(*args):
            print(args)
            self.layout.reports_stack.set_visible_child(self.layout.reports_error_box)

        def on_success(result):
            self.layout.set_disabled(self.layout.reportz_button)
            for account in result['response']:
                if account['no'] == 1 and account['sum'] == 0:
                    self.layout.set_sensitive(self.layout.reportz_button)
            self.layout.reports_stack.set_visible_child(self.layout.reports_box)

        EcrAccountsRequest(on_error=on_error, on_success=on_success)

    def on_row_settings_activate(self, *args):
        self.layout.settings.init_settings(self.view.config)
        self.layout.stack.set_visible_child(self.layout.settings)

    def on_row_devices_activate(self, *args):
        self.layout.stack.set_visible_child(self.layout.devices_stack)
        self.on_repeat_search_clicked(*args)

    def on_row_service_activate(self, *args):
        self.layout.stack.set_visible_child(self.layout.service_box)

    def on_last_receipt_copy_error(self, *args):
        print(args)
        self.layout.set_sensitive(self.layout.last_receipt_copy_button)
        self.view.application.show_network_error()

    def on_last_receipt_copy_button_clicked(self, *args):
        self.layout.set_disabled(self.layout.last_receipt_copy_button)
        EcrReceiptsCopyRequest(
            on_success=lambda _: self.layout.set_sensitive(self.layout.last_receipt_copy_button),
            on_error=self.on_last_receipt_copy_error,
        )

    def on_accounts_refresh_button_clicked(self, *args):
        self.layout.set_disabled(*self.layout.accounts_widgets)
        self.layout.accounts_stack.set_visible_child(self.layout.accounts_loader_box)
        EcrAccountsRequest(on_success=self.on_accounts_received, on_error=self.on_accounts_error)

    def on_accounts_received(self, result):
        self.layout.accounts_in_spin.set_value(0)
        self.layout.accounts_out_spin.set_value(0)
        self.layout.clear_accounts_list()
        for i, account in enumerate(result['response']):
            self.layout.accounts_list.add(AccountsRowBox(account))

        self.layout.set_sensitive(*self.layout.accounts_widgets)
        self.layout.update_cash_transfer_sensitivity()
        self.layout.accounts_stack.set_visible_child(self.layout.accounts_list_window)

    def on_accounts_error(self, *args):
        print(args)
        self.layout.accounts_stack.set_visible_child(self.layout.accounts_error_box)

    def on_accounts_transfer_success(self, result):
        self.on_accounts_refresh_button_clicked()

    def on_accounts_list_row_selected(self, *args):
        self.layout.update_cash_transfer_sensitivity()

    def on_accounts_in_button_clicked(self, *args):
        row = self.layout.accounts_list.get_selected_row()
        if row:
            account = row.get_child().get_account()
            self.layout.set_disabled(*self.layout.accounts_widgets)
            EcrAccountsDepositRequest(
                account['no'], self.layout.accounts_in_spin.get_value(),
                on_success=self.on_accounts_transfer_success,
                on_error=self.on_accounts_error,
            )

    def on_accounts_out_button_clicked(self, *args):
        row = self.layout.accounts_list.get_selected_row()
        if row:
            account = row.get_child().get_account()
            self.layout.set_disabled(*self.layout.accounts_widgets)
            EcrAccountsWithdrawalRequest(
                account['no'], self.layout.accounts_out_spin.get_value(),
                on_success=self.on_accounts_transfer_success,
                on_error=self.on_accounts_error,
            )

    def on_sessionopen_clicked(self, *args):
        self.layout.set_disabled(*self.layout.report_buttons)
        EcrOpenSessionRequest(
            on_success=lambda _: self.layout.set_sensitive(*self.layout.report_buttons),
            on_error=lambda _: self.view.application.show_network_error(),
        )

    def on_reportx_clicked(self, *args):
        self.layout.set_disabled(*self.layout.report_buttons)
        EcrReportXRequest(
            on_success=lambda _: self.layout.set_sensitive(*self.layout.report_buttons),
            on_error=lambda _: self.view.application.show_network_error(),
        )

    def on_reportz_clicked(self, *args):
        self.layout.set_disabled(*self.layout.report_buttons)
        EcrReportZRequest(
            on_success=lambda _: self.layout.set_sensitive(*self.layout.report_buttons),
            on_error=lambda _: self.view.application.show_network_error(),
        )

    def on_service_lock_button_toggled(self, button, *args):
        self.view.state.service_dialog_locked = not button.get_active()

    def on_send_and_reset_button_clicked(self, *args):
        self.view.state.service_dialog_locked = True

        EcrSendAndReset(
            on_error=lambda _: self.view.application.show_network_error(),
            on_both=lambda: setattr(self.view.state, 'service_dialog_locked', False)
        )

    def on_repeat_search_clicked(self, *args):
        self.layout.devices_stack.set_visible_child(self.layout.loader_box)
        EcrDevicesRequest(on_success=self.on_devices_received, on_error=self.on_devices_error)

    def on_devices_received(self, result):
        self.layout.set_disabled(self.layout.select_device_button)
        self.layout.clear_devices_list()
        if result['result'] == 'ok' and len(result['response']):
            for device in result['response']:
                self.layout.devices_list.add(DevicesRowBox(device, self.view.config['addr']))
        else:
            self.layout.devices_list.add(DevicesRowBox({
                'ip': '', 'model': "Пристрої не знайдено", 'serial': '',
            }))
            row = self.layout.devices_list.get_row_at_index(0)
            row.set_activatable(False)
            row.set_selectable(False)
        self.layout.devices_stack.set_visible_child(self.layout.devices_box)

    def on_devices_error(self, *args, **kwargs):
        print(args)
        self.layout.devices_stack.set_visible_child(self.layout.error_box)

    def on_devices_list_box_row_selected(self, sender, row):
        if row:
            ip = row.get_child().get_ip()
            if ip != self.view.config['addr']:
                self.layout.set_sensitive(self.layout.select_device_button)
            else:
                self.layout.set_disabled(self.layout.select_device_button)

    def on_select_device_button_clicked(self, *args):
        ip = self.layout.devices_list.get_selected_row().get_child().get_ip()
        self.view.config['addr'] = ip
        self.view.save_ecr_config()
        self.on_repeat_search_clicked()

    def on_close(self, *args):
        self.widget.hide()
        return True
