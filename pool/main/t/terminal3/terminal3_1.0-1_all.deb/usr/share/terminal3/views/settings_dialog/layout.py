from views.common import Layout, Binding, Widget
from settings import config, save_config


class SettingsDialogLayout(Layout):
    stack = Widget('form_stack')

    main_settings = Widget('main_settings_box')
    auth_settings = Widget('auth_settings_box')
    print_settings = Widget('print_settings_box')
    payment_settings = Widget('payment_settings_box')
    ecr_settings = Widget('ecr_settings_box')
    reimbursement_settings = Widget('reimbursement_settings_box')

    print_widgets = None
    print_url = Widget('entry_print_url')
    print_interval = Widget('entry_print_interval')
    print_auto = Widget('switch_print_auto')

    ecr_widgets = None
    ecr_interpreter = Widget('entry_ecr_interpreter')
    ecr_command = Widget('entry_ecr_command')
    ecr_config = Widget('entry_ecr_config')
    ecr_working_dir = Widget('entry_ecr_working_dir')
    ecr_show_screen_info = Widget('ecr_show_screen_info')

    b_main_server_url = Binding('entry_main_server_url')
    b_main_check_connection_interval = Binding('entry_main_check_connection_interval')
    b_auth_drugstore_id = Binding('entry_auth_drugstore_id')
    b_auth_api_user = Binding('entry_auth_api_user')
    b_auth_api_password = Binding('entry_auth_api_password')
    b_auth_account_to = Binding('entry_auth_account_to')
    b_print_enabled = Binding('print_enabled')
    b_print_server_url = Binding('entry_print_url')
    b_print_check_connection_interval = Binding('entry_print_interval')
    b_print_auto_print = Binding('switch_print_auto')
    b_payment_enabled = Binding('payment_enabled')
    b_ecr_enabled = Binding('ecr_enabled')
    b_ecr_interpreter = Binding('entry_ecr_interpreter')
    b_ecr_command = Binding('entry_ecr_command')
    b_ecr_working_dir = Binding('entry_ecr_working_dir')
    b_ecr_config = Binding('entry_ecr_config')
    b_ecr_show_screen_info = Binding('ecr_show_screen_info')
    b_reimbursement_enabled = Binding('reimbursement_enabled')

    update_driver_button = Widget('update_driver_button')
    driver_success_update_label = Widget('driver_success_update_label')
    driver_update_image = Widget('driver_update_image')

    renderers = {
        'driver_update_in_progress': 'render_driver_update',
    }

    def build(self, *args, **kwargs):
        self.print_widgets = [self.print_url, self.print_interval, self.print_auto]
        self.ecr_widgets = [self.ecr_interpreter, self.ecr_command, self.ecr_config, self.ecr_working_dir, self.ecr_show_screen_info]
        super(SettingsDialogLayout, self).build(*args, **kwargs)
        self.connect_state(self.view.state, self.renderers)

    def render(self):
        main = config['main']
        self.b_main_server_url = main.server_url
        self.b_main_check_connection_interval = str(main.check_connection_interval)

        auth = config['auth']
        self.b_auth_drugstore_id = str(auth.drugstore_id)
        self.b_auth_api_user = auth.api_user
        self.b_auth_api_password = auth.api_password
        self.b_auth_account_to = str(auth.account_to)

        s_print = config['print']
        self.b_print_enabled = s_print.enabled
        self.b_print_server_url = s_print.server_url
        self.b_print_check_connection_interval = str(s_print.check_connection_interval)
        self.b_print_auto_print = s_print.auto_print

        payment = config['payment']
        self.b_payment_enabled = payment.enabled

        ecr = config['ecr']
        self.b_ecr_enabled = ecr.enabled
        self.b_ecr_interpreter = ecr.interpreter
        self.b_ecr_command = ecr.command
        self.b_ecr_working_dir = ecr.working_dir
        self.b_ecr_config = ecr.config_path
        self.b_ecr_show_screen_info = ecr.show_screen_info

        reimbursement = config['reimbursement']
        self.b_reimbursement_enabled = reimbursement.enabled

        self.render_driver_update()

    def render_driver_update(self, *args):
        if self.view.state.driver_update_in_progress:
            self.set_disabled(self.update_driver_button)
            self.driver_success_update_label.hide()
            self.driver_update_image.get_style_context().add_class('fa-spinner')
        else:
            self.set_sensitive(self.update_driver_button)
            self.driver_update_image.get_style_context().remove_class('fa-spinner')
            if self.view.state.driver_update_success:
                self.driver_success_update_label.show()
            else:
                self.driver_success_update_label.hide()

    def save(self):
        main = config['main']
        main.server_url = self.b_main_server_url
        main.check_connection_interval = int(self.b_main_check_connection_interval)

        auth = config['auth']
        auth.drugstore_id = int(self.b_auth_drugstore_id)
        auth.api_user = self.b_auth_api_user
        auth.api_password = self.b_auth_api_password
        auth.account_to = int(self.b_auth_account_to)

        s_print = config['print']
        s_print.enabled = self.b_print_enabled
        s_print.server_url = self.b_print_server_url
        s_print.check_connection_interval = int(self.b_print_check_connection_interval)
        s_print.auto_print = self.b_print_auto_print

        payment = config['payment']
        payment.enabled = self.b_payment_enabled

        ecr = config['ecr']
        ecr.enabled = self.b_ecr_enabled
        ecr.interpreter = self.b_ecr_interpreter
        ecr.command = self.b_ecr_command
        ecr.working_dir = self.b_ecr_working_dir
        ecr.config_path = self.b_ecr_config
        ecr.show_screen_info = self.b_ecr_show_screen_info

        reimbursement = config['reimbursement']
        reimbursement.enabled = self.b_reimbursement_enabled

        save_config()
