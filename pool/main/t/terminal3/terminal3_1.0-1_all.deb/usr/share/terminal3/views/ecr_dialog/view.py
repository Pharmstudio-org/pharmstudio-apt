from gi.repository import GObject, Gtk, Pango
from views import View
from settings import config
from .handler import EcrDialogHandler
from .layout import EcrDialogLayout
from .state import EcrDialogState
from composites.ecr_internal_settings_form import EcrInternalSettingsFormBox
try:
    from configparser import ConfigParser
except ImportError:
    from ConfigParser import ConfigParser


class EcrDialogView(View):
    glade_file = 'ecr.glade'
    main_widget_id = 'window_ecr'

    event_handler_class = EcrDialogHandler
    layout_class = EcrDialogLayout
    state_class = EcrDialogState

    config = {}

    def build(self):
        GObject.type_register(EcrInternalSettingsFormBox)
        self.read_ecr_config()
        super(EcrDialogView, self).build()

    def read_ecr_config(self):
        conf_reader = ConfigParser()

        conf_reader.read(config['ecr'].config_path)
        self.config = conf_reader['DEFAULT']

    def save_ecr_config(self):
        conf_reader = ConfigParser()
        conf_reader.read(config['ecr'].config_path)
        conf_reader['DEFAULT'] = self.config
        with open(config['ecr'].config_path, 'w') as configfile:
            conf_reader.write(configfile)

    def on_settings_form_save(self, _, config):
        self.config = config
        self.save_ecr_config()
        self.layout().settings.init_settings(self.config)

    def on_device_select(self, _, addr):
        pass
