from decimal import Decimal
from gi.repository import GObject, Gtk, Pango
from models.receipt_item import ReceiptItemCollection
from views import View
from settings import config
from api.ecr.screen import EcrScreenRequest
from .handler import ReceiptHandler
from .layout import ReceiptLayout


class ReceiptView(View):
    glade_file = 'receipt.glade'
    main_widget_id = 'box1'

    event_handler_class = ReceiptHandler
    layout_class = ReceiptLayout

    __gsignals__ = {
        'close': (GObject.SIGNAL_RUN_FIRST, None, ()),
        'receipt_closed': (GObject.SIGNAL_RUN_FIRST, None, ()),
    }

    receipt = None
    to_money_box = None
    from_money_box = None
    receipt_item_collection = None
    _selected_receipt_item = None

    @property
    def selected_receipt_item(self):
        return self._selected_receipt_item

    @selected_receipt_item.setter
    def selected_receipt_item(self, value):
        self._selected_receipt_item = value

        # Update buttons for new selection
        if self.layout().dialog_sensitive():
            self.layout().set_dialog_sensitive()

    receipt_item_dialog = None
    add_client_dialog = None
    add_client_by_phone_dialog = None
    add_cashless_amount_dialog = None
    add_reimbursement_dialog = None
    client_form_dialog = None
    client_not_found_dialog = None
    to_money_box_dialog = None
    from_money_box_dialog = None

    def __init__(self, application, receipt):
        self.receipt = receipt
        super(ReceiptView, self).__init__(application)

    def build(self, *args, **kwargs):
        super(ReceiptView, self).build(*args, **kwargs)

        self.receipt_item_collection = ReceiptItemCollection(self.receipt.id)

        self.receipt_item_collection.connect('fill', self.layout().calculate_total)
        self.receipt_item_collection.connect('create', self.layout().calculate_total)
        self.receipt_item_collection.connect('delete', self.layout().calculate_total)

        self.receipt_item_collection.connect('fill', self.layout().calculate_back)
        self.receipt_item_collection.connect('create', self.layout().calculate_back)
        self.receipt_item_collection.connect('delete', self.layout().calculate_back)

        self.receipt_item_collection.connect('fill', self.layout().set_dialog_sensitive)
        self.receipt_item_collection.connect('clear', self.layout().set_dialog_sensitive)
        self.receipt_item_collection.connect('create', self.layout().set_dialog_sensitive)
        self.receipt_item_collection.connect('delete', self.layout().set_dialog_sensitive)

        self.receipt.connect('load', self.layout().set_dialog_sensitive)
        self.receipt.connect('update', self.layout().set_dialog_sensitive)

        self.receipt.connect('load', self.layout().fill_client)
        self.receipt.connect('load', self.layout().fill_info)
        self.receipt.connect('load', self.load_receipt_items)
        self.receipt.connect('card_not_found', self.handler().on_card_not_found)

        self.receipt.connect('update', self.layout().fill_info)

        if config['ecr'].enabled and config['ecr'].show_screen_info:
            self.receipt_item_collection.connect('fill', self.update_ecr_screan)
            self.receipt_item_collection.connect('create', self.update_ecr_screan)
            self.receipt_item_collection.connect('delete', self.update_ecr_screan)

        self.load_receipt_items()

        self.layout().render()

    def load_receipt_items(self, *args):
        self.receipt_item_collection.clear()
        self.receipt_item_collection.from_list(self.receipt.items)
        self.layout().calculate_total()
        self.layout().calculate_back()

    def get_total(self):
        total = 0
        for item in self.receipt_item_collection:
            total += item.total_with_discount
        return total

    def get_total_with_money_box(self):
        to_money_box = self.to_money_box
        if to_money_box is None:
            to_money_box = 0

        from_money_box = self.from_money_box
        if from_money_box is None:
            from_money_box = 0

        return self.get_total() + to_money_box - from_money_box

    def update_ecr_screan(self, *args):
        total = Decimal(0).quantize(Decimal('1.00'))
        total_with_discount = Decimal(0).quantize(Decimal('1.00'))

        for item in self.receipt_item_collection:
            total += item.total
            total_with_discount += item.total_with_discount
        discount = total - total_with_discount

        def on_error(*args):
            print(args)

        scr_info = [
            {'id': 1, 'align': 'l',
             'str': ("Всього:" + str(total).rjust(9)).encode('utf-8')},
            {'id': 4, 'align': 'l', 'str': "До сплати:".encode('utf-8')},
            {'id': 5, 'align': 'r', 'str': str(total_with_discount)},
        ]

        if discount:
            scr_info.append(
                {'id': 2, 'align': 'l',
                 'str': ("Знижка:" + str(discount).rjust(9)).encode('utf-8')},
            )
        else:
            scr_info.append({'id': 2, 'align': 'l', 'str': ''})

        EcrScreenRequest(scr_info, on_error=on_error)
