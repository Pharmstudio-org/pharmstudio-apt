from gi.repository import GObject

defaults = {
    'service_dialog_locked': True,
}


class EcrDialogState(GObject.Object):
    _state = defaults

    @GObject.Property(type=bool, default=defaults['service_dialog_locked'])
    def service_dialog_locked(self):
        return self._state['service_dialog_locked']

    @service_dialog_locked.setter
    def service_dialog_locked(self, value):
        self._state['service_dialog_locked'] = value
