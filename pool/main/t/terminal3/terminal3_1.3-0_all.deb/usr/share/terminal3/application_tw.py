import gi
import os
import sys
try:
    import psutil
except ImportError:
    psutil = None
import logging

gi.require_version('Gtk', '3.0')

from gi.repository import GObject, Gtk, Gdk

# fix for pyinstaller packages app to avoid ReactorAlreadyInstalledError
if 'twisted.internet.reactor' in sys.modules:
    del sys.modules['twisted.internet.reactor']

from twisted.internet import gireactor
from views.network_error import NetworkErrorDialogView
from settings import load_config


reactor = gireactor.install()

from action_factory.connection_monitor import ConnectionMonitor, TabletConnectionMonitor, EscposConnectionMonitor
from views.layout import LayoutView


class Application(GObject.GObject):
    connection_monitor = ConnectionMonitor()
    tablet_connection_monitor = TabletConnectionMonitor()
    escpos_connection_monitor = EscposConnectionMonitor()

    application_window = None
    clipboard = None
    accel_group = None
    network_error_dialog = None

    def __init__(self):
        GObject.GObject.__init__(self)

        style_provider = Gtk.CssProvider()
        style_provider.load_from_path(os.path.join('data', 'css', 'main.css'))

        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            style_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

        self.accel_group = Gtk.AccelGroup()
        self.application_window = LayoutView(self).widget()
        self.application_window.maximize()
        self.clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        self.run()

    def show_network_error(self, parent=None):
        if self.network_error_dialog is None:
            self.network_error_dialog = NetworkErrorDialogView(self)
        if parent:
            self.network_error_dialog.widget().set_transient_for(parent)
        else:
            self.network_error_dialog.widget().set_transient_for(self.application_window)
        self.network_error_dialog.widget().show_all()

    def quit(self, *args):
        self.connection_monitor.stop()
        self.tablet_connection_monitor.stop()
        self.escpos_connection_monitor.stop()
        reactor.stop()

    def run(self):
        load_config()
        self.connection_monitor.run()
        self.tablet_connection_monitor.run()
        self.escpos_connection_monitor.run()
        reactor.run()

    def restart(self):
        self.connection_monitor.stop()
        self.tablet_connection_monitor.stop()
        self.escpos_connection_monitor.stop()
        reactor.stop()

        try:
            if psutil:
                p = psutil.Process(os.getpid())
                for handler in p.open_files() + p.connections():
                    os.close(handler.fd)
        except Exception as e:
            logging.error(e)

        python = sys.executable
        os.execl(python, python, *sys.argv)
