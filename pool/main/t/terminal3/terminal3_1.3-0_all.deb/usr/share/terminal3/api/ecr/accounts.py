from api.common import EcrRequest
from decimal import Decimal


class EcrAccountsRequest(EcrRequest):
    def get_args(self):
        return ['rep_pay']


class EcrAccountsDepositRequest(EcrRequest):
    """
    args[0] - payment no
    args[1] - amount
    """
    def get_args(self):
        return ['chk_in', '-n', str(self.args[0]), str(Decimal(self.args[1]).quantize(Decimal('1.00')))]


class EcrAccountsWithdrawalRequest(EcrRequest):
    """
    args[0] - payment no
    args[1] - amount
    """
    def get_args(self):
        return ['chk_out', '-n', str(self.args[0]), str(Decimal(self.args[1]).quantize(Decimal('1.00')))]
