from .view import MergeForPrintDialogView
