from .view import ReceiptItemDialogView
