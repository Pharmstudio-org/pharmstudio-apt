import api
from settings import config
import treq

URL = "sales/api/receipts/"


class ReceiptListRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(URL, 'list'),
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=10
        )


class ReceiptCreateRequest(api.RequestJson):
    def send(self):
        return treq.post(
            api.url(URL, 'create'),
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptDetailRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(URL, 'detail', self.args[0]),
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptUpdateRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(URL, 'update', self.args[0]),
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptCloseRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(URL, 'update', self.args[0]) + 'close/',
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptCancelRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(URL, 'update', self.args[0]) + 'cancel/',
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


# Backward compatibility
class ReceiptAddClientRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(URL, 'update', self.args[0]) + 'client-add/',
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptAddCardRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(URL, 'update', self.args[0]) + 'card-add/',
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptRemoveClientRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(URL, 'update', self.args[0]) + 'client-remove/',
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class ReceiptRemoveAffiliateRequest(api.RequestJson):
    def send(self):
        return treq.put(
            api.url(URL, 'update', self.args[0]) + 'affiliate-remove/',
            data=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5,
        )
