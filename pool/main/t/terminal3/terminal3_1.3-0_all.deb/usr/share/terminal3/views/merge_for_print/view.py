from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import MergeForPrintDialogHandler
from .layout import MergeForPrintDialogLayout


class MergeForPrintDialogView(View):
    glade_file = 'merge_for_print_dialog.glade'
    main_widget_id = 'dialog_merge_for_print'

    event_handler_class = MergeForPrintDialogHandler
    layout_class = MergeForPrintDialogLayout

    __gsignals__ = {
        'add': (GObject.SIGNAL_RUN_FIRST, None, (str,)),
    }
