import api
from settings import config
import treq


URL = "sales/api/receipts/"


class GetReceiptTextRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(URL, 'detail', self.args[0]) + 'print/',
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class PrintReceiptRequest(api.Request):
    def send(self):
        return treq.post(config['print'].server_url + '/print/', data={'data': self.args[0]}, timeout=5)
