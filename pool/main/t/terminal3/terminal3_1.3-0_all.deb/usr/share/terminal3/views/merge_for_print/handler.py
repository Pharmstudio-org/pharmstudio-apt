import json
import os
from decimal import Decimal
import tempfile
from views.common import Handler
from settings import config
from api.ecr.receipts import EcrReceiptRequest, DecimalEncoder


class MergeForPrintDialogHandler(Handler):
    def on_print(self, *args):
        ecr_receipt_list = [
            {'S': {
                'code': self.layout.code,
                'price': Decimal(self.layout.price),
                'qty': Decimal(self.layout.count),
                'name': self.layout.title,
            }},
            {'D': {'sum': Decimal(self.layout.reimbursment) * -1}}
        ]
        if self.layout.cashless_amount:
            ecr_receipt_list.append({'P': {'no': config['ecr'].cashless_account_no, 'sum': self.layout.cashless_amount}})
            if self.layout.cashless_amount < Decimal(self.layout.total):
                ecr_receipt_list.append({'P': {
                    'sum': Decimal(Decimal(self.layout.total) - self.layout.cashless_amount).quantize(Decimal('1.00'))
                }})
        else:
            ecr_receipt_list.append({'P': {}})

        f = tempfile.NamedTemporaryFile(mode='w', delete=False, encoding='utf-8')
        json.dump({'F': ecr_receipt_list}, f, cls=DecimalEncoder, ensure_ascii=False)
        name = f.name
        f.close()

        def on_success(*args):
            os.unlink(f.name)
            self.widget.close()

        def on_error(*args):
            os.unlink(f.name)
            self.widget.close()
            print(args)
            self.view.application.show_network_error()

        self.layout.button_print.set_sensitive(False)
        EcrReceiptRequest(name, on_success=on_success, on_error=on_error)

    def on_close(self, *args):
        self.widget.close()
