from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import AddCashlessAmountDialogHandler
from .layout import AddCashlessAmountDialogLayout


class AddCashlessAmountDialogView(View):
    glade_file = 'add_cashless_amount_dialog.glade'
    main_widget_id = 'dialog_add_cashless_amount'

    event_handler_class = AddCashlessAmountDialogHandler
    layout_class = AddCashlessAmountDialogLayout

    __gsignals__ = {
        'add': (GObject.SIGNAL_RUN_FIRST, None, (str,)),
    }
