from .view import GoodsBalanceView
