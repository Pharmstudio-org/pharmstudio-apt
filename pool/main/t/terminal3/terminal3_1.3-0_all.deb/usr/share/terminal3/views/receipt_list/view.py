from gi.repository import GObject, Gtk
from views import View
from models.receipt import ReceiptModel, ReceiptCollection
from decimal import Decimal
from .handler import ReceiptListHandler
from .layout import ReceiptListLayout


class ReceiptListView(View):
    __gsignals__ = {
        'close': (GObject.SIGNAL_RUN_FIRST, None, ()),
        'open_receipt': (GObject.SIGNAL_RUN_FIRST, None, (ReceiptModel,)),
    }

    glade_file = 'receipt_list.glade'
    main_widget_id = 'box_receipt_list'

    event_handler_class = ReceiptListHandler
    layout_class = ReceiptListLayout

    receipt_collection = None
    selected_receipt_model = None

    def build(self):
        super(ReceiptListView, self).build()

        self.receipt_collection = ReceiptCollection()
        self.receipt_collection.connect('fill', self.calculate_total)
        self.layout().stack.set_visible_child(self.layout().loader)
        self.receipt_collection.api('list')

        self.layout().render()

    def calculate_total(self, *args):
        self.layout().stack.set_visible_child(self.layout().receipt_list)
        total = Decimal(0)
        for item in self.receipt_collection:
            if item.closed:
                total += item.total_with_discount
        self.layout().total = str(total.quantize(Decimal('1.00')))
