from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import ClientFormDialogHandler
from .layout import ClientFormDialogLayout
from .state import ClientFormState


class ClientFromDialogView(View):
    glade_file = 'client_form_dialog.glade'
    main_widget_id = 'client_form_dialog'

    event_handler_class = ClientFormDialogHandler
    layout_class = ClientFormDialogLayout
    state_class = ClientFormState.init()

    __gsignals__ = {
        'add': (GObject.SIGNAL_RUN_FIRST, None, (str,)),
    }
