from views.common import Handler


class AddClientDialogHandler(Handler):
    def on_add(self, *args):
        self.emit('add', self.layout.client_code)
        self.widget.close()

    def on_close(self, *args):
        self.widget.hide()
        return True

    def on_button_find_by_phone_clicked(self, *args):
        self.emit('find-by-phone')
        self.widget.close()

    def on_add_client_button_clicked(self, *args):
        #self.widget.close()
        self.emit('register-new-client')
