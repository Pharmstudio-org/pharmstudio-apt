import api
from settings import config
import treq


URL = "sales/api/pledge/print/"


class GetPledgeTextRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(URL, 'list'),
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5
        )


class PrintPledgeRequest(api.Request):
    def send(self):
        return treq.post(config['print'].server_url + '/print/', data={'data': self.args[0]}, timeout=5)
