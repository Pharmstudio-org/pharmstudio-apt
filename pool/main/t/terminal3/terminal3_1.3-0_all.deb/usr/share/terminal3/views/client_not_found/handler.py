from views.common import Handler


class ClientNotFoundDialogHandler(Handler):
    def on_close(self, *args):
        self.widget.hide()
        return True
