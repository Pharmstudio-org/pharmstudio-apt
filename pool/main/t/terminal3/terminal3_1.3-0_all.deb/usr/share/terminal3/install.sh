#!/bin/bash

sudo apt-get install -y $(cat deb_required.txt)
if [ ! -d ".env" ]; then
  virtualenv --system-site-packages .env
fi
source ./.env/bin/activate
pip install -r requirments.txt
deactivate
cp Terminal.desktop "$(xdg-user-dir DESKTOP)"
echo "Path=$(pwd)" >> "$(xdg-user-dir DESKTOP)/Terminal.desktop"
