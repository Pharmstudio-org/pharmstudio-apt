#!/bin/sh
cd ~/projects/N707TS
~/virtualenv/N707TS/bin/python ecr.py "$@"
