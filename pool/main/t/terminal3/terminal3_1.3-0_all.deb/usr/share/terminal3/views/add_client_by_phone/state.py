from gi.repository import GObject
from api.crm_info import GetCrmClientsByPhoneRequest

defaults = {
    'phone': '',
    'clients': {
        'selected_client_code': None,
        'request': False,
        'error': False,
    },
    'client_list': [],
}


class AddClientByPhoneState(GObject.Object):
    _state = defaults
    
    @GObject.Property(type=str)
    def phone(self):
        return self._state['phone']
    
    @phone.setter
    def phone(self, value):
        self._state['phone'] = value
    
    @GObject.Property(type=object)
    def clients(self):
        return self._state['clients']

    @clients.setter
    def clients(self, value):
        self._state['clients'] = value
        
    @GObject.Property(type=object)
    def client_list(self):
        return self._state['client_list']

    @client_list.setter
    def client_list(self, value):
        self._state['client_list'] = value
        
    def dispatch_phone_change(self, phone):
        self.phone = phone
    
    def dispatch_client_search_success(self, client_list):
        self.clients = dict(self.clients, request=False, error=False)
        self.client_list = client_list
        
    def dispatch_client_search_error(self):
        self.client_list = []
        self.clients = dict(self.clients, request=False, error=True)
    
    def dispatch_clients_search_request(self):
        self.client_list = []
        self.clients = dict(
            self.clients, request=True, error=False, selected_client_code=None)
        GetCrmClientsByPhoneRequest(
            data={'phone': self.phone},
            on_success=lambda result: self.dispatch_client_search_success(result),
            on_error=lambda _: self.dispatch_client_search_error(),
        )
        
    def dispatch_client_select(self, client_code):
        self.clients = dict(self.clients, selected_client_code=client_code)
        
    def dispatch_clear_client_list(self):
        self.client_list = []
        self.clients = dict(self.clients, selected_client_code=None)