from .view import SecureDialogView
