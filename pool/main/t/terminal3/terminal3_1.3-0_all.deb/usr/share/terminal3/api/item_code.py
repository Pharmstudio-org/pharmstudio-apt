import api
from settings import config
import treq

URL = "sales/api/item-code/%s/"
LIST_URL = "sales/api/item-code-list/"
PRICE_URL = "goods-balance/prices/%s"


class ItemCodeRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(URL, 'list', self.args[0]),
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5,
        )


class ItemCodeListRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(LIST_URL, 'list'),
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5,
        )


class ItemCodePriceRequest(api.RequestJson):
    def send(self):
        return treq.get(
            api.url(PRICE_URL, 'list', self.args[0]),
            params=self.data,
            auth=(config['auth'].api_user, config['auth'].api_password,),
            timeout=5,
        )
