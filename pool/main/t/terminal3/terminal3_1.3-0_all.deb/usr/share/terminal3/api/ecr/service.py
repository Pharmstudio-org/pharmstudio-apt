from api.common import EcrRequest


class EcrSendAndReset(EcrRequest):
    def get_args(self):
        return ['printreport', '1']
