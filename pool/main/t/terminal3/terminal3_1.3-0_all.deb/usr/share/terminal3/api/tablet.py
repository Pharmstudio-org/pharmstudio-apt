import api
from settings import TABLET_IP, TABLET_PORT
import treq

URL = "sales/api/receipts/"


class UpdateTabletInfoRequest(api.RequestJson):
    def send(self):
        if TABLET_IP and TABLET_PORT:
            return treq.get('http://' + TABLET_IP + ':' + TABLET_PORT, params=self.data, timeout=2)
        else:
            return None
