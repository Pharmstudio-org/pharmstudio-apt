from decimal import Decimal
from views.common import Layout, Binding, Widget


class MergeForPrintDialogLayout(Layout):
    code = None
    cashless_amount = None
    title = Binding('label_title')
    count = Binding('label_count')
    price = Binding('label_price')
    total = Binding('label_total')
    reimbursment = Binding('label_reimbursment')
    to_pay = Binding('label_to_pay')

    button_print = Widget('button_print')

    def render(self, reimbursment, cashless_amount, receipt_item_collection):
        if len(receipt_item_collection):
            title = None
            total_units = None

            count = 0
            units = 0

            total = Decimal(0)

            for item in receipt_item_collection:
                if self.code is None:
                    self.code = item.code
                if title is None:
                    title = item.title
                if total_units is None:
                    total_units = item.total_units

                if item.count > 1:
                    count += item.count
                else:
                    units += item.units

                total += item.total_with_discount
            result_count = Decimal(count) + Decimal(Decimal(units) / Decimal(total_units)).quantize(Decimal('1.000'))
            result_price = Decimal(total / result_count).quantize(Decimal('1.00'))
            result_total = Decimal(result_price * result_count).quantize(Decimal('1.00'))

            self.button_print.set_sensitive(True)
            self.reimbursment = str(reimbursment)
            self.cashless_amount = cashless_amount
            self.title = title
            self.count = str(result_count)
            self.price = str(result_price)
            self.total = str(result_total)
            to_pay = Decimal(result_total - Decimal(reimbursment)).quantize(Decimal('1.00'))
            if cashless_amount:
                cash = to_pay - cashless_amount
                pay_list = []
                if cash:
                    pay_list.append(f"готівкою: {str(cash)}")
                pay_list.append(f"карткою: {str(cashless_amount)}")
                self.to_pay = f"{str(to_pay)} ({', '.join(pay_list)})"
            else:
                self.to_pay = str(to_pay)
        else:
            self.button_print.set_sensitive(False)
