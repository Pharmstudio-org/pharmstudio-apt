from gi.repository import GObject, Gtk, Pango
from views import View
from .handler import SecureDialogHandler
from .layout import SecureDialogLayout


class SecureDialogView(View):
    glade_file = 'secure_dialog.glade'
    main_widget_id = 'dialog_secure'

    event_handler_class = SecureDialogHandler
    layout_class = SecureDialogLayout

    def build(self):
        super(SecureDialogView, self).build()

    __gsignals__ = {
        'show_settings': (GObject.SIGNAL_RUN_FIRST, None, ()),
    }
